import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GOOGLE_API_KEY || "" });

const RECYCLING_COACH_SYSTEM_PROMPT_EN = `You are EcoRakyat's AI Recycling Coach - a friendly and knowledgeable assistant helping Malaysian citizens recycle properly.

IMPORTANT: Always respond in English.

Your responsibilities:
1. Help users identify recyclable materials from their photos
2. Provide guidance on proper recycling practices in Malaysia
3. Suggest the best disposal methods for different waste types
4. Educate users about environmental impact of recycling
5. Answer questions about the EcoRakyat recycling program

Category Information:
- Plastic: PET bottles (check for ♻️1 symbol), HDPE containers (♻️2), plastic bags
- Paper: Newspapers, cardboard, office paper
- Glass: Bottles, jars (not broken glass)
- Metal: Aluminum cans, steel containers
- E-Waste: Electronics, batteries, cables
- Batteries: All battery types (need special handling)
- Used Cooking Oil: Kitchen oil (our specialty!)
- Textiles: Clothes, fabrics
- Appliances: Large electronics, home appliances
- Organic: Food waste, garden waste
- Special Waste: Hazardous materials, chemicals

Format your responses:
- Use **bold text** for important terms and categories
- Use bullet points (starting with - or *) for lists
- Keep responses helpful, concise, and encouraging
- Avoid long-winded explanations - be direct and practical
- Always emphasize the positive environmental impact of recycling.`;

const IMAGE_ANALYSIS_PROMPT_EN = `You are analyzing a recyclable item photo for an initial assessment. Your goal is to:
1. Greet the user briefly and identify what you see in the image
2. Make ONE helpful observation about the item (material, condition, brand if visible)
3. Ask ONE specific follow-up question to better understand how to recycle it properly

For plastic bottles/containers:
- Ask if they can check for the recycling symbol number (1-7) on the bottom
- Or ask if the bottles have been rinsed and caps removed

For water bottles specifically:
- Ask about the plastic type if visible, or whether the bottles are empty
- Ask if they plan to submit multiple bottles

Keep your response warm, conversational, and under 50 words. End with your question.`;

const IMAGE_ANALYSIS_PROMPT_MS = `Anda menganalisis foto item kitar semula untuk penilaian awal. Matlamat anda:
1. Sapa pengguna dengan ringkas dan kenal pasti apa yang anda lihat dalam gambar
2. Buat SATU pemerhatian berguna tentang item (bahan, keadaan, jenama jika kelihatan)
3. Tanya SATU soalan susulan khusus untuk lebih memahami cara kitar semula dengan betul

Untuk botol/bekas plastik:
- Tanya jika mereka boleh semak nombor simbol kitar semula (1-7) di bahagian bawah
- Atau tanya jika botol telah dibilas dan penutup dibuang

Untuk botol air khususnya:
- Tanya tentang jenis plastik jika kelihatan, atau sama ada botol kosong
- Tanya jika mereka bercadang menghantar beberapa botol

Pastikan respons anda mesra dan tidak melebihi 50 patah perkataan. Akhiri dengan soalan anda.`;

const FOLLOWUP_ANALYSIS_PROMPT_EN = `Based on the image and the user's answers, provide a SHOWCASE-READY recycling analysis.

Structure your response EXACTLY like this:

**Item Identified**: [What it is - be specific about brand/type]

**Category**: Plastic (Recyclable)

**Preparation Steps**:
- Remove caps and labels
- Rinse if necessary
- Flatten to save space

**Recycling Value**: High - These bottles are made from [material type], which is highly valuable for recycling.

**Your Impact**: By recycling these bottles, you're helping reduce plastic pollution and conserving resources!

Keep total response under 80 words. Be encouraging and practical.`;

const FOLLOWUP_ANALYSIS_PROMPT_MS = `Berdasarkan gambar dan jawapan pengguna, berikan analisis kitar semula SEDIA UNTUK PAMERAN.

Struktur respons anda TEPAT seperti ini:

**Item Dikenal Pasti**: [Apa item tersebut - khusus tentang jenama/jenis]

**Kategori**: Plastik (Boleh Dikitar Semula)

**Langkah Penyediaan**:
- Buang penutup dan label
- Bilas jika perlu
- Kempiskan untuk jimat ruang

**Nilai Kitar Semula**: Tinggi - Botol ini diperbuat daripada [jenis bahan], yang sangat bernilai untuk kitar semula.

**Impak Anda**: Dengan mengitar semula botol ini, anda membantu mengurangkan pencemaran plastik dan memelihara sumber!

Pastikan respons tidak melebihi 80 patah perkataan. Bersemangat dan praktikal.`;

const RECYCLING_COACH_SYSTEM_PROMPT_MS = `Anda adalah Jurulatih Kitar Semula AI EcoRakyat - pembantu mesra dan berpengetahuan yang membantu rakyat Malaysia kitar semula dengan betul.

PENTING: Sentiasa balas dalam Bahasa Malaysia.

Tanggungjawab anda:
1. Bantu pengguna mengenal pasti bahan kitar semula dari foto mereka
2. Beri panduan tentang amalan kitar semula yang betul di Malaysia
3. Cadangkan kaedah pelupusan terbaik untuk pelbagai jenis sisa
4. Didik pengguna tentang kesan alam sekitar kitar semula
5. Jawab soalan tentang program kitar semula EcoRakyat

Maklumat Kategori:
- Plastik: Botol PET, bekas HDPE, beg plastik
- Kertas: Surat khabar, kadbod, kertas pejabat
- Kaca: Botol, balang (bukan kaca pecah)
- Logam: Tin aluminium, bekas keluli
- E-Sisa: Elektronik, bateri, kabel
- Bateri: Semua jenis bateri (perlu pengendalian khas)
- Minyak Masak Terpakai: Minyak dapur (kepakaran kami!)
- Tekstil: Pakaian, fabrik
- Peralatan: Elektronik besar, peralatan rumah
- Organik: Sisa makanan, sisa kebun
- Sisa Khas: Bahan berbahaya, bahan kimia

Format respons anda:
- Gunakan **teks tebal** untuk istilah dan kategori penting
- Gunakan titik peluru (bermula dengan - atau *) untuk senarai
- Pastikan respons membantu dan menggalakkan
- Sentiasa tekankan kesan positif alam sekitar daripada kitar semula.`;

const RIDER_ASSISTANT_SYSTEM_PROMPT = `You are EcoRider's AI Assistant - helping collection riders optimize their routes and handle recyclables efficiently.

Your responsibilities:
1. Suggest optimal collection routes based on pickup locations
2. Provide tips for handling different recyclable materials safely
3. Help troubleshoot common issues during collection
4. Advise on weight estimation and quality assessment
5. Assist with reporting illegal dumping incidents

Be concise, practical, and safety-focused. Riders are often on the go, so keep responses brief but helpful.`;

export async function getRecyclingAdvice(userMessage: string, imageBase64?: string, language: string = "ms"): Promise<string> {
  try {
    const contents: any[] = [];
    
    if (imageBase64) {
      contents.push({
        inlineData: {
          data: imageBase64,
          mimeType: "image/jpeg",
        },
      });
    }
    
    contents.push(userMessage);

    const systemPrompt = language === "en" 
      ? RECYCLING_COACH_SYSTEM_PROMPT_EN 
      : RECYCLING_COACH_SYSTEM_PROMPT_MS;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: contents,
    });

    return response.text || (language === "en" 
      ? "I'm having trouble processing your request. Please try again." 
      : "Saya menghadapi masalah memproses permintaan anda. Sila cuba lagi.");
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error(`Failed to get recycling advice: ${error}`);
  }
}

export async function analyzeImageWithQuestions(
  imageBase64: string, 
  userMessage: string,
  conversationHistory: { role: string; content: string; hasImage?: boolean }[],
  language: string = "ms"
): Promise<string> {
  try {
    const contents: any[] = [];
    
    const hasExistingImage = conversationHistory.some(msg => msg.hasImage);
    const isInitialImageUpload = !hasExistingImage && imageBase64;
    
    if (imageBase64) {
      contents.push({
        inlineData: {
          data: imageBase64,
          mimeType: "image/jpeg",
        },
      });
    }

    if (isInitialImageUpload) {
      const analysisPrompt = language === "en" 
        ? IMAGE_ANALYSIS_PROMPT_EN 
        : IMAGE_ANALYSIS_PROMPT_MS;
      contents.push(`${analysisPrompt}\n\nUser message: ${userMessage || "Please analyze this item for recycling."}`);
    } else if (hasExistingImage) {
      const followupPrompt = language === "en" 
        ? FOLLOWUP_ANALYSIS_PROMPT_EN 
        : FOLLOWUP_ANALYSIS_PROMPT_MS;
      
      const contextMessages = conversationHistory
        .map(msg => `${msg.role === 'user' ? 'User' : 'Assistant'}: ${msg.content}`)
        .join('\n');
      
      contents.push(`Previous conversation:\n${contextMessages}\n\nUser's answer: ${userMessage}\n\n${followupPrompt}`);
    } else {
      contents.push(userMessage);
    }

    const systemPrompt = language === "en" 
      ? RECYCLING_COACH_SYSTEM_PROMPT_EN 
      : RECYCLING_COACH_SYSTEM_PROMPT_MS;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: contents,
    });

    return response.text || (language === "en" 
      ? "I'm having trouble processing your request. Please try again." 
      : "Saya menghadapi masalah memproses permintaan anda. Sila cuba lagi.");
  } catch (error) {
    console.error("Gemini image analysis error:", error);
    throw new Error(`Failed to analyze image: ${error}`);
  }
}

export async function getRiderAssistance(query: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: RIDER_ASSISTANT_SYSTEM_PROMPT,
      },
      contents: query,
    });

    return response.text || "Unable to provide assistance at this time.";
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error(`Failed to get rider assistance: ${error}`);
  }
}

export interface RouteOptimizationResult {
  optimizedOrder: number[];
  estimatedDuration: number;
  totalDistance: number;
  suggestions: string[];
}

export async function optimizeRoute(
  waypoints: { lat: number; lng: number; address?: string }[]
): Promise<RouteOptimizationResult> {
  try {
    const waypointsList = waypoints
      .map((wp, i) => `${i + 1}. ${wp.address || `(${wp.lat}, ${wp.lng})`}`)
      .join("\n");

    const prompt = `Given these pickup locations in Malaysia:
${waypointsList}

Suggest the optimal order to visit them to minimize travel time and distance.
Consider traffic patterns in Malaysian cities.

Respond in JSON format:
{
  "optimizedOrder": [array of indices 1-based],
  "estimatedDuration": estimated total minutes,
  "totalDistance": estimated total km,
  "suggestions": ["helpful tip 1", "helpful tip 2"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            optimizedOrder: { type: "array", items: { type: "number" } },
            estimatedDuration: { type: "number" },
            totalDistance: { type: "number" },
            suggestions: { type: "array", items: { type: "string" } },
          },
          required: ["optimizedOrder", "estimatedDuration", "totalDistance", "suggestions"],
        },
      },
      contents: prompt,
    });

    const result = JSON.parse(response.text || "{}");
    return result as RouteOptimizationResult;
  } catch (error) {
    console.error("Route optimization error:", error);
    return {
      optimizedOrder: waypoints.map((_, i) => i + 1),
      estimatedDuration: waypoints.length * 15,
      totalDistance: waypoints.length * 5,
      suggestions: ["Unable to optimize route at this time. Using default order."],
    };
  }
}

export interface RouteItem {
  id: number;
  lat: number;
  lng: number;
  address?: string;
  category: string;
  weightKg?: number;
}

export interface OptimizedRouteResult {
  onRouteItems: { id: number; sequence: number; distanceFromPrev: number }[];
  offRouteItems: { id: number; reason: string }[];
  wrongCategoryItems: { id: number; category: string }[];
  totalDistanceKm: number;
  estimatedDurationMin: number;
  aiSummary: string;
  waypoints: { lat: number; lng: number; sequence: number }[];
  petrolConsumedL: number;
  petrolSavedL: number;
  co2SavedKg: number;
  baselineDistanceKm: number;
}

function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c * 1.3;
}

function calculateRouteMetrics(optimizedDistanceKm: number, itemCount: number) {
  const FUEL_CONSUMPTION_L_PER_100KM = 13;
  const CO2_KG_PER_LITER = 2.31;
  
  const avgDistancePerItem = 5;
  const baselineDistanceKm = itemCount * avgDistancePerItem * 1.5;
  
  const petrolConsumedL = (optimizedDistanceKm / 100) * FUEL_CONSUMPTION_L_PER_100KM;
  const baselinePetrolL = (baselineDistanceKm / 100) * FUEL_CONSUMPTION_L_PER_100KM;
  const petrolSavedL = Math.max(0, baselinePetrolL - petrolConsumedL);
  const co2SavedKg = petrolSavedL * CO2_KG_PER_LITER;
  
  return {
    petrolConsumedL: Math.round(petrolConsumedL * 100) / 100,
    petrolSavedL: Math.round(petrolSavedL * 100) / 100,
    co2SavedKg: Math.round(co2SavedKg * 100) / 100,
    baselineDistanceKm: Math.round(baselineDistanceKm * 10) / 10
  };
}

export async function optimizeRouteWithCategories(
  truckLocation: { lat: number; lng: number },
  items: RouteItem[],
  selectedCategories: string | string[],
  restrictedCategories: string[],
  truckCapacityKg: number,
  language: string = "ms"
): Promise<OptimizedRouteResult> {
  const categories = Array.isArray(selectedCategories) ? selectedCategories : [selectedCategories];
  const categoryLabel = categories.length === 1 
    ? categories[0] 
    : categories.join(", ");
    
  try {
    const categoryItems = items.filter(item => categories.includes(item.category));
    const wrongCategoryItems = items.filter(item => 
      !categories.includes(item.category) && 
      !restrictedCategories.includes(item.category)
    );

    if (categoryItems.length === 0) {
      return {
        onRouteItems: [],
        offRouteItems: [],
        wrongCategoryItems: items.map(i => ({ id: i.id, category: i.category })),
        totalDistanceKm: 0,
        estimatedDurationMin: 0,
        aiSummary: language === "en" 
          ? `No items found for the selected categories (${categoryLabel}).` 
          : `Tiada item ditemui untuk kategori yang dipilih (${categoryLabel}).`,
        waypoints: [],
        petrolConsumedL: 0,
        petrolSavedL: 0,
        co2SavedKg: 0,
        baselineDistanceKm: 0
      };
    }

    const itemsList = categoryItems
      .map((item, i) => `${i + 1}. ID:${item.id} at (${item.lat}, ${item.lng}) - ${item.address || "No address"} - ${item.weightKg || 0}kg - Category: ${item.category}`)
      .join("\n");

    const prompt = `You are an AI route optimizer for a recycling collection service in Malaysia.

TRUCK LOCATION: (${truckLocation.lat}, ${truckLocation.lng})
TRUCK CAPACITY: ${truckCapacityKg} kg
CATEGORIES BEING COLLECTED: ${categoryLabel}

ITEMS TO COLLECT:
${itemsList}

TASK:
1. Analyze distances from truck location to all items
2. Calculate the optimal route visiting items efficiently
3. Identify items that are "too far off route" (>15km detour from optimal path)
4. Consider Malaysian road patterns and traffic

RESPOND IN JSON with these exact fields:
{
  "onRouteItems": [{"id": item_id, "sequence": 1-based_order, "distanceFromPrev": km}],
  "offRouteItems": [{"id": item_id, "reason": "15km detour from main route"}],
  "totalDistanceKm": total_route_distance,
  "estimatedDurationMin": total_time_including_15min_per_stop,
  "aiSummary": "${language === "en" ? "Brief English explanation of the optimized route" : "Penjelasan ringkas dalam Bahasa Malaysia tentang laluan yang dioptimumkan"}"
}

Important:
- Put most items on-route unless they are genuinely too far (>15km detour)
- Order items by optimal travel path from truck location
- Calculate realistic driving distances for Malaysian roads`;

    let result: any = null;
    let retryCount = 0;
    const maxRetries = 2;
    
    while (retryCount <= maxRetries && !result) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: "object",
              properties: {
                onRouteItems: { 
                  type: "array", 
                  items: { 
                    type: "object",
                    properties: {
                      id: { type: "number" },
                      sequence: { type: "number" },
                      distanceFromPrev: { type: "number" }
                    }
                  } 
                },
                offRouteItems: { 
                  type: "array", 
                  items: { 
                    type: "object",
                    properties: {
                      id: { type: "number" },
                      reason: { type: "string" }
                    }
                  } 
                },
                totalDistanceKm: { type: "number" },
                estimatedDurationMin: { type: "number" },
                aiSummary: { type: "string" }
              },
              required: ["onRouteItems", "offRouteItems", "totalDistanceKm", "estimatedDurationMin", "aiSummary"]
            }
          },
          contents: prompt
        });

        const responseText = response.text || "{}";
        result = JSON.parse(responseText);
        
        if (!result.onRouteItems || !Array.isArray(result.onRouteItems)) {
          console.log("Invalid AI response structure, retrying...");
          result = null;
          retryCount++;
          continue;
        }
      } catch (parseError) {
        console.log(`JSON parse error on attempt ${retryCount + 1}:`, parseError);
        retryCount++;
        if (retryCount > maxRetries) {
          throw parseError;
        }
      }
    }
    
    if (!result) {
      throw new Error("Failed to get valid AI response after retries");
    }

    const waypoints = result.onRouteItems.map((item: any) => {
      const originalItem = categoryItems.find(i => i.id === item.id);
      return {
        lat: originalItem?.lat || 0,
        lng: originalItem?.lng || 0,
        sequence: item.sequence
      };
    }).sort((a: any, b: any) => a.sequence - b.sequence);

    let calculatedDistanceKm = 0;
    if (waypoints.length > 0) {
      calculatedDistanceKm += haversineDistance(
        truckLocation.lat, truckLocation.lng,
        waypoints[0].lat, waypoints[0].lng
      );
      for (let i = 1; i < waypoints.length; i++) {
        calculatedDistanceKm += haversineDistance(
          waypoints[i - 1].lat, waypoints[i - 1].lng,
          waypoints[i].lat, waypoints[i].lng
        );
      }
    }

    const finalDistanceKm = Math.max(calculatedDistanceKm, result.totalDistanceKm || 0);
    const metrics = calculateRouteMetrics(finalDistanceKm, result.onRouteItems?.length || 0);
    
    const AVG_SPEED_KM_PER_HOUR = 30;
    const STOP_TIME_MINUTES = 15;
    const drivingMinutes = Math.round((finalDistanceKm / AVG_SPEED_KM_PER_HOUR) * 60);
    const stopMinutes = waypoints.length * STOP_TIME_MINUTES;
    const calculatedDurationMin = drivingMinutes + stopMinutes;

    return {
      onRouteItems: result.onRouteItems || [],
      offRouteItems: result.offRouteItems || [],
      wrongCategoryItems: wrongCategoryItems.map(i => ({ id: i.id, category: i.category })),
      totalDistanceKm: Math.round(finalDistanceKm * 10) / 10,
      estimatedDurationMin: Math.max(calculatedDurationMin, result.estimatedDurationMin || 0),
      aiSummary: result.aiSummary || (language === "en" 
        ? `Route optimized with ${waypoints.length} stops covering ${finalDistanceKm.toFixed(1)} km.`
        : `Laluan dioptimumkan dengan ${waypoints.length} perhentian merangkumi ${finalDistanceKm.toFixed(1)} km.`),
      waypoints,
      ...metrics
    };
  } catch (error) {
    console.error("Route optimization with categories error:", error);
    
    const fallbackCategoryItems = items.filter(item => categories.includes(item.category));
    const fallbackWrongCategoryItems = items.filter(item => !categories.includes(item.category));
    
    const fallbackWaypoints = fallbackCategoryItems.map((item, i) => ({ lat: item.lat, lng: item.lng, sequence: i + 1 }));
    
    let fallbackDistanceKm = 0;
    if (fallbackWaypoints.length > 0) {
      fallbackDistanceKm += haversineDistance(
        truckLocation.lat, truckLocation.lng,
        fallbackWaypoints[0].lat, fallbackWaypoints[0].lng
      );
      for (let i = 1; i < fallbackWaypoints.length; i++) {
        fallbackDistanceKm += haversineDistance(
          fallbackWaypoints[i - 1].lat, fallbackWaypoints[i - 1].lng,
          fallbackWaypoints[i].lat, fallbackWaypoints[i].lng
        );
      }
    }
    
    const fallbackMetrics = calculateRouteMetrics(fallbackDistanceKm, fallbackCategoryItems.length);
    
    const AVG_SPEED_KM_PER_HOUR = 30;
    const STOP_TIME_MINUTES = 15;
    const fallbackDrivingMin = Math.round((fallbackDistanceKm / AVG_SPEED_KM_PER_HOUR) * 60);
    const fallbackStopMin = fallbackWaypoints.length * STOP_TIME_MINUTES;
    const fallbackDurationMin = fallbackDrivingMin + fallbackStopMin;
    
    return {
      onRouteItems: fallbackCategoryItems.map((item, i) => ({ id: item.id, sequence: i + 1, distanceFromPrev: 2 })),
      offRouteItems: [],
      wrongCategoryItems: fallbackWrongCategoryItems.map(i => ({ id: i.id, category: i.category })),
      totalDistanceKm: Math.round(fallbackDistanceKm * 10) / 10,
      estimatedDurationMin: fallbackDurationMin,
      aiSummary: language === "en" 
        ? `Route created with ${fallbackCategoryItems.length} stops covering ${fallbackDistanceKm.toFixed(1)} km for ${categoryLabel}. AI optimization unavailable.` 
        : `Laluan dicipta dengan ${fallbackCategoryItems.length} perhentian merangkumi ${fallbackDistanceKm.toFixed(1)} km untuk ${categoryLabel}. Pengoptimuman AI tidak tersedia.`,
      waypoints: fallbackWaypoints,
      ...fallbackMetrics
    };
  }
}

export async function analyzeRecyclableImage(imageBase64: string): Promise<{
  category: string;
  subcategory: string;
  confidence: number;
  recyclable: boolean;
  tips: string;
}> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            category: { type: "string" },
            subcategory: { type: "string" },
            confidence: { type: "number" },
            recyclable: { type: "boolean" },
            tips: { type: "string" },
          },
          required: ["category", "subcategory", "confidence", "recyclable", "tips"],
        },
      },
      contents: [
        {
          inlineData: {
            data: imageBase64,
            mimeType: "image/jpeg",
          },
        },
        `Analyze this image and identify the recyclable material. 
Categories: plastic, paper, glass, metal, ewaste, batteries, cooking_oil, textiles, appliances, organic, special_waste
Provide the category, subcategory (e.g., "PET bottles"), confidence (0-1), whether it's recyclable, and tips for proper disposal.`,
      ],
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Image analysis error:", error);
    return {
      category: "unknown",
      subcategory: "unknown",
      confidence: 0,
      recyclable: false,
      tips: "Unable to analyze image. Please try again or manually select the category.",
    };
  }
}
