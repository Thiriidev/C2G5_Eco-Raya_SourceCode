import { HfInference } from "@huggingface/inference";

const hf = new HfInference(process.env.HUGGINGFACE_API_KEY || "");

export interface ClassificationResult {
  label: string;
  score: number;
}

export async function classifyImage(imageBuffer: Buffer): Promise<ClassificationResult[]> {
  try {
    const results = await hf.imageClassification({
      data: new Blob([imageBuffer]),
      model: "google/vit-base-patch16-224",
    });

    return results.map((r) => ({
      label: r.label,
      score: r.score,
    }));
  } catch (error) {
    console.error("HuggingFace classification error:", error);
    throw new Error(`Image classification failed: ${error}`);
  }
}

const RECYCLABLE_KEYWORDS: Record<string, string[]> = {
  plastic: ["bottle", "plastic", "container", "pet", "hdpe", "packaging", "wrapper"],
  paper: ["paper", "cardboard", "newspaper", "magazine", "book", "carton", "box"],
  glass: ["glass", "bottle", "jar", "window"],
  metal: ["can", "aluminum", "steel", "tin", "metal", "foil"],
  ewaste: ["phone", "computer", "laptop", "electronic", "device", "cable", "circuit"],
  batteries: ["battery", "cell", "power bank"],
  cooking_oil: ["oil", "cooking", "frying", "kitchen"],
  textiles: ["clothes", "fabric", "shirt", "pants", "dress", "textile", "cloth"],
  appliances: ["appliance", "refrigerator", "washing", "microwave", "oven", "fan"],
  organic: ["food", "vegetable", "fruit", "plant", "compost", "garden"],
  special_waste: ["chemical", "paint", "solvent", "hazardous", "toxic"],
};

export function mapToRecyclableCategory(classifications: ClassificationResult[]): {
  category: string;
  confidence: number;
  originalLabel: string;
} {
  for (const result of classifications) {
    const lowerLabel = result.label.toLowerCase();
    
    for (const [category, keywords] of Object.entries(RECYCLABLE_KEYWORDS)) {
      if (keywords.some((keyword) => lowerLabel.includes(keyword))) {
        return {
          category,
          confidence: result.score,
          originalLabel: result.label,
        };
      }
    }
  }

  return {
    category: "unknown",
    confidence: 0,
    originalLabel: classifications[0]?.label || "unknown",
  };
}

export async function classifyRecyclable(imageBuffer: Buffer): Promise<{
  category: string;
  subcategory: string;
  confidence: number;
  allClassifications: ClassificationResult[];
}> {
  const classifications = await classifyImage(imageBuffer);
  const mapped = mapToRecyclableCategory(classifications);

  return {
    category: mapped.category,
    subcategory: mapped.originalLabel,
    confidence: mapped.confidence,
    allClassifications: classifications.slice(0, 5),
  };
}
