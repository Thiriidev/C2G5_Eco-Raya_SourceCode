import { db } from "./db";
import { users, partners, stations, devices, households, collections, payouts, fraudCases, esgMetrics, aiInsights, recyclableItems, reports } from "@shared/schema";

async function seedDatabase() {
  console.log("🌱 Seeding database...");

  try {
    await db.delete(reports);
    await db.delete(recyclableItems);
    await db.delete(aiInsights);
    await db.delete(esgMetrics);
    await db.delete(fraudCases);
    await db.delete(payouts);
    await db.delete(collections);
    await db.delete(households);
    await db.delete(devices);
    await db.delete(stations);
    await db.delete(partners);
    await db.delete(users);

    const [aucoPartner] = await db.insert(partners).values([
      {
        name: "AUCO Sdn Bhd",
        contact: "+6012-345-6789",
        email: "contact@auco.com.my",
        regions: ["Klang Valley", "Selangor", "Kuala Lumpur"],
        status: "active",
      }
    ]).returning();

    const [jabatanUser, riderUser, rakyatUser1, rakyatUser2] = await db.insert(users).values([
      {
        username: "admin",
        password: "password123",
        name: "Ahmad Rahman",
        email: "ahmad@jabatan.gov.my",
        phone: "+60123456789",
        role: "jabatan",
        partnerId: null,
      },
      {
        username: "rider1",
        password: "rider123",
        name: "Muhammad Ali",
        email: "ali@ecorider.com",
        phone: "+60198765432",
        role: "ecorider",
        partnerId: aucoPartner.id,
      },
      {
        username: "rakyat1",
        password: "rakyat123",
        name: "Siti Aminah",
        email: "siti@gmail.com",
        phone: "+60112223333",
        role: "ecorakyat",
        partnerId: null,
      },
      {
        username: "rakyat2",
        password: "rakyat123",
        name: "Lee Wei Ming",
        email: "weiming@gmail.com",
        phone: "+60114445555",
        role: "ecorakyat",
        partnerId: null,
      }
    ]).returning();

    const [station1, station2] = await db.insert(stations).values([
      {
        name: "Pusat Kitar Semula Klang",
        address: "Jalan Tengku Kelana, Klang, Selangor",
        latitude: "3.0444",
        longitude: "101.4457",
        partnerId: aucoPartner.id,
        hours: "8:00 AM - 6:00 PM",
        status: "active",
      },
      {
        name: "EcoHub Petaling Jaya",
        address: "SS2, Petaling Jaya, Selangor",
        latitude: "3.1179",
        longitude: "101.6291",
        partnerId: aucoPartner.id,
        hours: "9:00 AM - 5:00 PM",
        status: "active",
      }
    ]).returning();

    await db.insert(devices).values([
      {
        stationId: station1.id,
        type: "ble_scale",
        serialNumber: "BLE-SCALE-001",
        firmware: "v2.1.3",
        status: "active",
        batteryLevel: 85,
        lastSync: new Date(),
      },
      {
        stationId: station2.id,
        type: "ble_scale",
        serialNumber: "BLE-SCALE-002",
        firmware: "v2.1.3",
        status: "active",
        batteryLevel: 92,
        lastSync: new Date(),
      }
    ]);

    await db.insert(households).values([
      {
        phone: "+60123456789",
        name: "Ahmad Rahman",
        email: "ahmad@example.com",
        consentFlags: { dataCollection: true, marketing: false },
        totalKg: "12.5",
        totalPoints: 250,
      },
      {
        phone: "+60198765432",
        name: "Siti Aminah",
        email: "siti@example.com",
        consentFlags: { dataCollection: true, marketing: true },
        totalKg: "8.3",
        totalPoints: 166,
      }
    ]);

    await db.insert(recyclableItems).values([
      {
        userId: rakyatUser1.id,
        category: "plastic",
        subcategory: "PET bottles",
        description: "10 botol air mineral",
        weightEstimateKg: "2.5",
        latitude: "3.1390",
        longitude: "101.6869",
        address: "Taman Tun Dr Ismail, KL",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser1.id,
        category: "paper",
        subcategory: "Cardboard",
        description: "Kotak Amazon",
        weightEstimateKg: "1.5",
        latitude: "3.1320",
        longitude: "101.6750",
        address: "Bangsar, KL",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser1.id,
        category: "glass",
        subcategory: "Glass bottles",
        description: "Botol kaca selai dan minuman",
        weightEstimateKg: "3.2",
        latitude: "3.1415",
        longitude: "101.6832",
        address: "Bukit Damansara, KL",
        status: "assigned",
        assignedRiderId: riderUser.id,
      },
      {
        userId: rakyatUser1.id,
        category: "metal",
        subcategory: "Aluminum cans",
        description: "Tin minuman kosong",
        weightEstimateKg: "1.8",
        latitude: "3.1289",
        longitude: "101.6781",
        address: "Mid Valley, KL",
        status: "collected",
        assignedRiderId: riderUser.id,
      },
      {
        userId: rakyatUser2.id,
        category: "cooking_oil",
        subcategory: "Used cooking oil",
        description: "Minyak goreng terpakai 5L",
        weightEstimateKg: "4.5",
        latitude: "3.0840",
        longitude: "101.6530",
        address: "Subang Jaya, Selangor",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser2.id,
        category: "ewaste",
        subcategory: "Old phone",
        description: "Telefon lama rosak",
        weightEstimateKg: "0.3",
        latitude: "3.1080",
        longitude: "101.6420",
        address: "SS15, Subang Jaya",
        status: "assigned",
        assignedRiderId: riderUser.id,
      },
      {
        userId: rakyatUser2.id,
        category: "batteries",
        subcategory: "AA batteries",
        description: "Bateri terpakai pelbagai saiz",
        weightEstimateKg: "0.5",
        latitude: "3.0920",
        longitude: "101.6380",
        address: "USJ 21, Subang Jaya",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser2.id,
        category: "textiles",
        subcategory: "Old clothes",
        description: "Baju dan seluar lama",
        weightEstimateKg: "5.0",
        latitude: "3.1050",
        longitude: "101.6550",
        address: "SS18, Subang Jaya",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser1.id,
        category: "appliances",
        subcategory: "Old fan",
        description: "Kipas lama rosak",
        weightEstimateKg: "4.0",
        latitude: "3.1356",
        longitude: "101.6912",
        address: "TTDI, KL",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser2.id,
        category: "organic",
        subcategory: "Food waste",
        description: "Sisa sayuran dan buah",
        weightEstimateKg: "2.0",
        latitude: "3.0780",
        longitude: "101.6480",
        address: "Putra Heights, Subang",
        status: "collected",
        assignedRiderId: riderUser.id,
      },
      {
        userId: rakyatUser1.id,
        category: "plastic",
        subcategory: "HDPE containers",
        description: "Bekas syampu dan sabun cecair",
        weightEstimateKg: "1.2",
        latitude: "3.1425",
        longitude: "101.6795",
        address: "Sri Hartamas, KL",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser2.id,
        category: "paper",
        subcategory: "Newspapers",
        description: "Suratkhabar lama sebulan",
        weightEstimateKg: "3.5",
        latitude: "3.0890",
        longitude: "101.6620",
        address: "USJ 6, Subang Jaya",
        status: "new",
        assignedRiderId: null,
      },
    ]);

    await db.insert(reports).values([
      {
        userId: rakyatUser1.id,
        title: "Sampah bertimbun di lorong",
        description: "Terdapat sampah yang bertimbun di lorong belakang restoran. Berbau busuk dan ada tikus.",
        latitude: "3.1450",
        longitude: "101.7100",
        address: "Lorong Ampang, KL",
        severity: "high",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser2.id,
        title: "Pembuangan haram di tepi sungai",
        description: "Seseorang membuang sampah di tepi sungai. Saya ada gambar bukti.",
        latitude: "3.0950",
        longitude: "101.6800",
        address: "Sungai Klang, Petaling",
        severity: "medium",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser1.id,
        title: "Tong sampah penuh tidak dikutip",
        description: "Tong sampah kitar semula di taman telah penuh lebih seminggu. Perlu dikutip segera.",
        latitude: "3.1380",
        longitude: "101.6895",
        address: "Taman Tun Dr Ismail, KL",
        severity: "medium",
        status: "assigned",
        assignedRiderId: riderUser.id,
      },
      {
        userId: rakyatUser2.id,
        title: "Barang elektrik dibuang merata",
        description: "Banyak barang elektrik rosak dibuang di tepi jalan. Perlu dibersihkan.",
        latitude: "3.1020",
        longitude: "101.6450",
        address: "SS17, Subang Jaya",
        severity: "low",
        status: "new",
        assignedRiderId: null,
      },
      {
        userId: rakyatUser1.id,
        title: "Minyak masak terpakai tumpah",
        description: "Ada tumpahan minyak masak di tempat letak kereta. Licin dan berbahaya.",
        latitude: "3.1295",
        longitude: "101.6742",
        address: "Bangsar South, KL",
        severity: "high",
        status: "resolved",
        assignedRiderId: riderUser.id,
      },
    ]);

    await db.insert(esgMetrics).values([
      {
        period: "monthly",
        startDate: new Date("2024-07-01"),
        endDate: new Date("2024-07-31"),
        kgTotal: "1247.5",
        householdsServed: 342,
        co2Saved: "3742.5",
        revenueGenerated: "186420.00",
        reportUrl: null,
      }
    ]);

    await db.insert(aiInsights).values([
      {
        type: "optimization",
        title: "Cadangan kutipan hujung minggu",
        description: "Data menunjukkan 23% permintaan lebih tinggi pada hujung minggu. Pertimbangkan penambahan kutipan Sabtu.",
        confidence: "0.87",
        metadata: { region: "Klang Valley", impact: "high" },
        status: "active",
      },
      {
        type: "anomaly",
        title: "Penurunan kutipan dikesan",
        description: "Stesen KL-03 menunjukkan penurunan 40% dalam kutipan. Siasat potensi isu.",
        confidence: "0.94",
        metadata: { stationId: "KL-03", severity: "medium" },
        status: "active",
      },
      {
        type: "prediction",
        title: "Jangkaan peningkatan Hari Raya",
        description: "Dijangka peningkatan 35% kutipan minyak masak sempena Hari Raya Aidilfitri.",
        confidence: "0.91",
        metadata: { period: "Raya", category: "cooking_oil" },
        status: "active",
      }
    ]);

    console.log("✅ Database seeded successfully!");
    console.log("👤 Users created:");
    console.log("   - admin / password123 (Jabatan)");
    console.log("   - rider1 / rider123 (EcoRider)");
    console.log("   - rakyat1 / rakyat123 (EcoRakyat)");
    console.log("   - rakyat2 / rakyat123 (EcoRakyat)");
    
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { seedDatabase };
