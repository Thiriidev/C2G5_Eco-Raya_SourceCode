import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPartnerSchema, insertStationSchema, insertDeviceSchema, insertCollectionSchema, insertPayoutSchema, insertFraudCaseSchema, insertAiInsightSchema, insertRecyclableItemSchema, insertReportSchema, insertRoutePlanSchema, insertRouteEventSchema } from "@shared/schema";
import { z } from "zod";
import { getRecyclingAdvice, getRiderAssistance, optimizeRoute, analyzeRecyclableImage, optimizeRouteWithCategories, analyzeImageWithQuestions } from "./lib/gemini";
import { CATEGORIES, CATEGORY_CONSTRAINTS, REWARD_RATES } from "@shared/schema";
import { requireAuth, requireRole } from "./lib/auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      req.session.userRole = user.role;

      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    const { password: _, ...userWithoutPassword } = user;
    res.json({ user: userWithoutPassword });
  });

  // Users - Admin only
  app.get("/api/users", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const users = await storage.getUser(1);
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Partners - Admin only
  app.get("/api/partners", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const partners = await storage.getPartners();
      res.json(partners);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch partners" });
    }
  });

  app.post("/api/partners", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const validatedData = insertPartnerSchema.parse(req.body);
      const partner = await storage.createPartner(validatedData);
      res.json(partner);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create partner" });
    }
  });

  // Stations - Admin and EcoRider can view
  app.get("/api/stations", requireAuth, async (req, res) => {
    try {
      const stations = await storage.getStations();
      res.json(stations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stations" });
    }
  });

  app.post("/api/stations", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const validatedData = insertStationSchema.parse(req.body);
      const station = await storage.createStation(validatedData);
      res.json(station);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create station" });
    }
  });

  // Devices - Admin and EcoRider can view
  app.get("/api/devices", requireAuth, async (req, res) => {
    try {
      const devices = await storage.getDevices();
      res.json(devices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch devices" });
    }
  });

  app.post("/api/devices", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const validatedData = insertDeviceSchema.parse(req.body);
      const device = await storage.createDevice(validatedData);
      res.json(device);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create device" });
    }
  });

  // Collections - Admin and EcoRider can access
  app.get("/api/collections", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const collections = await storage.getCollections();
      res.json(collections);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch collections" });
    }
  });

  app.post("/api/collections", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const validatedData = insertCollectionSchema.parse(req.body);
      const collection = await storage.createCollection(validatedData);
      res.json(collection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create collection" });
    }
  });

  // Payouts - Admin only
  app.get("/api/payouts", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const payouts = await storage.getPayouts();
      res.json(payouts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payouts" });
    }
  });

  app.post("/api/payouts", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const validatedData = insertPayoutSchema.parse(req.body);
      const payout = await storage.createPayout(validatedData);
      res.json(payout);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create payout" });
    }
  });

  // Fraud Cases - Admin only
  app.get("/api/fraud-cases", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const fraudCases = await storage.getFraudCases();
      res.json(fraudCases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fraud cases" });
    }
  });

  app.post("/api/fraud-cases", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const validatedData = insertFraudCaseSchema.parse(req.body);
      const fraudCase = await storage.createFraudCase(validatedData);
      res.json(fraudCase);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create fraud case" });
    }
  });

  // AI Insights - All authenticated users can view
  app.get("/api/ai-insights", requireAuth, async (req, res) => {
    try {
      const insights = await storage.getAiInsights();
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch AI insights" });
    }
  });

  app.post("/api/ai-insights", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const validatedData = insertAiInsightSchema.parse(req.body);
      const insight = await storage.createAiInsight(validatedData);
      res.json(insight);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create AI insight" });
    }
  });

  // Dashboard metrics - Admin only
  app.get("/api/dashboard/metrics", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const collections = await storage.getCollections();
      const households = await storage.getHouseholds();
      
      const totalOil = 24567;
      const householdsServed = 8423;
      const co2Saved = 73.7;
      const revenue = 186420;

      res.json({
        totalOil,
        householdsServed,
        co2Saved,
        revenue,
        collections: collections.length,
        households: households.length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Collection trends for chart - Admin only
  app.get("/api/dashboard/collection-trends", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const trends = [
        { day: "Mon", kg: 1200 },
        { day: "Tue", kg: 1350 },
        { day: "Wed", kg: 1100 },
        { day: "Thu", kg: 1450 },
        { day: "Fri", kg: 1600 },
        { day: "Sat", kg: 1800 },
        { day: "Sun", kg: 1300 },
      ];
      res.json(trends);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch collection trends" });
    }
  });

  // Report stats for PDF generation - Jabatan only
  app.get("/api/jabatan/report-stats", requireRole("jabatan", "admin"), async (req, res) => {
    try {
      const allItems = await storage.getRecyclableItems();
      const allReports = await storage.getReports();
      
      const totalItems = allItems.length;
      const totalWeight = allItems.reduce((sum, item) => sum + (Number(item.weightEstimateKg) || 0), 0);
      const totalReports = allReports.length;
      
      const categoryBreakdown: Record<string, { count: number; weight: number }> = {};
      allItems.forEach(item => {
        const cat = item.category || 'unknown';
        if (!categoryBreakdown[cat]) {
          categoryBreakdown[cat] = { count: 0, weight: 0 };
        }
        categoryBreakdown[cat].count++;
        categoryBreakdown[cat].weight += Number(item.weightEstimateKg) || 0;
      });
      
      const statusBreakdown: Record<string, number> = {};
      allItems.forEach(item => {
        const status = item.status || 'unknown';
        statusBreakdown[status] = (statusBreakdown[status] || 0) + 1;
      });
      
      const recentItems = allItems
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 20)
        .map(item => ({
          id: item.id,
          category: item.category,
          weight_estimate_kg: Number(item.weightEstimateKg) || 0,
          address: item.address,
          status: item.status,
          created_at: item.createdAt,
        }));
      
      const recentReports = allReports
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, 20)
        .map(report => ({
          id: report.id,
          title: report.title,
          severity: report.severity,
          status: report.status,
          address: report.address,
          created_at: report.createdAt,
        }));
      
      res.json({
        totalItems,
        totalWeight,
        totalReports,
        categoryBreakdown,
        statusBreakdown,
        recentItems,
        recentReports,
      });
    } catch (error) {
      console.error("Report stats error:", error);
      res.status(500).json({ message: "Failed to fetch report stats" });
    }
  });

  // =============================================
  // RECYCLABLE ITEMS (EcoRakyat submissions)
  // =============================================
  
  app.get("/api/recyclable-items", requireAuth, async (req, res) => {
    try {
      const { status, userId, riderId } = req.query;
      let items;
      
      if (status) {
        items = await storage.getRecyclableItemsByStatus(status as string);
      } else if (userId) {
        items = await storage.getRecyclableItemsByUser(Number(userId));
      } else if (riderId) {
        items = await storage.getRecyclableItemsByRider(Number(riderId));
      } else {
        items = await storage.getRecyclableItems();
      }
      
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recyclable items" });
    }
  });

  app.get("/api/recyclable-items/:id", requireAuth, async (req, res) => {
    try {
      const item = await storage.getRecyclableItem(Number(req.params.id));
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch item" });
    }
  });

  app.post("/api/recyclable-items", requireAuth, async (req, res) => {
    try {
      console.log("Creating recyclable item with data:", JSON.stringify(req.body, null, 2));
      const validatedData = insertRecyclableItemSchema.parse(req.body);
      const item = await storage.createRecyclableItem(validatedData);
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.log("Validation errors:", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating item:", error);
      res.status(500).json({ message: "Failed to create item" });
    }
  });

  app.patch("/api/recyclable-items/:id", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const item = await storage.updateRecyclableItem(Number(req.params.id), req.body);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to update item" });
    }
  });

  // =============================================
  // REPORTS (illegal dumping, issues)
  // =============================================
  
  app.get("/api/reports", requireAuth, async (req, res) => {
    try {
      const { status, userId, riderId } = req.query;
      let reportsList;
      
      if (status) {
        reportsList = await storage.getReportsByStatus(status as string);
      } else if (userId) {
        reportsList = await storage.getReportsByUser(Number(userId));
      } else if (riderId) {
        reportsList = await storage.getReportsByRider(Number(riderId));
      } else {
        reportsList = await storage.getReports();
      }
      
      res.json(reportsList);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });

  app.get("/api/reports/:id", requireAuth, async (req, res) => {
    try {
      const report = await storage.getReport(Number(req.params.id));
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch report" });
    }
  });

  app.post("/api/reports", requireAuth, async (req, res) => {
    try {
      const validatedData = insertReportSchema.parse(req.body);
      const report = await storage.createReport(validatedData);
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create report" });
    }
  });

  app.patch("/api/reports/:id", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const report = await storage.updateReport(Number(req.params.id), req.body);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to update report" });
    }
  });

  // =============================================
  // ROUTE PLANS (EcoRider routes)
  // =============================================
  
  app.get("/api/route-plans", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const { riderId } = req.query;
      let plans;
      
      if (riderId) {
        plans = await storage.getRoutePlansByRider(Number(riderId));
      } else {
        plans = await storage.getRoutePlans();
      }
      
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch route plans" });
    }
  });

  app.get("/api/route-plans/:id", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const plan = await storage.getRoutePlan(Number(req.params.id));
      if (!plan) {
        return res.status(404).json({ message: "Route plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch route plan" });
    }
  });

  app.get("/api/route-plans/:id/events", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const events = await storage.getRouteEventsByPlan(Number(req.params.id));
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch route events" });
    }
  });

  app.post("/api/route-plans", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const validatedData = insertRoutePlanSchema.parse(req.body);
      const plan = await storage.createRoutePlan(validatedData);
      res.json(plan);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create route plan" });
    }
  });

  app.patch("/api/route-plans/:id", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const plan = await storage.updateRoutePlan(Number(req.params.id), req.body);
      if (!plan) {
        return res.status(404).json({ message: "Route plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to update route plan" });
    }
  });

  app.post("/api/route-events", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const validatedData = insertRouteEventSchema.parse(req.body);
      const event = await storage.createRouteEvent(validatedData);
      res.json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create route event" });
    }
  });

  app.patch("/api/route-events/:id", requireRole("jabatan", "admin", "ecorider", "collector"), async (req, res) => {
    try {
      const event = await storage.updateRouteEvent(Number(req.params.id), req.body);
      if (!event) {
        return res.status(404).json({ message: "Route event not found" });
      }
      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to update route event" });
    }
  });

  // =============================================
  // REWARDS & VOUCHERS
  // =============================================

  app.get("/api/rewards/summary", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({
        totalPoints: user.totalPoints || 0,
        totalCashback: parseFloat(user.totalCashback?.toString() || "0"),
        lifetimePoints: user.lifetimePoints || 0,
        lifetimeCashback: parseFloat(user.lifetimeCashback?.toString() || "0"),
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rewards summary" });
    }
  });

  app.get("/api/rewards/transactions", requireAuth, async (req, res) => {
    try {
      const transactions = await storage.getRewardTransactions(req.session.userId!);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reward transactions" });
    }
  });

  app.get("/api/vouchers", requireAuth, async (req, res) => {
    try {
      const activeVouchers = await storage.getActiveVouchers();
      res.json(activeVouchers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vouchers" });
    }
  });

  app.get("/api/vouchers/my", requireAuth, async (req, res) => {
    try {
      const userVouchers = await storage.getUserVouchers(req.session.userId!);
      res.json(userVouchers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user vouchers" });
    }
  });

  app.post("/api/vouchers/:id/redeem", requireAuth, async (req, res) => {
    try {
      const voucherId = Number(req.params.id);
      const voucher = await storage.getVoucher(voucherId);
      
      if (!voucher || !voucher.isActive) {
        return res.status(404).json({ message: "Voucher not found or inactive" });
      }

      const user = await storage.getUser(req.session.userId!);
      if (!user || (user.totalPoints || 0) < voucher.pointsCost) {
        return res.status(400).json({ message: "Insufficient points" });
      }

      const redemptionCode = `ECO${Date.now().toString(36).toUpperCase()}`;
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + 3);

      const userVoucher = await storage.createUserVoucher({
        userId: req.session.userId!,
        voucherId,
        code: redemptionCode,
        status: "active",
        expiresAt,
      });

      await storage.updateVoucher(voucherId, {
        currentRedemptions: (voucher.currentRedemptions || 0) + 1,
      });

      const newPoints = (user.totalPoints || 0) - voucher.pointsCost;
      await storage.updateUser(req.session.userId!, { totalPoints: newPoints });

      await storage.createRewardTransaction({
        userId: req.session.userId!,
        type: "redeemed",
        points: -voucher.pointsCost,
        description: `Redeemed ${voucher.name}`,
        voucherId,
      });

      res.json({ userVoucher, redemptionCode });
    } catch (error) {
      console.error("Voucher redemption error:", error);
      res.status(500).json({ message: "Failed to redeem voucher" });
    }
  });

  app.post("/api/rewards/credit", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { itemId, rewardType, actualWeightKg } = req.body;
      
      const item = await storage.getRecyclableItem(itemId);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      if (item.rewardCredited) {
        return res.status(400).json({ message: "Reward already credited" });
      }

      const weight = actualWeightKg || parseFloat(item.weightEstimateKg?.toString() || "0");
      const rates = REWARD_RATES[item.category] || { pointsPerKg: 30, cashbackPerKg: 0.20 };
      
      const pointsEarned = Math.round(weight * rates.pointsPerKg);
      const cashbackEarned = parseFloat((weight * rates.cashbackPerKg).toFixed(2));

      await storage.updateRecyclableItem(itemId, {
        actualWeightKg: weight.toString(),
        pointsEarned,
        cashbackEarned: cashbackEarned.toString(),
        rewardType,
        rewardCredited: true,
        status: "collected",
        collectedAt: new Date(),
      });

      if (rewardType === "points") {
        await storage.creditUserReward(item.userId, pointsEarned, 0);
        await storage.createRewardTransaction({
          userId: item.userId,
          type: "earned",
          points: pointsEarned,
          description: `Earned from recycling ${item.category} (${weight}kg)`,
          recyclableItemId: itemId,
        });
      } else if (rewardType === "cashback") {
        await storage.creditUserReward(item.userId, 0, cashbackEarned);
        await storage.createRewardTransaction({
          userId: item.userId,
          type: "cashback",
          cashback: cashbackEarned.toString(),
          description: `Cashback from recycling ${item.category} (${weight}kg)`,
          recyclableItemId: itemId,
        });
      }

      res.json({
        pointsEarned,
        cashbackEarned,
        rewardType,
        category: item.category,
        weight,
      });
    } catch (error) {
      console.error("Credit reward error:", error);
      res.status(500).json({ message: "Failed to credit reward" });
    }
  });

  app.get("/api/rewards/rates", requireAuth, async (req, res) => {
    res.json(REWARD_RATES);
  });

  // =============================================
  // AI FEATURES
  // =============================================

  // Recycling centres in Klang Valley, Malaysia
  const RECYCLING_CENTRES = [
    { name: "IPC Recycling & Buy Back Centre", lat: 3.1149, lng: 101.6157, address: "Mutiara Damansara, 47810 Petaling Jaya" },
    { name: "Alam Flora Recycling Centre", lat: 3.0833, lng: 101.5500, address: "Jalan SS7/26, Kelana Jaya, 47301 PJ" },
    { name: "Kajang Recycling Centre", lat: 2.9927, lng: 101.7909, address: "Jalan Reko, 43000 Kajang, Selangor" },
    { name: "Shah Alam Recycling Hub", lat: 3.0733, lng: 101.5185, address: "Seksyen 16, 40200 Shah Alam" },
    { name: "TTDI Recycling Centre", lat: 3.1300, lng: 101.6300, address: "Taman Tun Dr Ismail, 60000 KL" },
    { name: "Bandar Utama Recycling Point", lat: 3.1380, lng: 101.6050, address: "BU 10, Bandar Utama, 47800 PJ" },
    { name: "Subang Jaya E-Waste Centre", lat: 3.0475, lng: 101.5842, address: "SS18, Subang Jaya, 47500 Selangor" },
    { name: "Ampang Recycling Station", lat: 3.1500, lng: 101.7600, address: "Jalan Ampang, 68000 Ampang" },
    { name: "Setapak Recycling Centre", lat: 3.1817, lng: 101.7100, address: "Jalan Genting Klang, 53300 KL" },
    { name: "Cheras Community Recycling", lat: 3.1019, lng: 101.7500, address: "Taman Connaught, 56000 Cheras" },
    { name: "Puchong Green Collection", lat: 3.0200, lng: 101.6200, address: "Bandar Puteri Puchong, 47100 Puchong" },
    { name: "Kepong Recycling Hub", lat: 3.2150, lng: 101.6350, address: "Jalan Kepong, 52100 KL" },
  ];

  function haversineDistanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  function detectRecyclingCentreQuery(message: string): boolean {
    const keywords = [
      'recycling centre', 'recycling center', 'recycle centre', 'recycle center',
      'pusat kitar semula', 'pusat kitar', 'pusat recycle',
      'nearby', 'dekat', 'berdekatan', 'terdekat',
      'where can i recycle', 'di mana boleh kitar',
      'drop off', 'collection point', 'tempat kitar', 'tempat buang',
      'recycling location', 'lokasi kitar semula'
    ];
    const lowerMsg = message.toLowerCase();
    return keywords.some(kw => lowerMsg.includes(kw));
  }

  app.post("/api/ai/recycling-advice", requireRole("ecorakyat"), async (req, res) => {
    try {
      const { message, imageBase64, language = "ms", conversationHistory = [], userLocation } = req.body;
      
      // Check if user is asking about nearby recycling centres
      if (detectRecyclingCentreQuery(message)) {
        // Use provided location or default to KL city center
        const location = (userLocation?.lat && userLocation?.lng) 
          ? userLocation 
          : { lat: 3.1390, lng: 101.6869 }; // Default: Kuala Lumpur city center
        
        const centresWithDistance = RECYCLING_CENTRES.map(centre => ({
          ...centre,
          distanceKm: haversineDistanceKm(location.lat, location.lng, centre.lat, centre.lng)
        })).sort((a, b) => a.distanceKm - b.distanceKm);
        
        const nearest3 = centresWithDistance.slice(0, 3);
        
        const locationNote = (userLocation?.lat && userLocation?.lng)
          ? ""
          : (language === "en" 
              ? "\n\n*Note: Using Kuala Lumpur city center as reference. Enable location for more accurate results.*" 
              : "\n\n*Nota: Menggunakan pusat bandar Kuala Lumpur sebagai rujukan. Aktifkan lokasi untuk hasil yang lebih tepat.*");
        
        const responseText = language === "en" 
          ? `Here are the 3 nearest recycling centres:\n\n` +
            nearest3.map((c, i) => `${i+1}. **${c.name}**\n   📍 ${c.address}\n   📏 ${c.distanceKm.toFixed(1)} km`).join('\n\n') + locationNote
          : `Berikut adalah 3 pusat kitar semula terdekat:\n\n` +
            nearest3.map((c, i) => `${i+1}. **${c.name}**\n   📍 ${c.address}\n   📏 ${c.distanceKm.toFixed(1)} km`).join('\n\n') + locationNote;
        
        return res.json({ 
          response: responseText,
          recyclingCentres: nearest3.map(c => ({
            name: c.name,
            address: c.address,
            lat: c.lat,
            lng: c.lng,
            distanceKm: Math.round(c.distanceKm * 10) / 10
          }))
        });
      }
      
      if (imageBase64 || conversationHistory.some((msg: any) => msg.hasImage)) {
        const advice = await analyzeImageWithQuestions(imageBase64 || "", message, conversationHistory, language);
        res.json({ response: advice, hasImage: !!imageBase64 });
      } else {
        const advice = await getRecyclingAdvice(message, undefined, language);
        res.json({ response: advice });
      }
    } catch (error) {
      console.error("AI advice error:", error);
      res.status(500).json({ message: "Failed to get AI advice" });
    }
  });

  app.post("/api/ai/rider-assistance", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { query } = req.body;
      const assistance = await getRiderAssistance(query);
      res.json({ response: assistance });
    } catch (error) {
      console.error("AI assistance error:", error);
      res.status(500).json({ message: "Failed to get AI assistance" });
    }
  });

  app.post("/api/ai/chat", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { message, context, language = "ms" } = req.body;
      const assistance = await getRiderAssistance(message);
      res.json({ reply: assistance });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ message: "Failed to get AI response" });
    }
  });

  app.post("/api/ai/optimize-route", requireRole("ecorider", "collector", "jabatan", "admin"), async (req, res) => {
    try {
      const { waypoints } = req.body;
      const optimization = await optimizeRoute(waypoints);
      res.json(optimization);
    } catch (error) {
      console.error("Route optimization error:", error);
      res.status(500).json({ message: "Failed to optimize route" });
    }
  });

  app.post("/api/ai/classify-image", requireAuth, async (req, res) => {
    try {
      const { imageBase64 } = req.body;
      const classification = await analyzeRecyclableImage(imageBase64);
      res.json(classification);
    } catch (error) {
      console.error("Image classification error:", error);
      res.status(500).json({ message: "Failed to classify image" });
    }
  });

  // =============================================
  // AI-POWERED ROUTE OPTIMIZATION
  // =============================================

  app.post("/api/routes/optimize", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { 
        riderName,
        truckCapacityKg, 
        selectedCategory,
        selectedCategories,
        restrictedCategories = [],
        truckLocation,
        language = "ms"
      } = req.body;

      if (!truckLocation || !truckLocation.lat || !truckLocation.lng) {
        return res.status(400).json({ message: "Truck location is required" });
      }

      const categories: string[] = selectedCategories && Array.isArray(selectedCategories) && selectedCategories.length > 0
        ? selectedCategories.filter((c: string) => CATEGORIES.includes(c as any))
        : (selectedCategory && CATEGORIES.includes(selectedCategory as any) ? [selectedCategory] : []);

      if (categories.length === 0) {
        return res.status(400).json({ message: "At least one valid category is required" });
      }

      const riderId = req.session.userId!;
      
      const existingPlan = await storage.getActiveRoutePlanByRider(riderId);
      if (existingPlan) {
        await storage.clearItemRouteStatus(existingPlan.id);
        await storage.updateRoutePlan(existingPlan.id, { status: "cancelled" });
      }

      const allItems = await storage.getRecyclableItemsByStatus("new");
      
      const routeItems = allItems.map(item => ({
        id: item.id,
        lat: parseFloat(item.latitude?.toString() || "0"),
        lng: parseFloat(item.longitude?.toString() || "0"),
        address: item.address || undefined,
        category: item.category,
        weightKg: parseFloat(item.weightEstimateKg?.toString() || "0")
      }));

      const optimization = await optimizeRouteWithCategories(
        truckLocation,
        routeItems,
        categories,
        restrictedCategories,
        truckCapacityKg,
        language
      );

      const routePlan = await storage.createRoutePlan({
        riderId,
        riderName: riderName || "EcoRider",
        date: new Date(),
        status: "in_progress",
        selectedCategory: categories[0],
        selectedCategories: categories,
        restrictedCategories,
        truckCapacityKg: truckCapacityKg.toString(),
        startLatitude: truckLocation.lat.toString(),
        startLongitude: truckLocation.lng.toString(),
        totalDistanceKm: optimization.totalDistanceKm.toString(),
        estimatedDurationMin: optimization.estimatedDurationMin,
        aiSummary: optimization.aiSummary,
        waypoints: optimization.waypoints,
        optimizationMeta: {
          onRouteCount: optimization.onRouteItems.length,
          offRouteCount: optimization.offRouteItems.length,
          wrongCategoryCount: optimization.wrongCategoryItems.length,
          petrolConsumedL: optimization.petrolConsumedL,
          petrolSavedL: optimization.petrolSavedL,
          co2SavedKg: optimization.co2SavedKg,
          baselineDistanceKm: optimization.baselineDistanceKm
        }
      });

      const onRouteIds = optimization.onRouteItems.map(i => i.id);
      const sequences = optimization.onRouteItems.map(i => i.sequence);
      if (onRouteIds.length > 0) {
        await storage.bulkUpdateItemRouteStatus(onRouteIds, routePlan.id, "on_route", sequences);
      }

      const offRouteIds = optimization.offRouteItems.map(i => i.id);
      if (offRouteIds.length > 0) {
        await storage.bulkUpdateItemRouteStatus(offRouteIds, routePlan.id, "off_route");
      }

      const wrongCategoryIds = optimization.wrongCategoryItems.map(i => i.id);
      if (wrongCategoryIds.length > 0) {
        await storage.bulkUpdateItemRouteStatus(wrongCategoryIds, routePlan.id, "wrong_category");
      }

      res.json({
        routePlan,
        optimization,
        categoryConstraints: categories.flatMap(c => CATEGORY_CONSTRAINTS[c] || [])
      });
    } catch (error) {
      console.error("Route optimization error:", error);
      res.status(500).json({ message: "Failed to optimize route" });
    }
  });

  app.get("/api/routes/active", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const riderId = req.session.userId!;
      const plan = await storage.getActiveRoutePlanByRider(riderId);
      
      if (!plan) {
        return res.json({ active: false, plan: null, items: [] });
      }

      const items = await storage.getItemsByRoutePlan(plan.id);
      
      const meta = plan.optimizationMeta as any || {};
      
      res.json({ 
        active: true, 
        plan: {
          ...plan,
          petrolConsumedL: meta.petrolConsumedL || 0,
          petrolSavedL: meta.petrolSavedL || 0,
          co2SavedKg: meta.co2SavedKg || 0,
          baselineDistanceKm: meta.baselineDistanceKm || 0
        },
        items: items.map(item => ({
          ...item,
          lat: parseFloat(item.latitude?.toString() || "0"),
          lng: parseFloat(item.longitude?.toString() || "0"),
        }))
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active route" });
    }
  });

  app.patch("/api/routes/:planId/items/:itemId/complete", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { planId, itemId } = req.params;
      const { actualWeightKg } = req.body;

      const item = await storage.getRecyclableItem(Number(itemId));
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      const updatedItem = await storage.updateRecyclableItem(Number(itemId), {
        status: "collected",
        routeStatus: "completed"
      });

      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete item" });
    }
  });

  app.patch("/api/routes/:planId/items/:itemId/remove", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { itemId } = req.params;

      const item = await storage.updateRecyclableItem(Number(itemId), {
        routeStatus: "off_route",
        routeSequence: null
      });

      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to remove item from route" });
    }
  });

  app.patch("/api/routes/:planId/items/:itemId/add", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { planId, itemId } = req.params;
      const { sequence } = req.body;

      const item = await storage.updateRecyclableItem(Number(itemId), {
        routePlanId: Number(planId),
        routeStatus: "on_route",
        routeSequence: sequence
      });

      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to add item to route" });
    }
  });

  app.patch("/api/routes/:planId/end", requireRole("ecorider", "collector"), async (req, res) => {
    try {
      const { planId } = req.params;

      const plan = await storage.updateRoutePlan(Number(planId), {
        status: "completed"
      });

      if (!plan) {
        return res.status(404).json({ message: "Route plan not found" });
      }

      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to end route" });
    }
  });

  app.get("/api/categories", requireAuth, async (req, res) => {
    res.json({
      categories: CATEGORIES,
      constraints: CATEGORY_CONSTRAINTS
    });
  });

  // =============================================
  // ECORAKYAT DASHBOARD METRICS
  // =============================================

  app.get("/api/ecorakyat/stats/:userId", requireAuth, async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      
      if (req.session.userRole !== 'jabatan' && req.session.userRole !== 'admin' && req.session.userId !== userId) {
        return res.status(403).json({ message: "Access denied. You can only view your own stats." });
      }
      
      const items = await storage.getRecyclableItemsByUser(userId);
      const userReports = await storage.getReportsByUser(userId);
      
      const totalItems = items.length;
      const collectedItems = items.filter(i => i.status === "collected").length;
      const pendingItems = items.filter(i => i.status === "new" || i.status === "assigned").length;
      const totalWeight = items
        .filter(i => i.status === "collected")
        .reduce((sum, i) => sum + parseFloat(i.weightEstimateKg?.toString() || "0"), 0);
      const co2Saved = totalWeight * 3;
      
      res.json({
        totalItems,
        collectedItems,
        pendingItems,
        totalWeight,
        co2Saved,
        reportsSubmitted: userReports.length,
        reportsResolved: userReports.filter(r => r.status === "resolved").length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch EcoRakyat stats" });
    }
  });

  // =============================================
  // ECORIDER DASHBOARD METRICS
  // =============================================

  app.get("/api/ecorider/stats/:riderId", requireRole("ecorider", "collector", "jabatan", "admin"), async (req, res) => {
    try {
      const riderId = Number(req.params.riderId);
      const assignedItems = await storage.getRecyclableItemsByRider(riderId);
      const assignedReports = await storage.getReportsByRider(riderId);
      const routePlansData = await storage.getRoutePlansByRider(riderId);
      
      const pendingCollections = assignedItems.filter(i => i.status === "assigned" || i.status === "in_progress").length;
      const completedToday = assignedItems.filter(i => {
        if (i.status !== "collected" || !i.collectedAt) return false;
        const today = new Date();
        const collected = new Date(i.collectedAt);
        return collected.toDateString() === today.toDateString();
      }).length;
      
      const totalKgCollected = assignedItems
        .filter(i => i.status === "collected")
        .reduce((sum, i) => sum + parseFloat(i.weightEstimateKg?.toString() || "0"), 0);
      
      res.json({
        pendingCollections,
        completedToday,
        totalKgCollected,
        activeRoute: routePlansData.find(p => p.status === "in_progress") || null,
        pendingReports: assignedReports.filter(r => r.status === "assigned" || r.status === "in_progress").length,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch EcoRider stats" });
    }
  });

  // Get all pending items and reports for EcoRider map
  app.get("/api/ecorider/pending-pickups", requireRole("ecorider", "collector", "jabatan", "admin"), async (req, res) => {
    try {
      const pendingItems = await storage.getRecyclableItemsByStatus("new");
      const assignedItems = await storage.getRecyclableItemsByStatus("assigned");
      const pendingReports = await storage.getReportsByStatus("new");
      const assignedReports = await storage.getReportsByStatus("assigned");
      
      res.json({
        items: [...pendingItems, ...assignedItems],
        reports: [...pendingReports, ...assignedReports],
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pending pickups" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
