import {
  users, partners, stations, devices, households, collections, payouts, fraudCases, esgMetrics, aiInsights,
  recyclableItems, reports, routePlans, routeEvents, aiPrompts, vouchers, userVouchers, rewardTransactions,
  type User, type Partner, type Station, type Device, type Household, type Collection, type Payout, type FraudCase, type EsgMetric, type AiInsight,
  type RecyclableItem, type Report, type RoutePlan, type RouteEvent, type AiPrompt, type Voucher, type UserVoucher, type RewardTransaction,
  type InsertUser, type InsertPartner, type InsertStation, type InsertDevice, type InsertHousehold, type InsertCollection, type InsertPayout, type InsertFraudCase, type InsertEsgMetric, type InsertAiInsight,
  type InsertRecyclableItem, type InsertReport, type InsertRoutePlan, type InsertRouteEvent, type InsertAiPrompt, type InsertVoucher, type InsertUserVoucher, type InsertRewardTransaction
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Partners
  getPartners(): Promise<Partner[]>;
  getPartner(id: number): Promise<Partner | undefined>;
  createPartner(partner: InsertPartner): Promise<Partner>;
  updatePartner(id: number, partner: Partial<InsertPartner>): Promise<Partner | undefined>;
  
  // Stations
  getStations(): Promise<Station[]>;
  getStationsByPartner(partnerId: number): Promise<Station[]>;
  getStation(id: number): Promise<Station | undefined>;
  createStation(station: InsertStation): Promise<Station>;
  updateStation(id: number, station: Partial<InsertStation>): Promise<Station | undefined>;
  
  // Devices
  getDevices(): Promise<Device[]>;
  getDevicesByStation(stationId: number): Promise<Device[]>;
  getDevice(id: number): Promise<Device | undefined>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: number, device: Partial<InsertDevice>): Promise<Device | undefined>;
  
  // Households
  getHouseholds(): Promise<Household[]>;
  getHousehold(id: number): Promise<Household | undefined>;
  getHouseholdByPhone(phone: string): Promise<Household | undefined>;
  createHousehold(household: InsertHousehold): Promise<Household>;
  updateHousehold(id: number, household: Partial<InsertHousehold>): Promise<Household | undefined>;
  
  // Collections
  getCollections(): Promise<Collection[]>;
  getCollectionsByStation(stationId: number): Promise<Collection[]>;
  getCollectionsByCollector(collectorId: number): Promise<Collection[]>;
  getCollection(id: number): Promise<Collection | undefined>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  updateCollection(id: number, collection: Partial<InsertCollection>): Promise<Collection | undefined>;
  
  // Payouts
  getPayouts(): Promise<Payout[]>;
  getPayoutsByHousehold(householdId: number): Promise<Payout[]>;
  getPayout(id: number): Promise<Payout | undefined>;
  createPayout(payout: InsertPayout): Promise<Payout>;
  updatePayout(id: number, payout: Partial<InsertPayout>): Promise<Payout | undefined>;
  
  // Fraud Cases
  getFraudCases(): Promise<FraudCase[]>;
  getFraudCase(id: number): Promise<FraudCase | undefined>;
  createFraudCase(fraudCase: InsertFraudCase): Promise<FraudCase>;
  updateFraudCase(id: number, fraudCase: Partial<InsertFraudCase>): Promise<FraudCase | undefined>;
  
  // ESG Metrics
  getEsgMetrics(): Promise<EsgMetric[]>;
  getEsgMetric(id: number): Promise<EsgMetric | undefined>;
  createEsgMetric(esgMetric: InsertEsgMetric): Promise<EsgMetric>;
  
  // AI Insights
  getAiInsights(): Promise<AiInsight[]>;
  getAiInsight(id: number): Promise<AiInsight | undefined>;
  createAiInsight(aiInsight: InsertAiInsight): Promise<AiInsight>;
  updateAiInsight(id: number, aiInsight: Partial<InsertAiInsight>): Promise<AiInsight | undefined>;

  // Recyclable Items (EcoRakyat submissions)
  getRecyclableItems(): Promise<RecyclableItem[]>;
  getRecyclableItemsByUser(userId: number): Promise<RecyclableItem[]>;
  getRecyclableItemsByStatus(status: string): Promise<RecyclableItem[]>;
  getRecyclableItemsByRider(riderId: number): Promise<RecyclableItem[]>;
  getRecyclableItem(id: number): Promise<RecyclableItem | undefined>;
  createRecyclableItem(item: InsertRecyclableItem): Promise<RecyclableItem>;
  updateRecyclableItem(id: number, item: Partial<InsertRecyclableItem>): Promise<RecyclableItem | undefined>;

  // Reports (illegal dumping, issues)
  getReports(): Promise<Report[]>;
  getReportsByUser(userId: number): Promise<Report[]>;
  getReportsByStatus(status: string): Promise<Report[]>;
  getReportsByRider(riderId: number): Promise<Report[]>;
  getReport(id: number): Promise<Report | undefined>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, report: Partial<InsertReport>): Promise<Report | undefined>;

  // Route Plans
  getRoutePlans(): Promise<RoutePlan[]>;
  getRoutePlansByRider(riderId: number): Promise<RoutePlan[]>;
  getActiveRoutePlanByRider(riderId: number): Promise<RoutePlan | undefined>;
  getRoutePlan(id: number): Promise<RoutePlan | undefined>;
  createRoutePlan(plan: InsertRoutePlan): Promise<RoutePlan>;
  updateRoutePlan(id: number, plan: Partial<InsertRoutePlan>): Promise<RoutePlan | undefined>;
  
  // Route-specific item queries
  getRecyclableItemsByCategory(category: string): Promise<RecyclableItem[]>;
  getPendingItemsByCategory(category: string): Promise<RecyclableItem[]>;
  getItemsByRoutePlan(routePlanId: number): Promise<RecyclableItem[]>;
  clearItemRouteStatus(routePlanId: number): Promise<void>;
  bulkUpdateItemRouteStatus(itemIds: number[], routePlanId: number, routeStatus: string, sequences?: number[]): Promise<void>;

  // Route Events
  getRouteEventsByPlan(planId: number): Promise<RouteEvent[]>;
  getRouteEvent(id: number): Promise<RouteEvent | undefined>;
  createRouteEvent(event: InsertRouteEvent): Promise<RouteEvent>;
  updateRouteEvent(id: number, event: Partial<InsertRouteEvent>): Promise<RouteEvent | undefined>;

  // AI Prompts
  getAiPrompts(): Promise<AiPrompt[]>;
  getAiPromptsByType(promptType: string): Promise<AiPrompt[]>;
  getActiveAiPrompt(promptType: string): Promise<AiPrompt | undefined>;
  createAiPrompt(prompt: InsertAiPrompt): Promise<AiPrompt>;
  updateAiPrompt(id: number, prompt: Partial<InsertAiPrompt>): Promise<AiPrompt | undefined>;

  // Vouchers
  getVouchers(): Promise<Voucher[]>;
  getActiveVouchers(): Promise<Voucher[]>;
  getVoucher(id: number): Promise<Voucher | undefined>;
  createVoucher(voucher: InsertVoucher): Promise<Voucher>;
  updateVoucher(id: number, voucher: Partial<InsertVoucher>): Promise<Voucher | undefined>;

  // User Vouchers
  getUserVouchers(userId: number): Promise<UserVoucher[]>;
  getUserVoucher(id: number): Promise<UserVoucher | undefined>;
  createUserVoucher(userVoucher: InsertUserVoucher): Promise<UserVoucher>;
  updateUserVoucher(id: number, userVoucher: Partial<InsertUserVoucher>): Promise<UserVoucher | undefined>;

  // Reward Transactions
  getRewardTransactions(userId: number): Promise<RewardTransaction[]>;
  createRewardTransaction(transaction: InsertRewardTransaction): Promise<RewardTransaction>;

  // User updates for rewards
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  creditUserReward(userId: number, points: number, cashback: number): Promise<User | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private partners: Map<number, Partner> = new Map();
  private stations: Map<number, Station> = new Map();
  private devices: Map<number, Device> = new Map();
  private households: Map<number, Household> = new Map();
  private collections: Map<number, Collection> = new Map();
  private payouts: Map<number, Payout> = new Map();
  private fraudCases: Map<number, FraudCase> = new Map();
  private esgMetrics: Map<number, EsgMetric> = new Map();
  private aiInsights: Map<number, AiInsight> = new Map();
  
  private currentId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed initial data
    const defaultPartner: Partner = {
      id: 1,
      name: "AUCO Sdn Bhd",
      contact: "+60123456789",
      email: "contact@auco.com.my",
      regions: ["Klang Valley", "Selangor"],
      status: "active",
      createdAt: new Date(),
    };
    this.partners.set(1, defaultPartner);

    const defaultStation: Station = {
      id: 1,
      name: "Klang Valley Hub",
      address: "123 Industrial Area, Klang, Selangor",
      latitude: "3.0319",
      longitude: "101.5584",
      partnerId: 1,
      hours: "8:00 AM - 6:00 PM",
      status: "active",
      createdAt: new Date(),
    };
    this.stations.set(1, defaultStation);

    const defaultUser: User = {
      id: 1,
      username: "admin",
      password: "password123",
      name: "Ahmad Rahman",
      email: "ahmad.rahman@jabatan.gov.my",
      phone: "+60123456789",
      role: "jabatan",
      partnerId: null,
      avatarUrl: null,
      createdAt: new Date(),
    };
    this.users.set(1, defaultUser);

    const riderUser: User = {
      id: 2,
      username: "rider1",
      password: "rider123",
      name: "Muhammad Ali",
      email: "ali@ecorider.com",
      phone: "+60198765432",
      role: "ecorider",
      partnerId: 1,
      avatarUrl: null,
      createdAt: new Date(),
    };
    this.users.set(2, riderUser);

    const rakyatUser: User = {
      id: 3,
      username: "rakyat1",
      password: "rakyat123",
      name: "Siti Aminah",
      email: "siti@gmail.com",
      phone: "+60112223333",
      role: "ecorakyat",
      partnerId: null,
      avatarUrl: null,
      createdAt: new Date(),
    };
    this.users.set(3, rakyatUser);

    // Seed AI Insights
    const insights: InsertAiInsight[] = [
      {
        type: "optimization",
        title: "Optimal Collection Timing Detected",
        description: "AI analysis shows 23% higher efficiency when collections occur between 9-11 AM at Klang Valley stations.",
        confidence: "94.00",
        metadata: { dataPoints: 3247, timeRange: "9-11 AM" },
        status: "active",
      },
      {
        type: "anomaly",
        title: "Anomaly Pattern Identified",
        description: "Unusual spike in collection volumes at Subang station (+185% above average). Requires investigation.",
        confidence: "87.00",
        metadata: { station: "Subang", increase: 185 },
        status: "active",
      },
      {
        type: "prediction",
        title: "Predictive Recommendation",
        description: "Based on seasonal trends, expect 18% increase in collections during upcoming festive period. Consider additional capacity.",
        confidence: "87.00",
        metadata: { expectedIncrease: 18, period: "festive" },
        status: "active",
      },
    ];

    insights.forEach((insight, index) => {
      const aiInsight: AiInsight = {
        id: index + 1,
        createdAt: new Date(),
        title: insight.title,
        type: insight.type,
        description: insight.description,
        confidence: insight.confidence,
        status: insight.status || "active",
        metadata: insight.metadata || {},
      };
      this.aiInsights.set(index + 1, aiInsight);
    });

    this.currentId = 10;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      id,
      username: insertUser.username,
      password: insertUser.password,
      name: insertUser.name,
      email: insertUser.email,
      phone: insertUser.phone || null,
      role: insertUser.role,
      partnerId: insertUser.partnerId || null,
      avatarUrl: insertUser.avatarUrl || null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  // Partners
  async getPartners(): Promise<Partner[]> {
    return Array.from(this.partners.values());
  }

  async getPartner(id: number): Promise<Partner | undefined> {
    return this.partners.get(id);
  }

  async createPartner(insertPartner: InsertPartner): Promise<Partner> {
    const id = this.currentId++;
    const partner: Partner = {
      id,
      name: insertPartner.name,
      email: insertPartner.email,
      contact: insertPartner.contact,
      status: insertPartner.status || "active",
      regions: insertPartner.regions || null,
      createdAt: new Date(),
    };
    this.partners.set(id, partner);
    return partner;
  }

  async updatePartner(id: number, updateData: Partial<InsertPartner>): Promise<Partner | undefined> {
    const partner = this.partners.get(id);
    if (!partner) return undefined;
    const updated = { ...partner, ...updateData };
    this.partners.set(id, updated);
    return updated;
  }

  // Stations
  async getStations(): Promise<Station[]> {
    return Array.from(this.stations.values());
  }

  async getStationsByPartner(partnerId: number): Promise<Station[]> {
    return Array.from(this.stations.values()).filter(station => station.partnerId === partnerId);
  }

  async getStation(id: number): Promise<Station | undefined> {
    return this.stations.get(id);
  }

  async createStation(insertStation: InsertStation): Promise<Station> {
    const id = this.currentId++;
    const station: Station = {
      id,
      name: insertStation.name,
      partnerId: insertStation.partnerId,
      address: insertStation.address,
      status: insertStation.status || "active",
      latitude: insertStation.latitude || null,
      longitude: insertStation.longitude || null,
      hours: insertStation.hours || null,
      createdAt: new Date(),
    };
    this.stations.set(id, station);
    return station;
  }

  async updateStation(id: number, updateData: Partial<InsertStation>): Promise<Station | undefined> {
    const station = this.stations.get(id);
    if (!station) return undefined;
    const updated = { ...station, ...updateData };
    this.stations.set(id, updated);
    return updated;
  }

  // Devices
  async getDevices(): Promise<Device[]> {
    return Array.from(this.devices.values());
  }

  async getDevicesByStation(stationId: number): Promise<Device[]> {
    return Array.from(this.devices.values()).filter(device => device.stationId === stationId);
  }

  async getDevice(id: number): Promise<Device | undefined> {
    return this.devices.get(id);
  }

  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const id = this.currentId++;
    const device: Device = {
      id,
      stationId: insertDevice.stationId,
      serialNumber: insertDevice.serialNumber,
      type: insertDevice.type || "scale",
      status: insertDevice.status || "active",
      lastCalibration: insertDevice.lastCalibration || null,
      firmware: insertDevice.firmware || null,
      batteryLevel: insertDevice.batteryLevel || null,
      lastSync: insertDevice.lastSync || null,
      createdAt: new Date(),
    };
    this.devices.set(id, device);
    return device;
  }

  async updateDevice(id: number, updateData: Partial<InsertDevice>): Promise<Device | undefined> {
    const device = this.devices.get(id);
    if (!device) return undefined;
    const updated = { ...device, ...updateData };
    this.devices.set(id, updated);
    return updated;
  }

  // Households
  async getHouseholds(): Promise<Household[]> {
    return Array.from(this.households.values());
  }

  async getHousehold(id: number): Promise<Household | undefined> {
    return this.households.get(id);
  }

  async getHouseholdByPhone(phone: string): Promise<Household | undefined> {
    return Array.from(this.households.values()).find(household => household.phone === phone);
  }

  async createHousehold(insertHousehold: InsertHousehold): Promise<Household> {
    const id = this.currentId++;
    const household: Household = {
      id,
      phone: insertHousehold.phone,
      name: insertHousehold.name || null,
      email: insertHousehold.email || null,
      consentFlags: insertHousehold.consentFlags || {},
      totalKg: insertHousehold.totalKg || null,
      totalPoints: insertHousehold.totalPoints || null,
      createdAt: new Date(),
    };
    this.households.set(id, household);
    return household;
  }

  async updateHousehold(id: number, updateData: Partial<InsertHousehold>): Promise<Household | undefined> {
    const household = this.households.get(id);
    if (!household) return undefined;
    const updated = { ...household, ...updateData };
    this.households.set(id, updated);
    return updated;
  }

  // Collections
  async getCollections(): Promise<Collection[]> {
    return Array.from(this.collections.values());
  }

  async getCollectionsByStation(stationId: number): Promise<Collection[]> {
    return Array.from(this.collections.values()).filter(collection => collection.stationId === stationId);
  }

  async getCollectionsByCollector(collectorId: number): Promise<Collection[]> {
    return Array.from(this.collections.values()).filter(collection => collection.collectorId === collectorId);
  }

  async getCollection(id: number): Promise<Collection | undefined> {
    return this.collections.get(id);
  }

  async createCollection(insertCollection: InsertCollection): Promise<Collection> {
    const id = this.currentId++;
    const collection: Collection = {
      id,
      stationId: insertCollection.stationId,
      collectionId: insertCollection.collectionId,
      householdId: insertCollection.householdId || null,
      collectorId: insertCollection.collectorId,
      kg: insertCollection.kg,
      payoutType: insertCollection.payoutType,
      payoutAmount: insertCollection.payoutAmount,
      status: insertCollection.status || "completed",
      photoUrl: insertCollection.photoUrl || null,
      signatureUrl: insertCollection.signatureUrl || null,
      deviceId: insertCollection.deviceId || null,
      flags: insertCollection.flags || null,
      metadata: insertCollection.metadata || {},
      geoLocation: insertCollection.geoLocation || {},
      createdAt: new Date(),
    };
    this.collections.set(id, collection);
    return collection;
  }

  async updateCollection(id: number, updateData: Partial<InsertCollection>): Promise<Collection | undefined> {
    const collection = this.collections.get(id);
    if (!collection) return undefined;
    const updated = { ...collection, ...updateData };
    this.collections.set(id, updated);
    return updated;
  }

  // Payouts
  async getPayouts(): Promise<Payout[]> {
    return Array.from(this.payouts.values());
  }

  async getPayoutsByHousehold(householdId: number): Promise<Payout[]> {
    return Array.from(this.payouts.values()).filter(payout => payout.householdId === householdId);
  }

  async getPayout(id: number): Promise<Payout | undefined> {
    return this.payouts.get(id);
  }

  async createPayout(insertPayout: InsertPayout): Promise<Payout> {
    const id = this.currentId++;
    const payout: Payout = {
      id,
      type: insertPayout.type,
      collectionId: insertPayout.collectionId,
      householdId: insertPayout.householdId || null,
      amount: insertPayout.amount,
      status: insertPayout.status || "pending",
      reconciled: insertPayout.reconciled || null,
      createdAt: new Date(),
    };
    this.payouts.set(id, payout);
    return payout;
  }

  async updatePayout(id: number, updateData: Partial<InsertPayout>): Promise<Payout | undefined> {
    const payout = this.payouts.get(id);
    if (!payout) return undefined;
    const updated = { ...payout, ...updateData };
    this.payouts.set(id, updated);
    return updated;
  }

  // Fraud Cases
  async getFraudCases(): Promise<FraudCase[]> {
    return Array.from(this.fraudCases.values());
  }

  async getFraudCase(id: number): Promise<FraudCase | undefined> {
    return this.fraudCases.get(id);
  }

  async createFraudCase(insertFraudCase: InsertFraudCase): Promise<FraudCase> {
    const id = this.currentId++;
    const fraudCase: FraudCase = {
      id,
      status: insertFraudCase.status || "pending",
      reason: insertFraudCase.reason,
      collectionIds: insertFraudCase.collectionIds || null,
      reviewerId: insertFraudCase.reviewerId || null,
      resolutionNotes: insertFraudCase.resolutionNotes || null,
      severity: insertFraudCase.severity || "medium",
      resolvedAt: null,
      createdAt: new Date(),
    };
    this.fraudCases.set(id, fraudCase);
    return fraudCase;
  }

  async updateFraudCase(id: number, updateData: Partial<InsertFraudCase>): Promise<FraudCase | undefined> {
    const fraudCase = this.fraudCases.get(id);
    if (!fraudCase) return undefined;
    const updated = { ...fraudCase, ...updateData };
    if (updateData.status === "resolved") {
      updated.resolvedAt = new Date();
    }
    this.fraudCases.set(id, updated);
    return updated;
  }

  // ESG Metrics
  async getEsgMetrics(): Promise<EsgMetric[]> {
    return Array.from(this.esgMetrics.values());
  }

  async getEsgMetric(id: number): Promise<EsgMetric | undefined> {
    return this.esgMetrics.get(id);
  }

  async createEsgMetric(insertEsgMetric: InsertEsgMetric): Promise<EsgMetric> {
    const id = this.currentId++;
    const esgMetric: EsgMetric = {
      id,
      period: insertEsgMetric.period,
      startDate: insertEsgMetric.startDate,
      endDate: insertEsgMetric.endDate,
      kgTotal: insertEsgMetric.kgTotal,
      householdsServed: insertEsgMetric.householdsServed,
      co2Saved: insertEsgMetric.co2Saved,
      revenueGenerated: insertEsgMetric.revenueGenerated,
      reportUrl: insertEsgMetric.reportUrl || null,
      createdAt: new Date(),
    };
    this.esgMetrics.set(id, esgMetric);
    return esgMetric;
  }

  // AI Insights
  async getAiInsights(): Promise<AiInsight[]> {
    return Array.from(this.aiInsights.values());
  }

  async getAiInsight(id: number): Promise<AiInsight | undefined> {
    return this.aiInsights.get(id);
  }

  async createAiInsight(insertAiInsight: InsertAiInsight): Promise<AiInsight> {
    const id = this.currentId++;
    const aiInsight: AiInsight = {
      id,
      title: insertAiInsight.title,
      type: insertAiInsight.type,
      description: insertAiInsight.description,
      confidence: insertAiInsight.confidence,
      status: insertAiInsight.status || "active",
      metadata: insertAiInsight.metadata || {},
      createdAt: new Date(),
    };
    this.aiInsights.set(id, aiInsight);
    return aiInsight;
  }

  async updateAiInsight(id: number, updateData: Partial<InsertAiInsight>): Promise<AiInsight | undefined> {
    const aiInsight = this.aiInsights.get(id);
    if (!aiInsight) return undefined;
    const updated = { ...aiInsight, ...updateData };
    this.aiInsights.set(id, updated);
    return updated;
  }

  // Stub implementations for interface compliance (using DatabaseStorage instead)
  async getRecyclableItems(): Promise<RecyclableItem[]> { return []; }
  async getRecyclableItemsByUser(userId: number): Promise<RecyclableItem[]> { return []; }
  async getRecyclableItemsByStatus(status: string): Promise<RecyclableItem[]> { return []; }
  async getRecyclableItemsByRider(riderId: number): Promise<RecyclableItem[]> { return []; }
  async getRecyclableItem(id: number): Promise<RecyclableItem | undefined> { return undefined; }
  async createRecyclableItem(item: InsertRecyclableItem): Promise<RecyclableItem> { throw new Error("Use DatabaseStorage"); }
  async updateRecyclableItem(id: number, item: Partial<InsertRecyclableItem>): Promise<RecyclableItem | undefined> { return undefined; }
  async getReports(): Promise<Report[]> { return []; }
  async getReportsByUser(userId: number): Promise<Report[]> { return []; }
  async getReportsByStatus(status: string): Promise<Report[]> { return []; }
  async getReportsByRider(riderId: number): Promise<Report[]> { return []; }
  async getReport(id: number): Promise<Report | undefined> { return undefined; }
  async createReport(report: InsertReport): Promise<Report> { throw new Error("Use DatabaseStorage"); }
  async updateReport(id: number, report: Partial<InsertReport>): Promise<Report | undefined> { return undefined; }
  async getRoutePlans(): Promise<RoutePlan[]> { return []; }
  async getRoutePlansByRider(riderId: number): Promise<RoutePlan[]> { return []; }
  async getActiveRoutePlanByRider(riderId: number): Promise<RoutePlan | undefined> { return undefined; }
  async getRoutePlan(id: number): Promise<RoutePlan | undefined> { return undefined; }
  async createRoutePlan(plan: InsertRoutePlan): Promise<RoutePlan> { throw new Error("Use DatabaseStorage"); }
  async updateRoutePlan(id: number, plan: Partial<InsertRoutePlan>): Promise<RoutePlan | undefined> { return undefined; }
  async getRecyclableItemsByCategory(category: string): Promise<RecyclableItem[]> { return []; }
  async getPendingItemsByCategory(category: string): Promise<RecyclableItem[]> { return []; }
  async getItemsByRoutePlan(routePlanId: number): Promise<RecyclableItem[]> { return []; }
  async clearItemRouteStatus(routePlanId: number): Promise<void> { }
  async bulkUpdateItemRouteStatus(itemIds: number[], routePlanId: number, routeStatus: string, sequences?: number[]): Promise<void> { }
  async getRouteEventsByPlan(planId: number): Promise<RouteEvent[]> { return []; }
  async getRouteEvent(id: number): Promise<RouteEvent | undefined> { return undefined; }
  async createRouteEvent(event: InsertRouteEvent): Promise<RouteEvent> { throw new Error("Use DatabaseStorage"); }
  async updateRouteEvent(id: number, event: Partial<InsertRouteEvent>): Promise<RouteEvent | undefined> { return undefined; }
  async getAiPrompts(): Promise<AiPrompt[]> { return []; }
  async getAiPromptsByType(promptType: string): Promise<AiPrompt[]> { return []; }
  async getActiveAiPrompt(promptType: string): Promise<AiPrompt | undefined> { return undefined; }
  async createAiPrompt(prompt: InsertAiPrompt): Promise<AiPrompt> { throw new Error("Use DatabaseStorage"); }
  async updateAiPrompt(id: number, prompt: Partial<InsertAiPrompt>): Promise<AiPrompt | undefined> { return undefined; }
  async getVouchers(): Promise<Voucher[]> { return []; }
  async getActiveVouchers(): Promise<Voucher[]> { return []; }
  async getVoucher(id: number): Promise<Voucher | undefined> { return undefined; }
  async createVoucher(voucher: InsertVoucher): Promise<Voucher> { throw new Error("Use DatabaseStorage"); }
  async updateVoucher(id: number, voucher: Partial<InsertVoucher>): Promise<Voucher | undefined> { return undefined; }
  async getUserVouchers(userId: number): Promise<UserVoucher[]> { return []; }
  async getUserVoucher(id: number): Promise<UserVoucher | undefined> { return undefined; }
  async createUserVoucher(userVoucher: InsertUserVoucher): Promise<UserVoucher> { throw new Error("Use DatabaseStorage"); }
  async updateUserVoucher(id: number, userVoucher: Partial<InsertUserVoucher>): Promise<UserVoucher | undefined> { return undefined; }
  async getRewardTransactions(userId: number): Promise<RewardTransaction[]> { return []; }
  async createRewardTransaction(transaction: InsertRewardTransaction): Promise<RewardTransaction> { throw new Error("Use DatabaseStorage"); }
  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> { return undefined; }
  async creditUserReward(userId: number, points: number, cashback: number): Promise<User | undefined> { return undefined; }
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Partners
  async getPartners(): Promise<Partner[]> {
    return await db.select().from(partners);
  }

  async getPartner(id: number): Promise<Partner | undefined> {
    const [partner] = await db.select().from(partners).where(eq(partners.id, id));
    return partner || undefined;
  }

  async createPartner(insertPartner: InsertPartner): Promise<Partner> {
    const [partner] = await db
      .insert(partners)
      .values(insertPartner)
      .returning();
    return partner;
  }

  async updatePartner(id: number, updateData: Partial<InsertPartner>): Promise<Partner | undefined> {
    const [partner] = await db
      .update(partners)
      .set(updateData)
      .where(eq(partners.id, id))
      .returning();
    return partner || undefined;
  }

  // Stations
  async getStations(): Promise<Station[]> {
    return await db.select().from(stations);
  }

  async getStationsByPartner(partnerId: number): Promise<Station[]> {
    return await db.select().from(stations).where(eq(stations.partnerId, partnerId));
  }

  async getStation(id: number): Promise<Station | undefined> {
    const [station] = await db.select().from(stations).where(eq(stations.id, id));
    return station || undefined;
  }

  async createStation(insertStation: InsertStation): Promise<Station> {
    const [station] = await db
      .insert(stations)
      .values(insertStation)
      .returning();
    return station;
  }

  async updateStation(id: number, updateData: Partial<InsertStation>): Promise<Station | undefined> {
    const [station] = await db
      .update(stations)
      .set(updateData)
      .where(eq(stations.id, id))
      .returning();
    return station || undefined;
  }

  // Devices
  async getDevices(): Promise<Device[]> {
    return await db.select().from(devices);
  }

  async getDevicesByStation(stationId: number): Promise<Device[]> {
    return await db.select().from(devices).where(eq(devices.stationId, stationId));
  }

  async getDevice(id: number): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.id, id));
    return device || undefined;
  }

  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const [device] = await db
      .insert(devices)
      .values(insertDevice)
      .returning();
    return device;
  }

  async updateDevice(id: number, updateData: Partial<InsertDevice>): Promise<Device | undefined> {
    const [device] = await db
      .update(devices)
      .set(updateData)
      .where(eq(devices.id, id))
      .returning();
    return device || undefined;
  }

  // Households
  async getHouseholds(): Promise<Household[]> {
    return await db.select().from(households);
  }

  async getHousehold(id: number): Promise<Household | undefined> {
    const [household] = await db.select().from(households).where(eq(households.id, id));
    return household || undefined;
  }

  async getHouseholdByPhone(phone: string): Promise<Household | undefined> {
    const [household] = await db.select().from(households).where(eq(households.phone, phone));
    return household || undefined;
  }

  async createHousehold(insertHousehold: InsertHousehold): Promise<Household> {
    const [household] = await db
      .insert(households)
      .values(insertHousehold)
      .returning();
    return household;
  }

  async updateHousehold(id: number, updateData: Partial<InsertHousehold>): Promise<Household | undefined> {
    const [household] = await db
      .update(households)
      .set(updateData)
      .where(eq(households.id, id))
      .returning();
    return household || undefined;
  }

  // Collections
  async getCollections(): Promise<Collection[]> {
    return await db.select().from(collections);
  }

  async getCollectionsByStation(stationId: number): Promise<Collection[]> {
    return await db.select().from(collections).where(eq(collections.stationId, stationId));
  }

  async getCollectionsByCollector(collectorId: number): Promise<Collection[]> {
    return await db.select().from(collections).where(eq(collections.collectorId, collectorId));
  }

  async getCollection(id: number): Promise<Collection | undefined> {
    const [collection] = await db.select().from(collections).where(eq(collections.id, id));
    return collection || undefined;
  }

  async createCollection(insertCollection: InsertCollection): Promise<Collection> {
    const [collection] = await db
      .insert(collections)
      .values(insertCollection)
      .returning();
    return collection;
  }

  async updateCollection(id: number, updateData: Partial<InsertCollection>): Promise<Collection | undefined> {
    const [collection] = await db
      .update(collections)
      .set(updateData)
      .where(eq(collections.id, id))
      .returning();
    return collection || undefined;
  }

  // Payouts
  async getPayouts(): Promise<Payout[]> {
    return await db.select().from(payouts);
  }

  async getPayoutsByHousehold(householdId: number): Promise<Payout[]> {
    return await db.select().from(payouts).where(eq(payouts.householdId, householdId));
  }

  async getPayout(id: number): Promise<Payout | undefined> {
    const [payout] = await db.select().from(payouts).where(eq(payouts.id, id));
    return payout || undefined;
  }

  async createPayout(insertPayout: InsertPayout): Promise<Payout> {
    const [payout] = await db
      .insert(payouts)
      .values(insertPayout)
      .returning();
    return payout;
  }

  async updatePayout(id: number, updateData: Partial<InsertPayout>): Promise<Payout | undefined> {
    const [payout] = await db
      .update(payouts)
      .set(updateData)
      .where(eq(payouts.id, id))
      .returning();
    return payout || undefined;
  }

  // Fraud Cases
  async getFraudCases(): Promise<FraudCase[]> {
    return await db.select().from(fraudCases);
  }

  async getFraudCase(id: number): Promise<FraudCase | undefined> {
    const [fraudCase] = await db.select().from(fraudCases).where(eq(fraudCases.id, id));
    return fraudCase || undefined;
  }

  async createFraudCase(insertFraudCase: InsertFraudCase): Promise<FraudCase> {
    const [fraudCase] = await db
      .insert(fraudCases)
      .values(insertFraudCase)
      .returning();
    return fraudCase;
  }

  async updateFraudCase(id: number, updateData: Partial<InsertFraudCase>): Promise<FraudCase | undefined> {
    const [fraudCase] = await db
      .update(fraudCases)
      .set(updateData)
      .where(eq(fraudCases.id, id))
      .returning();
    return fraudCase || undefined;
  }

  // ESG Metrics
  async getEsgMetrics(): Promise<EsgMetric[]> {
    return await db.select().from(esgMetrics);
  }

  async getEsgMetric(id: number): Promise<EsgMetric | undefined> {
    const [esgMetric] = await db.select().from(esgMetrics).where(eq(esgMetrics.id, id));
    return esgMetric || undefined;
  }

  async createEsgMetric(insertEsgMetric: InsertEsgMetric): Promise<EsgMetric> {
    const [esgMetric] = await db
      .insert(esgMetrics)
      .values(insertEsgMetric)
      .returning();
    return esgMetric;
  }

  // AI Insights
  async getAiInsights(): Promise<AiInsight[]> {
    return await db.select().from(aiInsights);
  }

  async getAiInsight(id: number): Promise<AiInsight | undefined> {
    const [aiInsight] = await db.select().from(aiInsights).where(eq(aiInsights.id, id));
    return aiInsight || undefined;
  }

  async createAiInsight(insertAiInsight: InsertAiInsight): Promise<AiInsight> {
    const [aiInsight] = await db
      .insert(aiInsights)
      .values(insertAiInsight)
      .returning();
    return aiInsight;
  }

  async updateAiInsight(id: number, updateData: Partial<InsertAiInsight>): Promise<AiInsight | undefined> {
    const [aiInsight] = await db
      .update(aiInsights)
      .set(updateData)
      .where(eq(aiInsights.id, id))
      .returning();
    return aiInsight || undefined;
  }

  // Recyclable Items
  async getRecyclableItems(): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems).orderBy(desc(recyclableItems.createdAt));
  }

  async getRecyclableItemsByUser(userId: number): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems).where(eq(recyclableItems.userId, userId)).orderBy(desc(recyclableItems.createdAt));
  }

  async getRecyclableItemsByStatus(status: string): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems).where(eq(recyclableItems.status, status)).orderBy(desc(recyclableItems.createdAt));
  }

  async getRecyclableItemsByRider(riderId: number): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems).where(eq(recyclableItems.assignedRiderId, riderId)).orderBy(desc(recyclableItems.createdAt));
  }

  async getRecyclableItem(id: number): Promise<RecyclableItem | undefined> {
    const [item] = await db.select().from(recyclableItems).where(eq(recyclableItems.id, id));
    return item || undefined;
  }

  async createRecyclableItem(insertItem: InsertRecyclableItem): Promise<RecyclableItem> {
    const [item] = await db
      .insert(recyclableItems)
      .values(insertItem)
      .returning();
    return item;
  }

  async updateRecyclableItem(id: number, updateData: Partial<InsertRecyclableItem>): Promise<RecyclableItem | undefined> {
    const [item] = await db
      .update(recyclableItems)
      .set(updateData)
      .where(eq(recyclableItems.id, id))
      .returning();
    return item || undefined;
  }

  // Reports
  async getReports(): Promise<Report[]> {
    return await db.select().from(reports).orderBy(desc(reports.createdAt));
  }

  async getReportsByUser(userId: number): Promise<Report[]> {
    return await db.select().from(reports).where(eq(reports.userId, userId)).orderBy(desc(reports.createdAt));
  }

  async getReportsByStatus(status: string): Promise<Report[]> {
    return await db.select().from(reports).where(eq(reports.status, status)).orderBy(desc(reports.createdAt));
  }

  async getReportsByRider(riderId: number): Promise<Report[]> {
    return await db.select().from(reports).where(eq(reports.assignedRiderId, riderId)).orderBy(desc(reports.createdAt));
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report || undefined;
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const [report] = await db
      .insert(reports)
      .values(insertReport)
      .returning();
    return report;
  }

  async updateReport(id: number, updateData: Partial<InsertReport>): Promise<Report | undefined> {
    const [report] = await db
      .update(reports)
      .set(updateData)
      .where(eq(reports.id, id))
      .returning();
    return report || undefined;
  }

  // Route Plans
  async getRoutePlans(): Promise<RoutePlan[]> {
    return await db.select().from(routePlans).orderBy(desc(routePlans.date));
  }

  async getRoutePlansByRider(riderId: number): Promise<RoutePlan[]> {
    return await db.select().from(routePlans).where(eq(routePlans.riderId, riderId)).orderBy(desc(routePlans.date));
  }

  async getActiveRoutePlanByRider(riderId: number): Promise<RoutePlan | undefined> {
    const [plan] = await db.select().from(routePlans)
      .where(and(eq(routePlans.riderId, riderId), eq(routePlans.status, "in_progress")))
      .orderBy(desc(routePlans.date));
    return plan || undefined;
  }

  async getRoutePlan(id: number): Promise<RoutePlan | undefined> {
    const [plan] = await db.select().from(routePlans).where(eq(routePlans.id, id));
    return plan || undefined;
  }

  async createRoutePlan(insertPlan: InsertRoutePlan): Promise<RoutePlan> {
    const [plan] = await db
      .insert(routePlans)
      .values(insertPlan)
      .returning();
    return plan;
  }

  async updateRoutePlan(id: number, updateData: Partial<InsertRoutePlan>): Promise<RoutePlan | undefined> {
    const [plan] = await db
      .update(routePlans)
      .set(updateData)
      .where(eq(routePlans.id, id))
      .returning();
    return plan || undefined;
  }

  // Route Events
  async getRouteEventsByPlan(planId: number): Promise<RouteEvent[]> {
    return await db.select().from(routeEvents).where(eq(routeEvents.planId, planId));
  }

  async getRouteEvent(id: number): Promise<RouteEvent | undefined> {
    const [event] = await db.select().from(routeEvents).where(eq(routeEvents.id, id));
    return event || undefined;
  }

  async createRouteEvent(insertEvent: InsertRouteEvent): Promise<RouteEvent> {
    const [event] = await db
      .insert(routeEvents)
      .values(insertEvent)
      .returning();
    return event;
  }

  async updateRouteEvent(id: number, updateData: Partial<InsertRouteEvent>): Promise<RouteEvent | undefined> {
    const [event] = await db
      .update(routeEvents)
      .set(updateData)
      .where(eq(routeEvents.id, id))
      .returning();
    return event || undefined;
  }

  // AI Prompts
  async getAiPrompts(): Promise<AiPrompt[]> {
    return await db.select().from(aiPrompts);
  }

  async getAiPromptsByType(promptType: string): Promise<AiPrompt[]> {
    return await db.select().from(aiPrompts).where(eq(aiPrompts.promptType, promptType));
  }

  async getActiveAiPrompt(promptType: string): Promise<AiPrompt | undefined> {
    const [prompt] = await db.select().from(aiPrompts)
      .where(and(eq(aiPrompts.promptType, promptType), eq(aiPrompts.isActive, true)));
    return prompt || undefined;
  }

  async createAiPrompt(insertPrompt: InsertAiPrompt): Promise<AiPrompt> {
    const [prompt] = await db
      .insert(aiPrompts)
      .values(insertPrompt)
      .returning();
    return prompt;
  }

  async updateAiPrompt(id: number, updateData: Partial<InsertAiPrompt>): Promise<AiPrompt | undefined> {
    const [prompt] = await db
      .update(aiPrompts)
      .set(updateData)
      .where(eq(aiPrompts.id, id))
      .returning();
    return prompt || undefined;
  }

  // Route-specific item queries
  async getRecyclableItemsByCategory(category: string): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems)
      .where(eq(recyclableItems.category, category))
      .orderBy(desc(recyclableItems.createdAt));
  }

  async getPendingItemsByCategory(category: string): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems)
      .where(and(
        eq(recyclableItems.category, category),
        eq(recyclableItems.status, "new")
      ))
      .orderBy(desc(recyclableItems.createdAt));
  }

  async getItemsByRoutePlan(routePlanId: number): Promise<RecyclableItem[]> {
    return await db.select().from(recyclableItems)
      .where(eq(recyclableItems.routePlanId, routePlanId))
      .orderBy(recyclableItems.routeSequence);
  }

  async clearItemRouteStatus(routePlanId: number): Promise<void> {
    await db.update(recyclableItems)
      .set({ routePlanId: null, routeSequence: null, routeStatus: null })
      .where(eq(recyclableItems.routePlanId, routePlanId));
  }

  async bulkUpdateItemRouteStatus(
    itemIds: number[], 
    routePlanId: number, 
    routeStatus: string, 
    sequences?: number[]
  ): Promise<void> {
    for (let i = 0; i < itemIds.length; i++) {
      await db.update(recyclableItems)
        .set({ 
          routePlanId, 
          routeStatus, 
          routeSequence: sequences ? sequences[i] : null 
        })
        .where(eq(recyclableItems.id, itemIds[i]));
    }
  }

  // Vouchers
  async getVouchers(): Promise<Voucher[]> {
    return await db.select().from(vouchers).orderBy(desc(vouchers.createdAt));
  }

  async getActiveVouchers(): Promise<Voucher[]> {
    return await db.select().from(vouchers).where(eq(vouchers.isActive, true)).orderBy(vouchers.pointsCost);
  }

  async getVoucher(id: number): Promise<Voucher | undefined> {
    const [voucher] = await db.select().from(vouchers).where(eq(vouchers.id, id));
    return voucher || undefined;
  }

  async createVoucher(insertVoucher: InsertVoucher): Promise<Voucher> {
    const [voucher] = await db.insert(vouchers).values(insertVoucher).returning();
    return voucher;
  }

  async updateVoucher(id: number, updateData: Partial<InsertVoucher>): Promise<Voucher | undefined> {
    const [voucher] = await db.update(vouchers).set(updateData).where(eq(vouchers.id, id)).returning();
    return voucher || undefined;
  }

  // User Vouchers
  async getUserVouchers(userId: number): Promise<UserVoucher[]> {
    return await db.select().from(userVouchers).where(eq(userVouchers.userId, userId)).orderBy(desc(userVouchers.redeemedAt));
  }

  async getUserVoucher(id: number): Promise<UserVoucher | undefined> {
    const [uv] = await db.select().from(userVouchers).where(eq(userVouchers.id, id));
    return uv || undefined;
  }

  async createUserVoucher(insertUserVoucher: InsertUserVoucher): Promise<UserVoucher> {
    const [uv] = await db.insert(userVouchers).values(insertUserVoucher).returning();
    return uv;
  }

  async updateUserVoucher(id: number, updateData: Partial<InsertUserVoucher>): Promise<UserVoucher | undefined> {
    const [uv] = await db.update(userVouchers).set(updateData).where(eq(userVouchers.id, id)).returning();
    return uv || undefined;
  }

  // Reward Transactions
  async getRewardTransactions(userId: number): Promise<RewardTransaction[]> {
    return await db.select().from(rewardTransactions).where(eq(rewardTransactions.userId, userId)).orderBy(desc(rewardTransactions.createdAt));
  }

  async createRewardTransaction(insertTransaction: InsertRewardTransaction): Promise<RewardTransaction> {
    const [tx] = await db.insert(rewardTransactions).values(insertTransaction).returning();
    return tx;
  }

  // User updates
  async updateUser(id: number, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(updateData).where(eq(users.id, id)).returning();
    return user || undefined;
  }

  async creditUserReward(userId: number, points: number, cashback: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) return undefined;
    
    const newTotalPoints = (user.totalPoints || 0) + points;
    const newTotalCashback = parseFloat(user.totalCashback?.toString() || "0") + cashback;
    const newLifetimePoints = (user.lifetimePoints || 0) + points;
    const newLifetimeCashback = parseFloat(user.lifetimeCashback?.toString() || "0") + cashback;

    const [updated] = await db.update(users).set({
      totalPoints: newTotalPoints,
      totalCashback: newTotalCashback.toFixed(2),
      lifetimePoints: newLifetimePoints,
      lifetimeCashback: newLifetimeCashback.toFixed(2),
    }).where(eq(users.id, userId)).returning();
    return updated || undefined;
  }
}

export const storage = new DatabaseStorage();
