import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, TrendingUp, AlertTriangle, Lightbulb } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { AiInsight } from "@shared/schema";

const iconMap = {
  optimization: TrendingUp,
  anomaly: AlertTriangle,
  prediction: Lightbulb,
};

const colorMap = {
  optimization: "bg-green-100 text-green-600",
  anomaly: "bg-yellow-100 text-yellow-600",
  prediction: "bg-blue-100 text-blue-600",
};

export default function AIInsights() {
  const { data: insights, isLoading } = useQuery<AiInsight[]>({
    queryKey: ["/api/ai-insights"],
  });

  if (isLoading) {
    return (
      <Card className="lg:col-span-2 bg-gradient-to-br from-petronas-bg to-white">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="mr-2 h-5 w-5 text-petronas-light" />
            AI-Powered Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500">Loading AI insights...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="lg:col-span-2 bg-gradient-to-br from-petronas-bg to-white">
      <CardHeader>
        <div className="flex items-center">
          <div className="w-10 h-10 bg-petronas-light rounded-lg flex items-center justify-center mr-3">
            <Brain className="h-5 w-5 text-white" />
          </div>
          <div>
            <CardTitle>AI-Powered Insights</CardTitle>
            <p className="text-sm text-gray-600">Machine learning analysis of collection patterns</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights?.map((insight) => {
            const Icon = iconMap[insight.type as keyof typeof iconMap] || Brain;
            const colorClass = colorMap[insight.type as keyof typeof colorMap] || "bg-gray-100 text-gray-600";
            
            return (
              <div key={insight.id} className="bg-white rounded-lg p-4 border border-gray-100">
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">{insight.title}</h4>
                    <p className="text-sm text-gray-600 mt-1">{insight.description}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      Confidence: {insight.confidence}% • AI Analysis
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
