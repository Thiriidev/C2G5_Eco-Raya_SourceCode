import { Button } from "@/components/ui/button";
import { Bell, Download } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  return (
    <header className="bg-gradient-to-r from-white via-emerald-50/50 to-teal-50/50 shadow-sm border-b border-emerald-100">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-emerald-900">{title}</h2>
            <p className="text-emerald-600/70">{subtitle}</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-lg shadow-emerald-200/50">
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
            <div className="relative">
              <Button variant="ghost" size="icon" className="text-emerald-700 hover:bg-emerald-100">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  3
                </span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
