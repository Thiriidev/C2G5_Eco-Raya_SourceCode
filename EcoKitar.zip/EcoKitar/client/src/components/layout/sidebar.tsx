import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";
import {
  Gauge,
  Recycle,
  CreditCard,
  LineChart,
  Shield,
  FileText,
  Handshake,
  Scale,
  Leaf,
  Settings,
  LogOut,
  User,
} from "lucide-react";
import ecoKitarLogo from "@assets/1000150524_1762361284650.jpg";

const navigationItems = [
  { path: "/dashboard", label: "Dashboard", icon: Gauge },
  { path: "/collections", label: "Collections", icon: Recycle },
  { path: "/payouts", label: "Payouts", icon: CreditCard },
  { path: "/analytics", label: "AI Analytics", icon: LineChart },
  { path: "/fraud", label: "Fraud Detection", icon: Shield },
  { path: "/reports", label: "Reports", icon: FileText },
  { path: "/partners", label: "Partners", icon: Handshake },
  { path: "/devices", label: "Devices", icon: Scale },
  { path: "/esg", label: "ESG Metrics", icon: Leaf },
  { path: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  return (
    <div className="w-64 bg-gradient-to-b from-emerald-800 via-emerald-900 to-teal-900 text-white shadow-xl flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-emerald-700/50">
        <div className="flex items-center gap-3">
          <img 
            src={ecoKitarLogo} 
            alt="EcoKitar Logo" 
            className="h-10 w-10 rounded-xl object-cover"
          />
          <div>
            <h1 className="text-xl font-bold text-white">EcoKitar</h1>
            <p className="text-xs text-emerald-300">Recycling Platform</p>
          </div>
        </div>
      </div>
      
      {/* User Info */}
      <div className="p-4 border-b border-emerald-700/50">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full flex items-center justify-center shadow-lg">
            <User className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="font-semibold text-white">{user?.name}</p>
            <p className="text-xs text-emerald-300">
              {user?.role === 'jabatan' ? 'Jabatan Operations' : user?.role === 'admin' ? 'Administrator' : 'Staff'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 mt-4 px-3">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link
              key={item.path}
              href={item.path}
              className={cn(
                "flex items-center px-4 py-2.5 my-1 rounded-xl text-emerald-200 hover:bg-white/10 hover:text-white transition-all duration-200",
                isActive && "bg-gradient-to-r from-emerald-500/30 to-teal-500/30 text-white border-l-4 border-emerald-400"
              )}
            >
              <Icon className={cn("w-5 h-5", isActive && "text-emerald-400")} />
              <span className="ml-3 text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-emerald-700/50">
        <button
          onClick={logout}
          className="flex items-center w-full px-4 py-2.5 text-emerald-200 hover:bg-red-500/20 hover:text-red-300 transition-all duration-200 rounded-xl"
        >
          <LogOut className="w-5 h-5" />
          <span className="ml-3 text-sm font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
}
