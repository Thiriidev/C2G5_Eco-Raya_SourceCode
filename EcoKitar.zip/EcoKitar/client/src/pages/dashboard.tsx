import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import KPICard from "@/components/dashboard/kpi-card";
import CollectionChart from "@/components/dashboard/collection-chart";
import AIInsights from "@/components/dashboard/ai-insights";
import RecentCollections from "@/components/dashboard/recent-collections";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Recycle, Home, Leaf, DollarSign } from "lucide-react";
import { mockTopPartners } from "@/lib/mock-data";

export default function Dashboard() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated || metricsLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-eco-gradient">
        <div className="flex items-center gap-3">
          <Leaf className="h-8 w-8 text-emerald-600 animate-pulse" />
          <p className="text-emerald-700 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-eco-gradient">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="EcoKitar Dashboard"
          subtitle="Real-time monitoring and analytics for recycling operations"
        />
        
        <main className="p-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <KPICard
              title="Total Recycled"
              value="24,567 kg"
              change="12.5%"
              changeType="increase"
              icon={<Recycle className="h-6 w-6 text-emerald-600" />}
              iconBgColor="bg-emerald-100"
            />
            <KPICard
              title="Households Served"
              value="8,423"
              change="8.2%"
              changeType="increase"
              icon={<Home className="h-6 w-6 text-teal-600" />}
              iconBgColor="bg-teal-100"
            />
            <KPICard
              title="CO₂ Saved"
              value="73.7 tons"
              change="15.3%"
              changeType="increase"
              icon={<Leaf className="h-6 w-6 text-emerald-600" />}
              iconBgColor="bg-emerald-100"
            />
            <KPICard
              title="Revenue Generated"
              value="RM 186,420"
              change="15.8%"
              changeType="increase"
              icon={<DollarSign className="h-6 w-6 text-amber-600" />}
              iconBgColor="bg-amber-100"
            />
          </div>

          {/* Charts and Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <CollectionChart />
            
            {/* Station Performance */}
            <Card className="bg-white/80 backdrop-blur-sm border-emerald-100">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-emerald-800">Collection Points</CardTitle>
                  <button className="text-sm text-emerald-600 hover:text-emerald-800 transition-colors">
                    View All Points
                  </button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg p-4 flex items-center justify-center h-48">
                  <div className="text-center">
                    <Recycle className="h-12 w-12 text-emerald-500 mx-auto mb-2" />
                    <p className="text-emerald-700 font-medium">Collection Points Map</p>
                    <p className="text-sm text-emerald-600/70">Klang Valley Region</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center bg-emerald-50 rounded-lg p-3">
                    <p className="text-2xl font-bold text-emerald-600">95%</p>
                    <p className="text-sm text-emerald-700/70">Active Points</p>
                  </div>
                  <div className="text-center bg-teal-50 rounded-lg p-3">
                    <p className="text-2xl font-bold text-teal-600">127</p>
                    <p className="text-sm text-teal-700/70">Total Points</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* AI Insights and Top Partners */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <AIInsights />
            
            {/* Top Partners */}
            <Card className="bg-white/80 backdrop-blur-sm border-emerald-100">
              <CardHeader>
                <CardTitle className="text-emerald-800">Top Performing Partners</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockTopPartners.slice(0, 3).map((partner, index) => (
                    <div key={partner.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg border border-emerald-100">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-md ${
                          index === 0 ? 'bg-gradient-to-br from-emerald-500 to-teal-600' : 
                          index === 1 ? 'bg-gradient-to-br from-teal-500 to-cyan-600' : 'bg-gradient-to-br from-amber-400 to-amber-500'
                        }`}>
                          <span className="text-white text-sm font-bold">{index + 1}</span>
                        </div>
                        <div>
                          <p className="font-medium text-emerald-900">{partner.name}</p>
                          <p className="text-sm text-emerald-600/70">{partner.volume}</p>
                        </div>
                      </div>
                      <span className="text-emerald-600 font-semibold">{partner.growth}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Collections */}
          <RecentCollections />
        </main>
      </div>
    </div>
  );
}
