import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { LanguageToggle } from "@/components/language-toggle";
import { Loader2, Building, Bike, Users, Leaf, Recycle } from "lucide-react";
import ecoKitarLogo from "@assets/1000150524_1762361284650.jpg";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const success = await login(username, password);
    
    if (!success) {
      toast({
        title: "Log Masuk Gagal",
        description: "Nama pengguna atau kata laluan tidak sah",
        variant: "destructive",
      });
    }
    
    setIsLoading(false);
  };

  const handleDemoLogin = async (role: 'jabatan' | 'ecorider' | 'ecorakyat') => {
    setIsLoading(true);
    const demoCredentials = {
      jabatan: { username: 'admin', password: 'password123' },
      ecorider: { username: 'rider1', password: 'rider123' },
      ecorakyat: { username: 'rakyat1', password: 'rakyat123' },
    }[role];
    
    const success = await login(demoCredentials.username, demoCredentials.password);
    
    if (!success) {
      toast({
        title: "Log Masuk Gagal",
        description: "Log masuk demo gagal",
        variant: "destructive",
      });
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-eco-gradient relative overflow-hidden" data-testid="login-page">
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-gradient-to-br from-emerald-200/40 to-teal-300/30 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -left-32 w-80 h-80 bg-gradient-to-br from-green-200/30 to-emerald-300/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 right-1/4 w-96 h-96 bg-gradient-to-br from-teal-200/30 to-cyan-300/20 rounded-full blur-3xl" />
        {/* Floating recycling icons */}
        <Recycle className="absolute top-20 left-[15%] w-8 h-8 text-emerald-300/40 animate-pulse" />
        <Leaf className="absolute top-32 right-[20%] w-6 h-6 text-green-300/50 animate-pulse" style={{ animationDelay: '1s' }} />
        <Recycle className="absolute bottom-40 left-[25%] w-10 h-10 text-teal-300/30 animate-pulse" style={{ animationDelay: '2s' }} />
        <Leaf className="absolute bottom-24 right-[15%] w-7 h-7 text-emerald-300/40 animate-pulse" style={{ animationDelay: '0.5s' }} />
      </div>

      {/* Language toggle */}
      <div className="absolute top-4 right-4 z-10">
        <LanguageToggle />
      </div>

      {/* Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-4">
              <img 
                src={ecoKitarLogo} 
                alt="EcoKitar Logo" 
                className="h-20 w-20 rounded-2xl object-cover shadow-lg shadow-emerald-200"
              />
            </div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-emerald-700 to-teal-600 bg-clip-text text-transparent">
              EcoKitar
            </CardTitle>
            <CardDescription className="text-base text-gray-600">
              {language === "en" ? "Malaysia's Smart Recycling Platform" : "Platform Kitar Semula Pintar Malaysia"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 pt-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-gray-700">
                  {language === "en" ? "Username" : "Nama Pengguna"}
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={language === "en" ? "Enter username" : "Masukkan nama pengguna"}
                  required
                  className="border-emerald-200 focus:border-emerald-400 focus:ring-emerald-400"
                  data-testid="input-username"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700">
                  {language === "en" ? "Password" : "Kata Laluan"}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={language === "en" ? "Enter password" : "Masukkan kata laluan"}
                  required
                  className="border-emerald-200 focus:border-emerald-400 focus:ring-emerald-400"
                  data-testid="input-password"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-lg py-5 shadow-lg shadow-emerald-200/50 transition-all duration-300" 
                disabled={isLoading}
                data-testid="button-login"
              >
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {language === "en" ? "Log In" : "Log Masuk"}
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-emerald-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white/90 px-3 text-gray-500">
                  {language === "en" ? "Demo Accounts" : "Akaun Demo"}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => handleDemoLogin('jabatan')}
                variant="outline"
                className="w-full justify-start h-auto py-3 border-2 border-emerald-200 hover:border-emerald-500 hover:bg-emerald-50/80 transition-all duration-300"
                disabled={isLoading}
                data-testid="button-demo-jabatan"
              >
                <div className="bg-emerald-100 p-2 rounded-lg mr-3">
                  <Building className="h-5 w-5 text-emerald-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-800">Jabatan (Admin)</div>
                  <div className="text-xs text-gray-500">admin / password123</div>
                </div>
              </Button>
              <Button
                onClick={() => handleDemoLogin('ecorider')}
                variant="outline"
                className="w-full justify-start h-auto py-3 border-2 border-teal-200 hover:border-teal-500 hover:bg-teal-50/80 transition-all duration-300"
                disabled={isLoading}
                data-testid="button-demo-ecorider"
              >
                <div className="bg-teal-100 p-2 rounded-lg mr-3">
                  <Bike className="h-5 w-5 text-teal-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-800">EcoRider ({language === "en" ? "Collector" : "Pengutip"})</div>
                  <div className="text-xs text-gray-500">rider1 / rider123</div>
                </div>
              </Button>
              <Button
                onClick={() => handleDemoLogin('ecorakyat')}
                variant="outline"
                className="w-full justify-start h-auto py-3 border-2 border-cyan-200 hover:border-cyan-500 hover:bg-cyan-50/80 transition-all duration-300"
                disabled={isLoading}
                data-testid="button-demo-ecorakyat"
              >
                <div className="bg-cyan-100 p-2 rounded-lg mr-3">
                  <Users className="h-5 w-5 text-cyan-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-800">EcoRakyat ({language === "en" ? "User" : "Pengguna"})</div>
                  <div className="text-xs text-gray-500">rakyat1 / rakyat123</div>
                </div>
              </Button>
            </div>

            <p className="text-center text-xs text-gray-500 pt-2">
              {language === "en" 
                ? "Together we build a greener Malaysia" 
                : "Bersama kita bina Malaysia lebih hijau"}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
