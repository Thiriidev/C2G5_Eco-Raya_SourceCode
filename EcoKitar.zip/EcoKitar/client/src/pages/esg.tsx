import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { Leaf, Droplets, Home, Globe, TrendingUp, Calculator, FileText, Settings } from "lucide-react";

const mockESGData = {
  monthlyTrends: [
    { month: "Jan", co2Saved: 65.2, oilCollected: 18500, households: 6200 },
    { month: "Feb", co2Saved: 71.8, oilCollected: 20300, households: 6800 },
    { month: "Mar", co2Saved: 73.7, oilCollected: 24567, households: 8423 },
  ],
  impactDistribution: [
    { category: "Waste Reduction", value: 35, color: "hsl(120, 70%, 50%)" },
    { category: "Carbon Savings", value: 30, color: "hsl(207, 90%, 54%)" },
    { category: "Community Engagement", value: 25, color: "hsl(60, 70%, 50%)" },
    { category: "Economic Benefits", value: 10, color: "hsl(280, 70%, 50%)" },
  ],
  sdgAlignment: [
    { goal: "SDG 12: Responsible Consumption", progress: 87 },
    { goal: "SDG 13: Climate Action", progress: 92 },
    { goal: "SDG 6: Clean Water", progress: 78 },
    { goal: "SDG 11: Sustainable Cities", progress: 85 },
  ],
};

const conversionFactors = {
  kgUCOtoCO2: 3.0,
  householdDefinition: "A household is counted when they contribute at least 1kg of UCO within a month",
  carbonCreditsPerTon: 25,
  economicValuePerKg: 2.5,
};

export default function ESG() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="ESG Metrics & Impact"
          subtitle="Environmental, Social, and Governance impact tracking and reporting"
        />
        
        <main className="p-6">
          {/* ESG Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total CO₂ Saved</p>
                    <p className="text-3xl font-bold text-gray-900">221.7 tons</p>
                    <p className="text-sm text-green-600 mt-1">YTD Impact</p>
                  </div>
                  <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                    <Leaf className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Waste Diverted</p>
                    <p className="text-3xl font-bold text-gray-900">63.4 tons</p>
                    <p className="text-sm text-blue-600 mt-1">From landfills</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Droplets className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Households Engaged</p>
                    <p className="text-3xl font-bold text-gray-900">21,423</p>
                    <p className="text-sm text-purple-600 mt-1">Community reach</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                    <Home className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">SDG Alignment</p>
                    <p className="text-3xl font-bold text-gray-900">85.5%</p>
                    <p className="text-sm text-orange-600 mt-1">Overall score</p>
                  </div>
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <Globe className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* ESG Impact Trends */}
            <Card>
              <CardHeader>
                <CardTitle>ESG Impact Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={mockESGData.monthlyTrends}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Line
                        type="monotone"
                        dataKey="co2Saved"
                        stroke="hsl(120, 70%, 50%)"
                        strokeWidth={3}
                        dot={{ fill: "hsl(120, 70%, 50%)", strokeWidth: 2, r: 4 }}
                        name="CO₂ Saved (tons)"
                      />
                      <Line
                        type="monotone"
                        dataKey="households"
                        stroke="hsl(207, 90%, 54%)"
                        strokeWidth={3}
                        dot={{ fill: "hsl(207, 90%, 54%)", strokeWidth: 2, r: 4 }}
                        name="Households"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Impact Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Impact Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={mockESGData.impactDistribution}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {mockESGData.impactDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* SDG Alignment */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>UN Sustainable Development Goals Alignment</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockESGData.sdgAlignment.map((sdg, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-900">{sdg.goal}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div
                          className="h-2 bg-green-500 rounded-full"
                          style={{ width: `${sdg.progress}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-semibold text-gray-700">{sdg.progress}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Configuration & Factors */}
          {user?.role === 'petronas' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Conversion Factors */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Conversion Factors</CardTitle>
                    <Button size="sm" variant="outline">
                      <Settings className="mr-2 h-4 w-4" />
                      Edit
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="co2-factor">CO₂ Conversion Factor (kg CO₂ per kg UCO)</Label>
                    <Input
                      id="co2-factor"
                      type="number"
                      value={conversionFactors.kgUCOtoCO2}
                      step="0.1"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="carbon-credits">Carbon Credits per Ton CO₂</Label>
                    <Input
                      id="carbon-credits"
                      type="number"
                      value={conversionFactors.carbonCreditsPerTon}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="economic-value">Economic Value per kg UCO (RM)</Label>
                    <Input
                      id="economic-value"
                      type="number"
                      value={conversionFactors.economicValuePerKg}
                      step="0.1"
                      className="mt-1"
                    />
                  </div>
                  <Separator />
                  <div>
                    <Label>Household Definition</Label>
                    <p className="text-sm text-gray-600 mt-1">
                      {conversionFactors.householdDefinition}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* ESG Reporting */}
              <Card>
                <CardHeader>
                  <CardTitle>ESG Reporting</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">Quarterly ESG Report</h4>
                      <p className="text-sm text-gray-600">Comprehensive environmental impact analysis</p>
                    </div>
                    <Button size="sm" className="bg-green-600 hover:bg-green-700">
                      <FileText className="mr-2 h-4 w-4" />
                      Generate
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">Carbon Credit Certificate</h4>
                      <p className="text-sm text-gray-600">Official carbon savings verification</p>
                    </div>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      <Calculator className="mr-2 h-4 w-4" />
                      Calculate
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">Community Impact Report</h4>
                      <p className="text-sm text-gray-600">Social engagement and outreach metrics</p>
                    </div>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                      <TrendingUp className="mr-2 h-4 w-4" />
                      Analyze
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
