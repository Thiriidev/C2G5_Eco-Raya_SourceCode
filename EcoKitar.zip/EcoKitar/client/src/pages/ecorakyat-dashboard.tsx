import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/i18n";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { LanguageToggle } from "@/components/language-toggle";
import { 
  Camera, MapPin, Send, Recycle, AlertTriangle, Leaf, 
  TrendingUp, Package, MessageCircle, Navigation, LogOut,
  Home, Plus, History, User, Bot, Gift, Coins, Wallet, Tag, CheckCircle, Star
} from "lucide-react";
import type { RecyclableItem, Report, Voucher, UserVoucher, RewardTransaction } from "@shared/schema";
import { CATEGORY_COLORS, CATEGORIES, REWARD_RATES } from "@shared/schema";
import ecoKitarLogo from "@assets/1000150524_1762361284650.jpg";

const CATEGORY_LABELS: Record<string, { en: string; ms: string }> = {
  plastic: { en: "Plastic", ms: "Plastik" },
  paper: { en: "Paper", ms: "Kertas" },
  glass: { en: "Glass", ms: "Kaca" },
  metal: { en: "Metal", ms: "Logam" },
  ewaste: { en: "E-Waste", ms: "E-Sisa" },
  batteries: { en: "Batteries", ms: "Bateri" },
  cooking_oil: { en: "Cooking Oil", ms: "Minyak Masak" },
  textiles: { en: "Textiles", ms: "Tekstil" },
  appliances: { en: "Appliances", ms: "Peralatan" },
  organic: { en: "Organic", ms: "Organik" },
  special_waste: { en: "Special Waste", ms: "Sisa Khas" },
};

function FormattedAIMessage({ content }: { content: string }) {
  const formatText = (text: string) => {
    const parts: JSX.Element[] = [];
    let key = 0;
    
    const lines = text.split('\n');
    
    lines.forEach((line, lineIndex) => {
      if (lineIndex > 0) {
        parts.push(<br key={`br-${key++}`} />);
      }
      
      if (line.startsWith('- ') || line.startsWith('* ') || line.match(/^\d+\.\s/)) {
        const bulletContent = line.replace(/^[-*]\s|^\d+\.\s/, '');
        parts.push(
          <div key={`bullet-${key++}`} className="flex gap-2 ml-2">
            <span className="text-green-600">•</span>
            <span>{formatInlineText(bulletContent)}</span>
          </div>
        );
      } else {
        parts.push(<span key={`line-${key++}`}>{formatInlineText(line)}</span>);
      }
    });
    
    return parts;
  };
  
  const formatInlineText = (text: string): (string | JSX.Element)[] => {
    const parts: (string | JSX.Element)[] = [];
    let remaining = text;
    let key = 0;
    
    while (remaining.length > 0) {
      const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
      
      if (boldMatch && boldMatch.index !== undefined) {
        if (boldMatch.index > 0) {
          parts.push(remaining.substring(0, boldMatch.index));
        }
        parts.push(
          <strong key={`bold-${key++}`} className="font-semibold text-green-700">
            {boldMatch[1]}
          </strong>
        );
        remaining = remaining.substring(boldMatch.index + boldMatch[0].length);
      } else {
        parts.push(remaining);
        remaining = '';
      }
    }
    
    return parts;
  };
  
  return <div className="text-sm space-y-1">{formatText(content)}</div>;
}

interface LocationData {
  latitude: number;
  longitude: number;
  address?: string;
}

export default function EcoRakyatDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState("home");
  
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [aiChatOpen, setAiChatOpen] = useState(false);
  
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [itemDescription, setItemDescription] = useState("");
  const [weightEstimate, setWeightEstimate] = useState("");
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [reportTitle, setReportTitle] = useState("");
  const [reportDescription, setReportDescription] = useState("");
  const [reportSeverity, setReportSeverity] = useState("medium");
  const [reportPhotoPreview, setReportPhotoPreview] = useState<string | null>(null);
  const reportFileInputRef = useRef<HTMLInputElement>(null);
  
  const [aiMessage, setAiMessage] = useState("");
  const [aiConversation, setAiConversation] = useState<{
    role: string; 
    content: string; 
    hasImage?: boolean; 
    imagePreview?: string;
    recyclingCentres?: Array<{
      name: string;
      address: string;
      lat: number;
      lng: number;
      distanceKm: number;
    }>;
  }[]>([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiPhotoPreview, setAiPhotoPreview] = useState<string | null>(null);
  const aiFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) {
      setLocation("/login");
      return;
    }
    if (user.role !== "ecorakyat") {
      if (user.role === "jabatan") {
        setLocation("/jabatan");
      } else if (user.role === "ecorider") {
        setLocation("/ecorider");
      }
    }
  }, [user, setLocation]);

  const { data: stats } = useQuery<{
    totalItems: number;
    collectedItems: number;
    pendingItems: number;
    totalWeight: number;
    co2Saved: number;
    reportsSubmitted: number;
    reportsResolved: number;
  }>({
    queryKey: ["/api/ecorakyat/stats", user?.id],
    enabled: !!user?.id,
  });

  const { data: myItems = [] } = useQuery<RecyclableItem[]>({
    queryKey: ["/api/recyclable-items", "user", user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/recyclable-items?userId=${user?.id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch items");
      return res.json();
    },
    enabled: !!user?.id,
  });

  const { data: myReports = [] } = useQuery<Report[]>({
    queryKey: ["/api/reports", "user", user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/reports?userId=${user?.id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch reports");
      return res.json();
    },
    enabled: !!user?.id,
  });

  const { data: rewardsSummary } = useQuery<{
    totalPoints: number;
    totalCashback: number;
    lifetimePoints: number;
    lifetimeCashback: number;
  }>({
    queryKey: ["/api/rewards/summary"],
    enabled: !!user?.id,
  });

  const { data: availableVouchers = [] } = useQuery<Voucher[]>({
    queryKey: ["/api/vouchers"],
    enabled: !!user?.id,
  });

  const { data: myVouchers = [] } = useQuery<UserVoucher[]>({
    queryKey: ["/api/vouchers/my"],
    enabled: !!user?.id,
  });

  const { data: rewardTransactions = [] } = useQuery<RewardTransaction[]>({
    queryKey: ["/api/rewards/transactions"],
    enabled: !!user?.id,
  });

  const redeemVoucherMutation = useMutation({
    mutationFn: async (voucherId: number) => {
      const res = await apiRequest("POST", `/api/vouchers/${voucherId}/redeem`);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: language === "en" ? "Voucher Redeemed!" : "Baucar Ditebus!",
        description: language === "en" 
          ? `Your redemption code: ${data.redemptionCode}` 
          : `Kod tebusan anda: ${data.redemptionCode}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/vouchers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/vouchers/my"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rewards/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rewards/transactions"] });
    },
    onError: (error: Error) => {
      toast({
        title: language === "en" ? "Redemption Failed" : "Tebusan Gagal",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const requestLocation = () => {
    setIsGettingLocation(true);
    setLocationError(null);
    
    if (!navigator.geolocation) {
      setLocationError(t("location_not_supported"));
      setIsGettingLocation(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        let address = "";
        
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`
          );
          const data = await response.json();
          address = data.display_name || "";
        } catch (e) {
          console.log("Could not fetch address");
        }
        
        setCurrentLocation({ latitude, longitude, address });
        setIsGettingLocation(false);
        toast({
          title: t("location_obtained"),
          description: address || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
        });
      },
      (error) => {
        setLocationError(t("location_error"));
        setIsGettingLocation(false);
        toast({
          title: t("location_error_title"),
          description: t("enable_gps"),
          variant: "destructive",
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleReportPhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReportPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const createItemMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/recyclable-items", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recyclable-items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorakyat/stats"] });
      setItemDialogOpen(false);
      resetItemForm();
      toast({
        title: t("success"),
        description: t("item_submitted"),
      });
    },
    onError: () => {
      toast({
        title: t("error"),
        description: t("failed_submit_item"),
        variant: "destructive",
      });
    },
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/reports", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorakyat/stats"] });
      setReportDialogOpen(false);
      resetReportForm();
      toast({
        title: t("report_submitted"),
        description: t("thank_you_report"),
      });
    },
    onError: () => {
      toast({
        title: t("error"),
        description: t("failed_submit_report"),
        variant: "destructive",
      });
    },
  });

  const resetItemForm = () => {
    setSelectedCategory("");
    setItemDescription("");
    setWeightEstimate("");
    setPhotoPreview(null);
    setCurrentLocation(null);
  };

  const resetReportForm = () => {
    setReportTitle("");
    setReportDescription("");
    setReportSeverity("medium");
    setReportPhotoPreview(null);
    setCurrentLocation(null);
  };

  const handleSubmitItem = () => {
    if (!currentLocation) {
      toast({
        title: t("location_required"),
        description: t("enable_location_first"),
        variant: "destructive",
      });
      return;
    }
    if (!selectedCategory) {
      toast({
        title: t("category_required"),
        description: t("select_recycling_category"),
        variant: "destructive",
      });
      return;
    }

    createItemMutation.mutate({
      userId: user?.id,
      category: selectedCategory,
      description: itemDescription || null,
      weightEstimateKg: weightEstimate ? weightEstimate : null,
      latitude: currentLocation.latitude.toString(),
      longitude: currentLocation.longitude.toString(),
      address: currentLocation.address || null,
      photoUrl: photoPreview || null,
      status: "new",
    });
  };

  const handleSubmitReport = () => {
    if (!currentLocation) {
      toast({
        title: t("location_required"),
        description: t("enable_location_first"),
        variant: "destructive",
      });
      return;
    }
    if (!reportTitle.trim()) {
      toast({
        title: t("title_required"),
        description: t("enter_report_title"),
        variant: "destructive",
      });
      return;
    }

    createReportMutation.mutate({
      userId: user?.id,
      title: reportTitle,
      description: reportDescription || null,
      severity: reportSeverity,
      latitude: currentLocation.latitude.toString(),
      longitude: currentLocation.longitude.toString(),
      address: currentLocation.address || null,
      photoUrl: reportPhotoPreview || null,
      status: "new",
    });
  };

  const handleAiPhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAiPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAiChat = async () => {
    if (!aiMessage.trim() && !aiPhotoPreview) return;
    
    const userMessage = aiMessage || (language === "en" ? "Please analyze this item" : "Sila analisis item ini");
    const hasImage = !!aiPhotoPreview;
    const imagePreview = aiPhotoPreview || undefined;
    
    setAiConversation(prev => [...prev, { 
      role: "user", 
      content: userMessage, 
      hasImage, 
      imagePreview 
    }]);
    setAiMessage("");
    const currentPhoto = aiPhotoPreview;
    setAiPhotoPreview(null);
    setAiLoading(true);

    try {
      const imageBase64 = currentPhoto ? currentPhoto.split(",")[1] : undefined;
      
      // Use current location if available (already captured from browser)
      const userLocation = currentLocation 
        ? { lat: currentLocation.latitude, lng: currentLocation.longitude }
        : undefined;
      
      const response = await apiRequest("POST", "/api/ai/recycling-advice", { 
        message: userMessage, 
        imageBase64,
        language,
        conversationHistory: aiConversation,
        userLocation
      });
      const data = await response.json();
      setAiConversation(prev => [...prev, { 
        role: "assistant", 
        content: data.response,
        hasImage: data.hasImage,
        recyclingCentres: data.recyclingCentres
      }]);
    } catch (error) {
      setAiConversation(prev => [...prev, { 
        role: "assistant", 
        content: language === "en" 
          ? "Sorry, I couldn't process your request. Please try again." 
          : "Maaf, saya tidak dapat memproses permintaan anda. Sila cuba lagi." 
      }]);
    } finally {
      setAiLoading(false);
    }
  };

  const clearAiChat = () => {
    setAiConversation([]);
    setAiPhotoPreview(null);
    setAiMessage("");
    setAiLoading(false);
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { labelKey: string; variant: "default" | "secondary" | "outline" | "destructive" }> = {
      new: { labelKey: "status_new", variant: "default" },
      assigned: { labelKey: "status_assigned", variant: "secondary" },
      in_progress: { labelKey: "status_in_progress", variant: "outline" },
      collected: { labelKey: "status_collected", variant: "default" },
      resolved: { labelKey: "status_resolved", variant: "default" },
      cancelled: { labelKey: "status_cancelled", variant: "destructive" },
    };
    const { labelKey, variant } = statusMap[status] || { labelKey: status, variant: "outline" as const };
    return <Badge variant={variant}>{t(labelKey)}</Badge>;
  };

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-eco-gradient" data-testid="ecorakyat-dashboard">
      <div className="max-w-md mx-auto pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-6 rounded-b-3xl shadow-xl">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-3">
              <img 
                src={ecoKitarLogo} 
                alt="EcoKitar Logo" 
                className="h-12 w-12 rounded-xl object-cover shadow-md"
              />
              <div>
                <p className="text-emerald-100 text-sm">{t("welcome")},</p>
                <h1 className="text-2xl font-bold" data-testid="user-name">{user.name}</h1>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <div className="text-emerald-100">
                <LanguageToggle />
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-emerald-700/50"
                onClick={handleLogout}
                data-testid="button-logout"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center border border-white/10">
              <Package className="h-5 w-5 mx-auto mb-1" />
              <p className="text-2xl font-bold" data-testid="stat-items">{stats?.totalItems || 0}</p>
              <p className="text-xs text-emerald-100">{t("items")}</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center border border-white/10">
              <TrendingUp className="h-5 w-5 mx-auto mb-1" />
              <p className="text-2xl font-bold" data-testid="stat-weight">{stats?.totalWeight?.toFixed(1) || 0}</p>
              <p className="text-xs text-emerald-100">{t("kg_recycled")}</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center border border-white/10">
              <Leaf className="h-5 w-5 mx-auto mb-1" />
              <p className="text-2xl font-bold" data-testid="stat-co2">{stats?.co2Saved?.toFixed(1) || 0}</p>
              <p className="text-xs text-emerald-100">{t("kg_co2")}</p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-4 space-y-4">
          {activeTab === "home" && (
            <>
              {/* Quick Actions */}
              <Card className="border-none shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-emerald-800">{t("quick_actions")}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3">
                    <Dialog open={itemDialogOpen} onOpenChange={setItemDialogOpen}>
                      <DialogTrigger asChild>
                        <Button
                          className="h-24 flex-col gap-2 bg-gradient-to-br from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg shadow-emerald-200/50 transition-all duration-300"
                          data-testid="button-add-item"
                        >
                          <Recycle className="h-8 w-8" />
                          <span>{t("submit_item")}</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="text-green-800">{t("submit_recyclable")}</DialogTitle>
                          <DialogDescription>
                            {t("location_required_collection")}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          {/* Location */}
                          <div>
                            <Button
                              variant={currentLocation ? "outline" : "default"}
                              className="w-full"
                              onClick={requestLocation}
                              disabled={isGettingLocation}
                              data-testid="button-get-location"
                            >
                              <MapPin className="h-4 w-4 mr-2" />
                              {isGettingLocation
                                ? t("getting_location")
                                : currentLocation
                                ? t("location_obtained")
                                : t("enable_location")}
                            </Button>
                            {currentLocation && (
                              <p className="text-xs text-gray-500 mt-1 truncate">
                                {currentLocation.address || `${currentLocation.latitude.toFixed(4)}, ${currentLocation.longitude.toFixed(4)}`}
                              </p>
                            )}
                            {locationError && (
                              <p className="text-xs text-red-500 mt-1">{locationError}</p>
                            )}
                          </div>

                          {/* Photo */}
                          <div>
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              ref={fileInputRef}
                              className="hidden"
                              onChange={handlePhotoCapture}
                              data-testid="input-photo"
                            />
                            <Button
                              variant="outline"
                              className="w-full"
                              onClick={() => fileInputRef.current?.click()}
                              data-testid="button-take-photo"
                            >
                              <Camera className="h-4 w-4 mr-2" />
                              {photoPreview ? t("change_photo") : t("take_photo")}
                            </Button>
                            {photoPreview && (
                              <img
                                src={photoPreview}
                                alt="Preview"
                                className="mt-2 rounded-lg w-full h-32 object-cover"
                              />
                            )}
                          </div>

                          {/* Category */}
                          <div>
                            <label className="text-sm font-medium text-gray-700">{t("category")}</label>
                            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                              <SelectTrigger data-testid="select-category">
                                <SelectValue placeholder={t("select_category")} />
                              </SelectTrigger>
                              <SelectContent>
                                {CATEGORIES.map((cat) => (
                                  <SelectItem key={cat} value={cat}>
                                    <div className="flex items-center gap-2">
                                      <div
                                        className="w-3 h-3 rounded-full"
                                        style={{ backgroundColor: CATEGORY_COLORS[cat] }}
                                      />
                                      {CATEGORY_LABELS[cat]?.[language] || cat}
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          {/* Weight Estimate */}
                          <div>
                            <label className="text-sm font-medium text-gray-700">{t("weight_estimate")}</label>
                            <Input
                              type="number"
                              step="0.1"
                              placeholder={t("example_weight")}
                              value={weightEstimate}
                              onChange={(e) => setWeightEstimate(e.target.value)}
                              data-testid="input-weight"
                            />
                          </div>

                          {/* Description */}
                          <div>
                            <label className="text-sm font-medium text-gray-700">{t("description")}</label>
                            <Textarea
                              placeholder={t("example_description")}
                              value={itemDescription}
                              onChange={(e) => setItemDescription(e.target.value)}
                              data-testid="input-description"
                            />
                          </div>

                          <Button
                            className="w-full bg-green-600 hover:bg-green-700"
                            onClick={handleSubmitItem}
                            disabled={createItemMutation.isPending}
                            data-testid="button-submit-item"
                          >
                            <Send className="h-4 w-4 mr-2" />
                            {createItemMutation.isPending ? t("submitting") : t("submit")}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          className="h-24 flex-col gap-2 border-orange-200 text-orange-600 hover:bg-orange-50"
                          data-testid="button-add-report"
                        >
                          <AlertTriangle className="h-8 w-8" />
                          <span>{t("report_issue")}</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="text-orange-800">{t("report_illegal_dumping")}</DialogTitle>
                          <DialogDescription>
                            {t("help_clean_area")}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          {/* Location */}
                          <div>
                            <Button
                              variant={currentLocation ? "outline" : "default"}
                              className="w-full"
                              onClick={requestLocation}
                              disabled={isGettingLocation}
                              data-testid="button-report-location"
                            >
                              <MapPin className="h-4 w-4 mr-2" />
                              {isGettingLocation
                                ? t("getting_location")
                                : currentLocation
                                ? t("location_obtained")
                                : t("enable_location")}
                            </Button>
                            {currentLocation && (
                              <p className="text-xs text-gray-500 mt-1 truncate">
                                {currentLocation.address || `${currentLocation.latitude.toFixed(4)}, ${currentLocation.longitude.toFixed(4)}`}
                              </p>
                            )}
                          </div>

                          {/* Photo */}
                          <div>
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              ref={reportFileInputRef}
                              className="hidden"
                              onChange={handleReportPhotoCapture}
                              data-testid="input-report-photo"
                            />
                            <Button
                              variant="outline"
                              className="w-full"
                              onClick={() => reportFileInputRef.current?.click()}
                              data-testid="button-report-photo"
                            >
                              <Camera className="h-4 w-4 mr-2" />
                              {reportPhotoPreview ? t("change_photo") : t("take_photo")}
                            </Button>
                            {reportPhotoPreview && (
                              <img
                                src={reportPhotoPreview}
                                alt="Preview"
                                className="mt-2 rounded-lg w-full h-32 object-cover"
                              />
                            )}
                          </div>

                          {/* Title */}
                          <div>
                            <label className="text-sm font-medium text-gray-700">{t("title")}</label>
                            <Input
                              placeholder={language === "en" ? "Example: Garbage piling up in alley" : "Contoh: Sampah bertimbun di lorong"}
                              value={reportTitle}
                              onChange={(e) => setReportTitle(e.target.value)}
                              data-testid="input-report-title"
                            />
                          </div>

                          {/* Severity */}
                          <div>
                            <label className="text-sm font-medium text-gray-700">{t("severity")}</label>
                            <Select value={reportSeverity} onValueChange={setReportSeverity}>
                              <SelectTrigger data-testid="select-severity">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">{t("low")}</SelectItem>
                                <SelectItem value="medium">{t("medium")}</SelectItem>
                                <SelectItem value="high">{t("high")}</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {/* Description */}
                          <div>
                            <label className="text-sm font-medium text-gray-700">{t("description")}</label>
                            <Textarea
                              placeholder={t("describe_issue")}
                              value={reportDescription}
                              onChange={(e) => setReportDescription(e.target.value)}
                              data-testid="input-report-description"
                            />
                          </div>

                          <Button
                            className="w-full bg-orange-600 hover:bg-orange-700"
                            onClick={handleSubmitReport}
                            disabled={createReportMutation.isPending}
                            data-testid="button-submit-report"
                          >
                            <Send className="h-4 w-4 mr-2" />
                            {createReportMutation.isPending ? t("submitting") : (language === "en" ? "Submit Report" : "Hantar Laporan")}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>

              {/* AI Assistant */}
              <Dialog open={aiChatOpen} onOpenChange={(open) => {
                setAiChatOpen(open);
                if (!open) {
                  clearAiChat();
                }
              }}>
                <DialogTrigger asChild>
                  <Card className="border-none shadow-lg cursor-pointer hover:shadow-xl transition-all duration-300 bg-gradient-to-r from-emerald-50 to-teal-50 hover:from-emerald-100 hover:to-teal-100">
                    <CardContent className="p-4 flex items-center gap-4">
                      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full p-3 shadow-md">
                        <Bot className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-emerald-800">{t("ai_recycling_coach")}</h3>
                        <p className="text-sm text-emerald-600/70">{t("ask_recycling")}</p>
                      </div>
                      <MessageCircle className="h-5 w-5 text-emerald-400" />
                    </CardContent>
                  </Card>
                </DialogTrigger>
                <DialogContent className="max-w-md h-[80vh] flex flex-col">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Bot className="h-5 w-5 text-emerald-600" />
                      {t("ai_recycling_coach")}
                    </DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="flex-1 pr-4">
                    <div className="space-y-4">
                      {aiConversation.length === 0 && (
                        <div className="text-center py-6 text-gray-500">
                          <Camera className="h-10 w-10 mx-auto mb-2 text-emerald-400" />
                          <p className="font-medium text-emerald-700">{t("snap_to_recycle")}</p>
                          <p className="text-xs mt-1 text-emerald-600/60">{t("take_photo_or_ask")}</p>
                        </div>
                      )}
                      {aiConversation.map((msg, i) => (
                        <div
                          key={i}
                          className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-[85%] rounded-2xl px-4 py-2 ${
                              msg.role === "user"
                                ? "bg-green-600 text-white"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {msg.imagePreview && (
                              <img 
                                src={msg.imagePreview} 
                                alt="Uploaded item" 
                                className="rounded-lg mb-2 max-h-32 w-auto"
                              />
                            )}
                            {msg.role === "assistant" ? (
                              <>
                                <FormattedAIMessage content={msg.content} />
                                {msg.recyclingCentres && msg.recyclingCentres.length > 0 && (
                                  <div className="mt-3 space-y-2">
                                    {msg.recyclingCentres.map((centre, idx) => (
                                      <div 
                                        key={idx} 
                                        className="bg-white rounded-lg p-3 border border-emerald-200 shadow-sm"
                                        data-testid={`recycling-centre-card-${idx}`}
                                      >
                                        <div className="flex items-start justify-between gap-2">
                                          <div className="flex-1 min-w-0">
                                            <p className="font-medium text-emerald-800 text-sm truncate">{centre.name}</p>
                                            <p className="text-xs text-gray-500 truncate">{centre.address}</p>
                                            <p className="text-xs text-emerald-600 mt-1">{centre.distanceKm} km {language === "en" ? "away" : ""}</p>
                                          </div>
                                          <Button
                                            size="sm"
                                            className="bg-blue-600 hover:bg-blue-700 text-white shrink-0"
                                            onClick={() => {
                                              const url = `https://www.google.com/maps/dir/?api=1&destination=${centre.lat},${centre.lng}`;
                                              window.open(url, '_blank');
                                            }}
                                            data-testid={`button-maps-${idx}`}
                                          >
                                            <Navigation className="h-3 w-3 mr-1" />
                                            {language === "en" ? "Maps" : "Peta"}
                                          </Button>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </>
                            ) : (
                              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            )}
                          </div>
                        </div>
                      ))}
                      {aiLoading && (
                        <div className="flex justify-start">
                          <div className="bg-gray-100 rounded-2xl px-4 py-2">
                            <p className="text-sm text-gray-500">{t("ai_analyzing_item")}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                  
                  {/* Photo Preview */}
                  {aiPhotoPreview && (
                    <div className="relative mx-2 mb-2">
                      <img 
                        src={aiPhotoPreview} 
                        alt="Preview" 
                        className="rounded-lg w-full h-24 object-cover border-2 border-emerald-300"
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-1 right-1 h-6 w-6"
                        onClick={() => setAiPhotoPreview(null)}
                      >
                        <span className="text-xs">✕</span>
                      </Button>
                    </div>
                  )}
                  
                  {/* Input Area */}
                  <div className="space-y-2 pt-2 border-t">
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      ref={aiFileInputRef}
                      className="hidden"
                      onChange={handleAiPhotoCapture}
                      data-testid="input-ai-photo"
                    />
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => aiFileInputRef.current?.click()}
                        disabled={aiLoading}
                        className="shrink-0 border-emerald-300 text-emerald-600 hover:bg-emerald-50"
                        data-testid="button-ai-photo"
                      >
                        <Camera className="h-4 w-4" />
                      </Button>
                      <Input
                        placeholder={aiPhotoPreview ? t("describe_item") : t("type_your_question")}
                        value={aiMessage}
                        onChange={(e) => setAiMessage(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleAiChat()}
                        disabled={aiLoading}
                        data-testid="input-ai-message"
                      />
                      <Button
                        onClick={handleAiChat}
                        disabled={aiLoading || (!aiMessage.trim() && !aiPhotoPreview)}
                        className="bg-emerald-600 hover:bg-emerald-700 shrink-0"
                        data-testid="button-send-ai"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                    {aiConversation.length > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearAiChat}
                        className="w-full text-gray-500 hover:text-gray-700"
                        data-testid="button-clear-chat"
                      >
                        {t("new_conversation")}
                      </Button>
                    )}
                  </div>
                </DialogContent>
              </Dialog>

              {/* Recent Items */}
              <Card className="border-none shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-emerald-800">
                    {language === "en" ? "Recent Items" : "Item Terkini"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {myItems.length === 0 ? (
                    <p className="text-center py-4 text-emerald-600/70">
                      {language === "en" ? "No items yet. Submit your first item!" : "Belum ada item. Hantar item pertama anda!"}
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {myItems.slice(0, 3).map((item) => (
                        <div
                          key={item.id}
                          className="flex items-center gap-3 p-3 bg-emerald-50/50 rounded-xl border border-emerald-100"
                          data-testid={`item-${item.id}`}
                        >
                          <div
                            className="w-10 h-10 rounded-full flex items-center justify-center"
                            style={{ backgroundColor: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] + "20" }}
                          >
                            <Recycle
                              className="h-5 w-5"
                              style={{ color: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] }}
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-gray-800 truncate">
                              {CATEGORY_LABELS[item.category]?.[language] || item.category}
                            </p>
                            <p className="text-xs text-gray-500">
                              {item.weightEstimateKg ? `${item.weightEstimateKg} kg` : (language === "en" ? "Weight not specified" : "Berat tidak dinyatakan")}
                            </p>
                          </div>
                          {getStatusBadge(item.status)}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}

          {activeTab === "history" && (
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg text-green-800">{t("history")}</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="items">
                  <TabsList className="w-full">
                    <TabsTrigger value="items" className="flex-1">{t("items")}</TabsTrigger>
                    <TabsTrigger value="reports" className="flex-1">{t("reports")}</TabsTrigger>
                  </TabsList>
                  <TabsContent value="items" className="mt-4">
                    {myItems.length === 0 ? (
                      <p className="text-center py-8 text-gray-500">{t("no_items_yet")}</p>
                    ) : (
                      <div className="space-y-3">
                        {myItems.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl"
                            data-testid={`history-item-${item.id}`}
                          >
                            <div
                              className="w-10 h-10 rounded-full flex items-center justify-center"
                              style={{ backgroundColor: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] + "20" }}
                            >
                              <Recycle
                                className="h-5 w-5"
                                style={{ color: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] }}
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-gray-800">
                                {CATEGORY_LABELS[item.category]?.[language] || item.category}
                              </p>
                              <p className="text-xs text-gray-500">
                                {item.createdAt ? new Date(item.createdAt).toLocaleDateString("ms-MY") : ""}
                              </p>
                            </div>
                            {getStatusBadge(item.status)}
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  <TabsContent value="reports" className="mt-4">
                    {myReports.length === 0 ? (
                      <p className="text-center py-8 text-gray-500">{t("no_reports_yet")}</p>
                    ) : (
                      <div className="space-y-3">
                        {myReports.map((report) => (
                          <div
                            key={report.id}
                            className="p-3 bg-gray-50 rounded-xl"
                            data-testid={`history-report-${report.id}`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <p className="font-medium text-gray-800">{report.title}</p>
                              {getStatusBadge(report.status)}
                            </div>
                            <p className="text-xs text-gray-500">
                              {report.createdAt ? new Date(report.createdAt).toLocaleDateString("ms-MY") : ""}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}

          {activeTab === "profile" && (
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg text-green-800">{language === "en" ? "My Profile" : "Profil Saya"}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                    <User className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{user.name}</h3>
                    <p className="text-gray-500">{user.email}</p>
                    <Badge className="mt-1 bg-green-100 text-green-800">EcoRakyat</Badge>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-green-600">{stats?.totalItems || 0}</p>
                    <p className="text-sm text-gray-500">{t("total_items")}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-green-600">{stats?.reportsSubmitted || 0}</p>
                    <p className="text-sm text-gray-500">{t("report_submitted")}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-green-600">{stats?.totalWeight?.toFixed(1) || 0}</p>
                    <p className="text-sm text-gray-500">{t("kg_recycled")}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-green-600">{stats?.co2Saved?.toFixed(1) || 0}</p>
                    <p className="text-sm text-gray-500">{t("co2_saved_short")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "rewards" && (
            <div className="space-y-4">
              <Card className="border-none shadow-lg bg-gradient-to-br from-green-500 to-emerald-600 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm opacity-90">{language === "en" ? "Total Points" : "Jumlah Mata"}</p>
                      <p className="text-3xl font-bold" data-testid="text-total-points">{rewardsSummary?.totalPoints || 0}</p>
                    </div>
                    <div className="bg-white/20 p-3 rounded-full">
                      <Coins className="h-8 w-8" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-white/20">
                    <div>
                      <p className="text-sm opacity-90">{language === "en" ? "Cashback Balance" : "Baki Pulangan Tunai"}</p>
                      <p className="text-2xl font-bold" data-testid="text-cashback-balance">RM {(rewardsSummary?.totalCashback || 0).toFixed(2)}</p>
                    </div>
                    <div className="bg-white/20 p-3 rounded-full">
                      <Wallet className="h-6 w-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-green-800 flex items-center gap-2">
                    <Star className="h-5 w-5" />
                    {language === "en" ? "Reward Rates" : "Kadar Ganjaran"}
                  </CardTitle>
                  <CardDescription>
                    {language === "en" ? "Points & cashback per kg" : "Mata & pulangan tunai setiap kg"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {Object.entries(REWARD_RATES).slice(0, 6).map(([category, rates]) => (
                      <div key={category} className="flex items-center justify-between bg-gray-50 p-2 rounded-lg">
                        <span className="font-medium capitalize">{CATEGORY_LABELS[category]?.[language] || category}</span>
                        <span className="text-green-600">{rates.pointsPerKg}pts</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-green-800 flex items-center gap-2">
                    <Tag className="h-5 w-5" />
                    {language === "en" ? "Available Vouchers" : "Baucar Tersedia"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {availableVouchers.length === 0 ? (
                    <p className="text-center py-6 text-gray-500">
                      {language === "en" ? "No vouchers available" : "Tiada baucar tersedia"}
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {availableVouchers.map((voucher) => (
                        <div 
                          key={voucher.id} 
                          className="bg-gray-50 p-4 rounded-xl flex items-center justify-between"
                          data-testid={`voucher-${voucher.id}`}
                        >
                          <div className="flex-1">
                            <p className="font-semibold text-gray-800">{voucher.name}</p>
                            <p className="text-sm text-gray-500">{voucher.description}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="text-green-600 border-green-200">
                                <Coins className="h-3 w-3 mr-1" />
                                {voucher.pointsCost} {language === "en" ? "points" : "mata"}
                              </Badge>
                              {voucher.value && (
                                <Badge variant="secondary">
                                  RM{voucher.value} OFF
                                </Badge>
                              )}
                            </div>
                          </div>
                          <Button
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                            disabled={
                              (rewardsSummary?.totalPoints || 0) < voucher.pointsCost ||
                              redeemVoucherMutation.isPending
                            }
                            onClick={() => redeemVoucherMutation.mutate(voucher.id)}
                            data-testid={`button-redeem-${voucher.id}`}
                          >
                            {redeemVoucherMutation.isPending ? "..." : language === "en" ? "Redeem" : "Tebus"}
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-green-800 flex items-center gap-2">
                    <Gift className="h-5 w-5" />
                    {language === "en" ? "My Vouchers" : "Baucar Saya"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {myVouchers.length === 0 ? (
                    <p className="text-center py-6 text-gray-500">
                      {language === "en" ? "No redeemed vouchers yet" : "Belum ada baucar ditebus"}
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {myVouchers.map((uv) => (
                        <div 
                          key={uv.id} 
                          className={`p-4 rounded-xl border-2 ${
                            uv.status === "active" ? "border-green-200 bg-green-50" : "border-gray-200 bg-gray-50"
                          }`}
                          data-testid={`my-voucher-${uv.id}`}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-mono text-lg font-bold text-green-700">{uv.code}</p>
                              <p className="text-xs text-gray-500">
                                {language === "en" ? "Expires:" : "Tamat:"} {uv.expiresAt ? new Date(uv.expiresAt).toLocaleDateString("ms-MY") : "N/A"}
                              </p>
                            </div>
                            <Badge className={uv.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-600"}>
                              {uv.status === "active" ? (
                                <><CheckCircle className="h-3 w-3 mr-1" /> {language === "en" ? "Active" : "Aktif"}</>
                              ) : (
                                language === "en" ? "Used" : "Digunakan"
                              )}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-green-800 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    {language === "en" ? "Recent Transactions" : "Transaksi Terkini"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {rewardTransactions.length === 0 ? (
                    <p className="text-center py-6 text-gray-500">
                      {language === "en" ? "No transactions yet" : "Belum ada transaksi"}
                    </p>
                  ) : (
                    <ScrollArea className="h-48">
                      <div className="space-y-2">
                        {rewardTransactions.slice(0, 10).map((tx) => (
                          <div 
                            key={tx.id}
                            className="flex items-center justify-between py-2 border-b border-gray-100"
                            data-testid={`transaction-${tx.id}`}
                          >
                            <div>
                              <p className="font-medium text-sm text-gray-800">{tx.description}</p>
                              <p className="text-xs text-gray-500">
                                {tx.createdAt ? new Date(tx.createdAt).toLocaleDateString("ms-MY") : ""}
                              </p>
                            </div>
                            <div className="text-right">
                              {tx.points && tx.points !== 0 && (
                                <p className={`font-semibold ${Number(tx.points) > 0 ? "text-green-600" : "text-red-500"}`}>
                                  {Number(tx.points) > 0 ? "+" : ""}{tx.points} pts
                                </p>
                              )}
                              {tx.cashback && parseFloat(tx.cashback.toString()) > 0 && (
                                <p className="font-semibold text-green-600">
                                  +RM{parseFloat(tx.cashback.toString()).toFixed(2)}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="max-w-md mx-auto flex justify-around py-2">
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "home" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("home")}
            data-testid="nav-home"
          >
            <Home className="h-5 w-5" />
            <span className="text-xs">{t("home")}</span>
          </Button>
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "rewards" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("rewards")}
            data-testid="nav-rewards"
          >
            <Gift className="h-5 w-5" />
            <span className="text-xs">{language === "en" ? "Rewards" : "Ganjaran"}</span>
          </Button>
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "history" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("history")}
            data-testid="nav-history"
          >
            <History className="h-5 w-5" />
            <span className="text-xs">{t("history")}</span>
          </Button>
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "profile" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("profile")}
            data-testid="nav-profile"
          >
            <User className="h-5 w-5" />
            <span className="text-xs">{t("profile")}</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
