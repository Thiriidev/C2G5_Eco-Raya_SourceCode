import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  User, 
  Shield, 
  Key, 
  Database, 
  Bell, 
  Globe, 
  Download, 
  Upload, 
  Trash2, 
  Plus,
  Edit,
  Eye,
  EyeOff
} from "lucide-react";

const mockUsers = [
  { id: 1, name: "Ahmad Rahman", email: "ahmad.rahman@petronas.com", role: "petronas", status: "active", lastLogin: "2024-03-15 14:30" },
  { id: 2, name: "NEOS Collector", email: "neos@collector.com", role: "collector", status: "active", lastLogin: "2024-03-15 13:45" },
  { id: 3, name: "Sarah Abdullah", email: "sarah.abdullah@petronas.com", role: "petronas", status: "active", lastLogin: "2024-03-14 16:22" },
  { id: 4, name: "Chen Li Hua", email: "li.hua@aucosb.com", role: "collector", status: "inactive", lastLogin: "2024-03-10 09:15" },
];

const mockAPIKeys = [
  { id: 1, name: "Setel Points API", key: "sk_live_**********************abc123", created: "2024-02-15", lastUsed: "2024-03-15", status: "active" },
  { id: 2, name: "Mesra Rewards API", key: "mk_prod_**********************def456", created: "2024-02-20", lastUsed: "2024-03-14", status: "active" },
  { id: 3, name: "Fraud Detection ML", key: "ml_api_**********************ghi789", created: "2024-03-01", lastUsed: "2024-03-15", status: "active" },
];

export default function Settings() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const [showApiKey, setShowApiKey] = useState<{ [key: number]: boolean }>({});
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    fraudNotifications: true,
    weeklyReports: false,
    systemUpdates: true,
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  const toggleApiKeyVisibility = (keyId: number) => {
    setShowApiKey(prev => ({
      ...prev,
      [keyId]: !prev[keyId]
    }));
  };

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="Settings & Configuration"
          subtitle="Manage system settings, user permissions, and integrations"
        />
        
        <main className="p-6">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="api">API & Keys</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
            </TabsList>

            {/* Profile Settings */}
            <TabsContent value="profile">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <User className="mr-2 h-5 w-5" />
                      Profile Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input id="name" value={user?.name || ""} className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input id="email" type="email" value={user?.email || ""} className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="role">Role</Label>
                      <Input 
                        id="role" 
                        value={user?.role === 'petronas' ? 'PETRONAS Operations' : 'Collector'} 
                        disabled 
                        className="mt-1" 
                      />
                    </div>
                    <div>
                      <Label htmlFor="username">Username</Label>
                      <Input id="username" value={user?.username || ""} className="mt-1" />
                    </div>
                    <Button className="bg-petronas-light hover:bg-petronas-blue">
                      Update Profile
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Change Password</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" className="mt-1" />
                    </div>
                    <Button variant="outline">
                      Change Password
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* User Management */}
            <TabsContent value="users">
              {user?.role === 'petronas' ? (
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center">
                        <Shield className="mr-2 h-5 w-5" />
                        User Management
                      </CardTitle>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button className="bg-petronas-light hover:bg-petronas-blue">
                            <Plus className="mr-2 h-4 w-4" />
                            Add User
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                          <DialogHeader>
                            <DialogTitle>Add New User</DialogTitle>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                              <Label htmlFor="user-name">Full Name</Label>
                              <Input id="user-name" placeholder="Enter full name" />
                            </div>
                            <div className="grid gap-2">
                              <Label htmlFor="user-email">Email</Label>
                              <Input id="user-email" type="email" placeholder="Enter email" />
                            </div>
                            <div className="grid gap-2">
                              <Label htmlFor="user-role">Role</Label>
                              <Select>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="petronas">PETRONAS Operations</SelectItem>
                                  <SelectItem value="collector">Collector</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <Button className="bg-petronas-light hover:bg-petronas-blue">
                              Add User
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              User
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Role
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Last Login
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {mockUsers.map((userData) => (
                            <tr key={userData.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div>
                                  <div className="text-sm font-medium text-gray-900">{userData.name}</div>
                                  <div className="text-sm text-gray-500">{userData.email}</div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge className={userData.role === 'petronas' ? 
                                  'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}>
                                  {userData.role === 'petronas' ? 'PETRONAS' : 'Collector'}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge className={userData.status === 'active' ? 
                                  'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                                  {userData.status.charAt(0).toUpperCase() + userData.status.slice(1)}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {userData.lastLogin}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <Button size="sm" variant="ghost" className="text-petronas-light hover:text-petronas-blue mr-2">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Shield className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Access Restricted</h3>
                    <p className="text-gray-600">You don't have permission to manage users.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Security Settings */}
            <TabsContent value="security">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Two-Factor Authentication</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Enable 2FA</p>
                        <p className="text-sm text-gray-600">Add an extra layer of security to your account</p>
                      </div>
                      <Switch />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">SMS Authentication</p>
                        <p className="text-sm text-gray-600">Receive codes via SMS</p>
                      </div>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Email Authentication</p>
                        <p className="text-sm text-gray-600">Receive codes via email</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Session Management</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Auto Logout</p>
                        <p className="text-sm text-gray-600">Automatically log out after inactivity</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div>
                      <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                      <Input id="session-timeout" type="number" value="30" className="mt-1" />
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <p className="font-medium">Active Sessions</p>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm font-medium">Current Session</p>
                            <p className="text-xs text-gray-600">Chrome on Windows • 103.150.45.12</p>
                          </div>
                          <Badge className="bg-green-100 text-green-800">Active</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* API & Keys */}
            <TabsContent value="api">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      <Key className="mr-2 h-5 w-5" />
                      API Keys & Integrations
                    </CardTitle>
                    {user?.role === 'petronas' && (
                      <Button className="bg-petronas-light hover:bg-petronas-blue">
                        <Plus className="mr-2 h-4 w-4" />
                        Generate API Key
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockAPIKeys.map((apiKey) => (
                      <div key={apiKey.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3">
                              <h4 className="font-medium text-gray-900">{apiKey.name}</h4>
                              <Badge className="bg-green-100 text-green-800">{apiKey.status}</Badge>
                            </div>
                            <div className="mt-2 flex items-center space-x-2">
                              <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                                {showApiKey[apiKey.id] ? apiKey.key.replace(/\*/g, '').slice(0, -6) + 'abc123' : apiKey.key}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => toggleApiKeyVisibility(apiKey.id)}
                              >
                                {showApiKey[apiKey.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </Button>
                            </div>
                            <div className="mt-2 text-sm text-gray-600">
                              Created: {apiKey.created} • Last used: {apiKey.lastUsed}
                            </div>
                          </div>
                          {user?.role === 'petronas' && (
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                Regenerate
                              </Button>
                              <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                                Revoke
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications */}
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bell className="mr-2 h-5 w-5" />
                    Notification Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Email Alerts</p>
                      <p className="text-sm text-gray-600">Receive important updates via email</p>
                    </div>
                    <Switch 
                      checked={notifications.emailAlerts}
                      onCheckedChange={(checked) => setNotifications(prev => ({...prev, emailAlerts: checked}))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Fraud Notifications</p>
                      <p className="text-sm text-gray-600">Get notified when fraud is detected</p>
                    </div>
                    <Switch 
                      checked={notifications.fraudNotifications}
                      onCheckedChange={(checked) => setNotifications(prev => ({...prev, fraudNotifications: checked}))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Weekly Reports</p>
                      <p className="text-sm text-gray-600">Receive weekly performance summaries</p>
                    </div>
                    <Switch 
                      checked={notifications.weeklyReports}
                      onCheckedChange={(checked) => setNotifications(prev => ({...prev, weeklyReports: checked}))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">System Updates</p>
                      <p className="text-sm text-gray-600">Get notified about system maintenance and updates</p>
                    </div>
                    <Switch 
                      checked={notifications.systemUpdates}
                      onCheckedChange={(checked) => setNotifications(prev => ({...prev, systemUpdates: checked}))}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* System Settings */}
            <TabsContent value="system">
              {user?.role === 'petronas' ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Database className="mr-2 h-5 w-5" />
                        Data Management
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">Export All Data</h4>
                          <p className="text-sm text-gray-600">Download complete system backup</p>
                        </div>
                        <Button size="sm" variant="outline">
                          <Download className="mr-2 h-4 w-4" />
                          Export
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">Import Data</h4>
                          <p className="text-sm text-gray-600">Bulk import collection data</p>
                        </div>
                        <Button size="sm" variant="outline">
                          <Upload className="mr-2 h-4 w-4" />
                          Import
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">Data Retention</h4>
                          <p className="text-sm text-gray-600">Configure data retention policies</p>
                        </div>
                        <Button size="sm" variant="outline">
                          Configure
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Globe className="mr-2 h-5 w-5" />
                        System Configuration
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="timezone">Timezone</Label>
                        <Select>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Asia/Kuala_Lumpur" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="asia/kuala_lumpur">Asia/Kuala Lumpur</SelectItem>
                            <SelectItem value="asia/singapore">Asia/Singapore</SelectItem>
                            <SelectItem value="asia/bangkok">Asia/Bangkok</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="language">Default Language</Label>
                        <Select>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="English" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en">English</SelectItem>
                            <SelectItem value="ms">Bahasa Malaysia</SelectItem>
                            <SelectItem value="zh">中文</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="currency">Currency</Label>
                        <Select>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="MYR (Malaysian Ringgit)" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="myr">MYR (Malaysian Ringgit)</SelectItem>
                            <SelectItem value="sgd">SGD (Singapore Dollar)</SelectItem>
                            <SelectItem value="usd">USD (US Dollar)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Database className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Access Restricted</h3>
                    <p className="text-gray-600">You don't have permission to modify system settings.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}
