import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Plus, Search, Scale, Wifi, Battery, Calendar, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Device } from "@shared/schema";

const mockDevices = [
  {
    id: 1,
    serialNumber: "BLE-001-KV",
    stationName: "Klang Valley Hub",
    type: "ble_scale",
    status: "active",
    batteryLevel: 85,
    lastSync: "2024-03-15 14:30",
    lastCalibration: "2024-02-15",
    firmware: "v2.1.3",
    connectionStatus: "connected",
  },
  {
    id: 2,
    serialNumber: "BLE-002-SB",
    stationName: "Subang Collection Point",
    type: "ble_scale",
    status: "active",
    batteryLevel: 92,
    lastSync: "2024-03-15 14:25",
    lastCalibration: "2024-02-20",
    firmware: "v2.1.3",
    connectionStatus: "connected",
  },
  {
    id: 3,
    serialNumber: "BLE-003-SA",
    stationName: "Shah Alam Terminal",
    type: "ble_scale",
    status: "maintenance",
    batteryLevel: 23,
    lastSync: "2024-03-14 16:45",
    lastCalibration: "2024-01-15",
    firmware: "v2.0.8",
    connectionStatus: "disconnected",
  },
  {
    id: 4,
    serialNumber: "BLE-004-PJ",
    stationName: "Petaling Jaya Hub",
    type: "ble_scale",
    status: "active",
    batteryLevel: 67,
    lastSync: "2024-03-15 14:18",
    lastCalibration: "2024-02-28",
    firmware: "v2.1.3",
    connectionStatus: "connected",
  },
  {
    id: 5,
    serialNumber: "BLE-005-KL",
    stationName: "Kuala Lumpur Central",
    type: "ble_scale",
    status: "inactive",
    batteryLevel: 0,
    lastSync: "2024-03-10 09:22",
    lastCalibration: "2024-01-20",
    firmware: "v2.0.5",
    connectionStatus: "disconnected",
  },
];

export default function Devices() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");

  const { data: devices, isLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  const filteredDevices = mockDevices.filter(device => {
    const matchesSearch = device.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         device.stationName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === "all" || device.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getConnectionColor = (status: string) => {
    return status === 'connected' ? 'text-green-600' : 'text-red-600';
  };

  const getBatteryColor = (level: number) => {
    if (level > 50) return 'bg-green-500';
    if (level > 20) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="Device Management"
          subtitle="Monitor and manage BLE scales, calibration status, and device connectivity"
        />
        
        <main className="p-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Devices</p>
                    <p className="text-3xl font-bold text-gray-900">127</p>
                    <p className="text-sm text-blue-600 mt-1">BLE Scales</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Scale className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Connected</p>
                    <p className="text-3xl font-bold text-gray-900">118</p>
                    <p className="text-sm text-green-600 mt-1">93% uptime</p>
                  </div>
                  <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                    <Wifi className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Low Battery</p>
                    <p className="text-3xl font-bold text-gray-900">7</p>
                    <p className="text-sm text-yellow-600 mt-1">Need replacement</p>
                  </div>
                  <div className="w-12 h-12 bg-yellow-50 rounded-lg flex items-center justify-center">
                    <Battery className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Calibration Due</p>
                    <p className="text-3xl font-bold text-gray-900">12</p>
                    <p className="text-sm text-orange-600 mt-1">Within 30 days</p>
                  </div>
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Bar */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-4">
              {user?.role === 'petronas' && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-petronas-light hover:bg-petronas-blue">
                      <Plus className="mr-2 h-4 w-4" />
                      Register Device
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Register New Device</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="device-serial">Serial Number</Label>
                        <Input id="device-serial" placeholder="Enter serial number" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="device-type">Device Type</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select device type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ble_scale">BLE Scale</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="device-station">Station</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select station" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">Klang Valley Hub</SelectItem>
                            <SelectItem value="2">Subang Collection Point</SelectItem>
                            <SelectItem value="3">Shah Alam Terminal</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button className="bg-petronas-light hover:bg-petronas-blue">
                        Register Device
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
              <Button variant="outline">
                <Calendar className="mr-2 h-4 w-4" />
                Schedule Calibration
              </Button>
            </div>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search devices..."
                  className="pl-10 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Devices Table */}
          <Card>
            <CardHeader>
              <CardTitle>Device Registry</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Device
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Station
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Battery
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Connection
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Last Sync
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Calibration
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredDevices.map((device) => (
                      <tr key={device.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
                              <Scale className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{device.serialNumber}</div>
                              <div className="text-sm text-gray-500">{device.firmware}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {device.stationName}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className={getStatusColor(device.status)}>
                            {device.status.charAt(0).toUpperCase() + device.status.slice(1)}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-2">
                            <div className="w-12 bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${getBatteryColor(device.batteryLevel)}`}
                                style={{ width: `${device.batteryLevel}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-600">{device.batteryLevel}%</span>
                            {device.batteryLevel < 25 && (
                              <AlertTriangle className="h-4 w-4 text-red-500" />
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <Wifi className={`h-4 w-4 mr-1 ${getConnectionColor(device.connectionStatus)}`} />
                            <span className={`text-sm ${getConnectionColor(device.connectionStatus)}`}>
                              {device.connectionStatus.charAt(0).toUpperCase() + device.connectionStatus.slice(1)}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {device.lastSync}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {device.lastCalibration}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <Button size="sm" variant="ghost" className="text-petronas-light hover:text-petronas-blue mr-2">
                            View
                          </Button>
                          {user?.role === 'petronas' && (
                            <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gray-600">
                              Configure
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
