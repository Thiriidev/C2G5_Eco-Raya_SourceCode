import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import AIInsights from "@/components/dashboard/ai-insights";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Brain, TrendingUp, Users, MapPin } from "lucide-react";

const performanceData = [
  { name: "AUCO Sdn Bhd", performance: 95, collections: 145 },
  { name: "Arus Oil Trading", performance: 88, collections: 132 },
  { name: "GreenTech Solutions", performance: 91, collections: 89 },
  { name: "EcoWaste Management", performance: 76, collections: 67 },
  { name: "Sustainable Oil Co", performance: 82, collections: 54 },
];

const regionData = [
  { name: "Klang Valley", value: 35, color: "hsl(207, 90%, 54%)" },
  { name: "Selangor", value: 28, color: "hsl(207, 73%, 63%)" },
  { name: "Johor", value: 20, color: "hsl(207, 60%, 70%)" },
  { name: "Penang", value: 17, color: "hsl(207, 50%, 75%)" },
];

export default function Analytics() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="AI Analytics & Insights"
          subtitle="Advanced analytics and machine learning insights for oil collection operations"
        />
        
        <main className="p-6">
          {/* Analytics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">AI Predictions</p>
                    <p className="text-3xl font-bold text-gray-900">94%</p>
                    <p className="text-sm text-green-600 mt-1">Accuracy Rate</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                    <Brain className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Trend Analysis</p>
                    <p className="text-3xl font-bold text-gray-900">↗ 23%</p>
                    <p className="text-sm text-green-600 mt-1">Growth Detected</p>
                  </div>
                  <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Behavioral Patterns</p>
                    <p className="text-3xl font-bold text-gray-900">847</p>
                    <p className="text-sm text-blue-600 mt-1">Unique Patterns</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Location Insights</p>
                    <p className="text-3xl font-bold text-gray-900">127</p>
                    <p className="text-sm text-orange-600 mt-1">Active Zones</p>
                  </div>
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* AI Insights */}
          <div className="mb-8">
            <AIInsights />
          </div>

          {/* Performance Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Partner Performance Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis 
                        dataKey="name" 
                        angle={-45}
                        textAnchor="end"
                        height={100}
                        interval={0}
                        tick={{ fontSize: 12 }}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Bar dataKey="performance" fill="hsl(207, 90%, 54%)" radius={4} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Regional Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={regionData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {regionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Predictive Analytics */}
          <Card>
            <CardHeader>
              <CardTitle>Predictive Analytics Dashboard</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-lg">
                  <h3 className="font-semibold text-blue-900 mb-2">Next Week Forecast</h3>
                  <p className="text-2xl font-bold text-blue-700">2,845 kg</p>
                  <p className="text-sm text-blue-600">Expected oil collection</p>
                </div>
                <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-lg">
                  <h3 className="font-semibold text-green-900 mb-2">Optimal Collection Time</h3>
                  <p className="text-2xl font-bold text-green-700">9-11 AM</p>
                  <p className="text-sm text-green-600">Peak efficiency window</p>
                </div>
                <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-lg">
                  <h3 className="font-semibold text-purple-900 mb-2">Risk Assessment</h3>
                  <p className="text-2xl font-bold text-purple-700">Low</p>
                  <p className="text-sm text-purple-600">Fraud probability</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
