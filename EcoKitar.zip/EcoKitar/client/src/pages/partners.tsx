import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, MapPin, Users, TrendingUp, Building } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Partner } from "@shared/schema";

const mockPartnerStats = [
  { id: 1, name: "AUCO Sdn Bhd", region: "Klang Valley", collections: 145, volume: "8,945 kg", efficiency: 95, status: "active" },
  { id: 2, name: "Arus Oil Trading", region: "Selangor", collections: 132, volume: "7,234 kg", efficiency: 88, status: "active" },
  { id: 3, name: "GreenTech Solutions", region: "Johor", collections: 89, volume: "6,187 kg", efficiency: 91, status: "active" },
  { id: 4, name: "EcoWaste Management", region: "Penang", collections: 67, volume: "5,432 kg", efficiency: 76, status: "inactive" },
  { id: 5, name: "Sustainable Oil Co", region: "Selangor", collections: 54, volume: "4,876 kg", efficiency: 82, status: "active" },
];

export default function Partners() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");

  const { data: partners, isLoading } = useQuery<Partner[]>({
    queryKey: ["/api/partners"],
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  const filteredPartners = mockPartnerStats.filter(partner => {
    const matchesSearch = partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         partner.region.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === "all" || partner.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="Partners & Stations"
          subtitle="Manage collection partners, stations, and performance monitoring"
        />
        
        <main className="p-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Partners</p>
                    <p className="text-3xl font-bold text-gray-900">24</p>
                    <p className="text-sm text-green-600 mt-1">+3 this month</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Building className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Active Stations</p>
                    <p className="text-3xl font-bold text-gray-900">127</p>
                    <p className="text-sm text-green-600 mt-1">95% operational</p>
                  </div>
                  <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Staff Members</p>
                    <p className="text-3xl font-bold text-gray-900">342</p>
                    <p className="text-sm text-blue-600 mt-1">Across all partners</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                    <Users className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Avg Performance</p>
                    <p className="text-3xl font-bold text-gray-900">87%</p>
                    <p className="text-sm text-green-600 mt-1">+2% vs last month</p>
                  </div>
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Bar */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-4">
              {user?.role === 'petronas' && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-petronas-light hover:bg-petronas-blue">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Partner
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Add New Partner</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="partner-name">Partner Name</Label>
                        <Input id="partner-name" placeholder="Enter partner name" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="partner-contact">Contact Information</Label>
                        <Input id="partner-contact" placeholder="Phone number" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="partner-email">Email</Label>
                        <Input id="partner-email" type="email" placeholder="Email address" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="partner-regions">Regions</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select regions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="klang-valley">Klang Valley</SelectItem>
                            <SelectItem value="selangor">Selangor</SelectItem>
                            <SelectItem value="johor">Johor</SelectItem>
                            <SelectItem value="penang">Penang</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button className="bg-petronas-light hover:bg-petronas-blue">
                        Add Partner
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search partners..."
                  className="pl-10 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Partners Table */}
          <Card>
            <CardHeader>
              <CardTitle>Partner Directory</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Partner
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Region
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Collections
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Volume
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Efficiency
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredPartners.map((partner) => (
                      <tr key={partner.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-petronas-bg rounded-full flex items-center justify-center">
                              <Building className="h-5 w-5 text-petronas-light" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{partner.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {partner.region}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {partner.collections}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {partner.volume}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          <div className="flex items-center">
                            <div className={`w-2 h-2 rounded-full mr-2 ${
                              partner.efficiency >= 90 ? 'bg-green-500' :
                              partner.efficiency >= 80 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}></div>
                            {partner.efficiency}%
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className={partner.status === 'active' ? 
                            'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                            {partner.status.charAt(0).toUpperCase() + partner.status.slice(1)}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <Button size="sm" variant="ghost" className="text-petronas-light hover:text-petronas-blue mr-2">
                            View
                          </Button>
                          {user?.role === 'petronas' && (
                            <Button size="sm" variant="ghost" className="text-gray-400 hover:text-gray-600">
                              Edit
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
