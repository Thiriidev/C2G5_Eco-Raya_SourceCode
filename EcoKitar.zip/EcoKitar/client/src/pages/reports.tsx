import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, Calendar, Filter, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

const predefinedReports = [
  {
    id: 1,
    name: "Monthly ESG Report",
    description: "Comprehensive environmental, social, and governance metrics",
    lastGenerated: "2024-03-01",
    format: "PDF",
    size: "2.4 MB",
  },
  {
    id: 2,
    name: "Quarterly Board Report",
    description: "Executive summary for board presentations",
    lastGenerated: "2024-03-01",
    format: "PDF",
    size: "1.8 MB",
  },
  {
    id: 3,
    name: "Partner Performance Report",
    description: "Detailed analysis of partner collection metrics",
    lastGenerated: "2024-03-10",
    format: "Excel",
    size: "5.2 MB",
  },
  {
    id: 4,
    name: "Weekly Operations Summary",
    description: "Weekly operational metrics and KPIs",
    lastGenerated: "2024-03-15",
    format: "PDF",
    size: "1.1 MB",
  },
];

interface ReportStats {
  totalItems: number;
  totalWeight: number;
  totalReports: number;
  categoryBreakdown: Record<string, { count: number; weight: number }>;
  statusBreakdown: Record<string, number>;
  recentItems: Array<{
    id: number;
    category: string;
    weight_estimate_kg: number;
    address: string;
    status: string;
    created_at: string;
  }>;
  recentReports: Array<{
    id: number;
    title: string;
    severity: string;
    status: string;
    address: string;
    created_at: string;
  }>;
}

export default function Reports() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [generatingReport, setGeneratingReport] = useState<number | null>(null);

  const { data: stats } = useQuery<ReportStats>({
    queryKey: ["/api/jabatan/report-stats"],
    queryFn: async () => {
      const res = await fetch("/api/jabatan/report-stats", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch report stats");
      return res.json();
    },
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  const generatePDF = async (reportId: number, reportName: string) => {
    setGeneratingReport(reportId);
    
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const currentDate = new Date().toLocaleDateString('en-MY', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });
      
      doc.setFillColor(16, 185, 129);
      doc.rect(0, 0, pageWidth, 40, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(24);
      doc.setFont("helvetica", "bold");
      doc.text("EcoKitar", 14, 20);
      
      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      doc.text(reportName, 14, 32);
      
      doc.setFontSize(10);
      doc.text(`Generated: ${currentDate}`, pageWidth - 14, 20, { align: 'right' });
      
      doc.setTextColor(0, 0, 0);
      let yPos = 55;
      
      if (reportId === 1 || reportId === 4) {
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.text("Executive Summary", 14, yPos);
        yPos += 10;
        
        doc.setFontSize(11);
        doc.setFont("helvetica", "normal");
        
        const summaryData = [
          ["Total Items Collected", `${stats?.totalItems || 0} items`],
          ["Total Weight Recycled", `${stats?.totalWeight?.toFixed(1) || 0} kg`],
          ["Active Reports", `${stats?.totalReports || 0} reports`],
          ["Categories Tracked", `${Object.keys(stats?.categoryBreakdown || {}).length || 0} categories`],
        ];
        
        autoTable(doc, {
          startY: yPos,
          head: [['Metric', 'Value']],
          body: summaryData,
          theme: 'striped',
          headStyles: { fillColor: [16, 185, 129] },
          margin: { left: 14, right: 14 },
        });
        
        yPos = (doc as any).lastAutoTable.finalY + 15;
      }
      
      if (stats?.categoryBreakdown && Object.keys(stats.categoryBreakdown).length > 0) {
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.text("Category Breakdown", 14, yPos);
        yPos += 10;
        
        const categoryData = Object.entries(stats.categoryBreakdown).map(([cat, data]) => [
          cat.charAt(0).toUpperCase() + cat.slice(1).replace('_', ' '),
          data.count.toString(),
          `${data.weight.toFixed(1)} kg`,
        ]);
        
        autoTable(doc, {
          startY: yPos,
          head: [['Category', 'Items', 'Weight']],
          body: categoryData,
          theme: 'striped',
          headStyles: { fillColor: [16, 185, 129] },
          margin: { left: 14, right: 14 },
        });
        
        yPos = (doc as any).lastAutoTable.finalY + 15;
      }
      
      if (stats?.recentItems && stats.recentItems.length > 0) {
        if (yPos > 200) {
          doc.addPage();
          yPos = 20;
        }
        
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.text("Recent Collection Items", 14, yPos);
        yPos += 10;
        
        const itemsData = stats.recentItems.slice(0, 10).map(item => [
          item.id.toString(),
          item.category,
          `${item.weight_estimate_kg} kg`,
          item.address?.substring(0, 25) || 'N/A',
          item.status,
        ]);
        
        autoTable(doc, {
          startY: yPos,
          head: [['ID', 'Category', 'Weight', 'Location', 'Status']],
          body: itemsData,
          theme: 'striped',
          headStyles: { fillColor: [16, 185, 129] },
          margin: { left: 14, right: 14 },
          columnStyles: {
            0: { cellWidth: 15 },
            1: { cellWidth: 30 },
            2: { cellWidth: 25 },
            3: { cellWidth: 60 },
            4: { cellWidth: 30 },
          },
        });
        
        yPos = (doc as any).lastAutoTable.finalY + 15;
      }
      
      if (stats?.recentReports && stats.recentReports.length > 0 && (reportId === 1 || reportId === 4)) {
        if (yPos > 200) {
          doc.addPage();
          yPos = 20;
        }
        
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.text("Active Reports", 14, yPos);
        yPos += 10;
        
        const reportsData = stats.recentReports.slice(0, 10).map(report => [
          report.id.toString(),
          report.title?.substring(0, 30) || 'N/A',
          report.severity,
          report.status,
        ]);
        
        autoTable(doc, {
          startY: yPos,
          head: [['ID', 'Title', 'Severity', 'Status']],
          body: reportsData,
          theme: 'striped',
          headStyles: { fillColor: [16, 185, 129] },
          margin: { left: 14, right: 14 },
        });
      }
      
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(128);
        doc.text(
          `EcoKitar Recycling Platform - Page ${i} of ${pageCount}`,
          pageWidth / 2,
          doc.internal.pageSize.getHeight() - 10,
          { align: 'center' }
        );
      }
      
      const fileName = `${reportName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
      doc.save(fileName);
      
      toast({
        title: "Report Generated",
        description: `${reportName} has been downloaded successfully.`,
      });
    } catch (error) {
      console.error("PDF generation error:", error);
      toast({
        title: "Error",
        description: "Failed to generate report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setGeneratingReport(null);
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="Reports & Analytics"
          subtitle="Generate and download comprehensive reports and analytics"
        />
        
        <main className="p-6">
          {/* Report Actions */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-4">
              <Button className="bg-petronas-light hover:bg-petronas-blue">
                <FileText className="mr-2 h-4 w-4" />
                Custom Report Builder
              </Button>
              <Button variant="outline">
                <Calendar className="mr-2 h-4 w-4" />
                Schedule Report
              </Button>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Filter Reports
              </Button>
            </div>
          </div>

          {/* Predefined Reports */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Predefined Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {predefinedReports.map((report) => (
                  <div key={report.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 mb-1">{report.name}</h3>
                        <p className="text-sm text-gray-600 mb-3">{report.description}</p>
                        <div className="flex items-center text-xs text-gray-500 space-x-4">
                          <span>Last: {report.lastGenerated}</span>
                          <span>{report.format}</span>
                          <span>{report.size}</span>
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2 ml-4">
                        <Button 
                          size="sm" 
                          className="bg-petronas-light hover:bg-petronas-blue"
                          onClick={() => generatePDF(report.id, report.name)}
                          disabled={generatingReport === report.id}
                          data-testid={`button-download-report-${report.id}`}
                        >
                          {generatingReport === report.id ? (
                            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                          ) : (
                            <Download className="mr-1 h-3 w-3" />
                          )}
                          {generatingReport === report.id ? "Generating..." : "Download"}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => generatePDF(report.id, report.name)}
                          disabled={generatingReport === report.id}
                          data-testid={`button-generate-report-${report.id}`}
                        >
                          {generatingReport === report.id ? (
                            <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                          ) : (
                            <FileText className="mr-1 h-3 w-3" />
                          )}
                          Generate
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Custom Report Builder */}
          <Card>
            <CardHeader>
              <CardTitle>Custom Report Builder</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <div className="mb-4">
                  <FileText className="mx-auto h-12 w-12 text-gray-400" />
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">Build Custom Reports</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Create customized reports with specific data fields and date ranges.
                </p>
                <div className="mt-6">
                  <Button className="bg-petronas-light hover:bg-petronas-blue">
                    <FileText className="mr-2 h-4 w-4" />
                    Start Building
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
