import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, AlertTriangle, CheckCircle, XCircle } from "lucide-react";

const mockFraudCases = [
  {
    id: "FR-001",
    collectionId: "COL-24563",
    reason: "Duplicate photo detected",
    severity: "high",
    status: "pending",
    station: "Klang Valley Hub",
    amount: "RM 45.65",
    flaggedAt: "2024-03-15 10:15",
  },
  {
    id: "FR-002",
    collectionId: "COL-24489",
    reason: "Abnormal volume spike (+300%)",
    severity: "medium",
    status: "resolved",
    station: "Subang Collection Point",
    amount: "RM 125.50",
    flaggedAt: "2024-03-14 14:22",
  },
  {
    id: "FR-003",
    collectionId: "COL-24445",
    reason: "Rapid repeat submissions",
    severity: "low",
    status: "invalid",
    station: "Shah Alam Terminal",
    amount: "RM 18.20",
    flaggedAt: "2024-03-14 09:45",
  },
];

const severityColors = {
  high: "bg-red-100 text-red-800",
  medium: "bg-yellow-100 text-yellow-800",
  low: "bg-blue-100 text-blue-800",
};

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800",
  resolved: "bg-green-100 text-green-800",
  invalid: "bg-gray-100 text-gray-800",
};

export default function Fraud() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <Header
          title="Fraud Detection & Review"
          subtitle="AI-powered fraud detection system and anomaly review queue"
        />
        
        <main className="p-6">
          {/* Fraud Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Active Cases</p>
                    <p className="text-3xl font-bold text-gray-900">12</p>
                    <p className="text-sm text-red-600 mt-1">Require review</p>
                  </div>
                  <div className="w-12 h-12 bg-red-50 rounded-lg flex items-center justify-center">
                    <AlertTriangle className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Resolved Cases</p>
                    <p className="text-3xl font-bold text-gray-900">87</p>
                    <p className="text-sm text-green-600 mt-1">This month</p>
                  </div>
                  <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">False Positives</p>
                    <p className="text-3xl font-bold text-gray-900">23</p>
                    <p className="text-sm text-gray-600 mt-1">Invalid flags</p>
                  </div>
                  <div className="w-12 h-12 bg-gray-50 rounded-lg flex items-center justify-center">
                    <XCircle className="h-6 w-6 text-gray-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Detection Rate</p>
                    <p className="text-3xl font-bold text-gray-900">96.8%</p>
                    <p className="text-sm text-blue-600 mt-1">AI accuracy</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Shield className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Fraud Cases Table */}
          <Card>
            <CardHeader>
              <CardTitle>Fraud Detection Queue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Case ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Collection ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Reason
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Severity
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Station
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Amount
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {mockFraudCases.map((fraudCase) => (
                      <tr key={fraudCase.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {fraudCase.id}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600">
                          {fraudCase.collectionId}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {fraudCase.reason}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className={severityColors[fraudCase.severity as keyof typeof severityColors]}>
                            {fraudCase.severity.toUpperCase()}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className={statusColors[fraudCase.status as keyof typeof statusColors]}>
                            {fraudCase.status.charAt(0).toUpperCase() + fraudCase.status.slice(1)}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {fraudCase.station}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {fraudCase.amount}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {fraudCase.flaggedAt}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {fraudCase.status === 'pending' ? (
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" className="text-green-600 hover:text-green-700">
                                Approve
                              </Button>
                              <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                                Reject
                              </Button>
                            </div>
                          ) : (
                            <Button size="sm" variant="ghost" className="text-petronas-light hover:text-petronas-blue">
                              View
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
