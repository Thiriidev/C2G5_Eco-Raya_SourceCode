import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { 
  Plus, 
  Calendar, 
  Coins, 
  Banknote, 
  Users, 
  Weight, 
  Receipt, 
  Upload,
  Wifi,
  WifiOff,
  Scale,
  MapPin,
  BarChart3,
  FileText,
  Download,
  Filter,
  Home,
  Leaf,
  Droplets,
  Calculator,
  Camera,
  Shield,
  Smartphone,
  CreditCard,
  Check,
  Eye,
  PenTool,
  CalendarDays,
  TrendingUp
} from "lucide-react";

interface DailyStats {
  date: string;
  cashPaidOut: number;
  pointsPaidOut: number;
  householdsServed: number;
  totalKg: number;
  transactions: number;
}

export default function CollectorDashboard() {
  const { isAuthenticated, user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [chartSelectedDate, setChartSelectedDate] = useState<Date>(new Date());
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [scaleWeight, setScaleWeight] = useState<number | null>(null);
  const [isAddEntryOpen, setIsAddEntryOpen] = useState(false);
  const [isOfflineEntryOpen, setIsOfflineEntryOpen] = useState(false);
  const [isFraudReviewOpen, setIsFraudReviewOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reports' | 'esg'>('dashboard');

  // Form states
  const [phone, setPhone] = useState("");
  const [weight, setWeight] = useState("");
  const [payoutType, setPayoutType] = useState<'cash' | 'points'>('cash');
  const [amount, setAmount] = useState("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  // User verification states
  const [verificationStep, setVerificationStep] = useState<'phone' | 'verify' | 'proof' | 'complete'>('phone');
  const [verificationType, setVerificationType] = useState<'face' | 'ic' | 'otp' | null>(null);
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'success' | 'failed'>('pending');
  const [otpCode, setOtpCode] = useState("");
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [capturedSignature, setCapturedSignature] = useState<string | null>(null);

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'collector') {
      setLocation("/login");
    }

    // Monitor online status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Simulate BLE scale connection
    const scaleInterval = setInterval(() => {
      if (isOnline) {
        setScaleWeight(Math.random() * 10 + 1); // Random weight between 1-11 kg
      }
    }, 3000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(scaleInterval);
    };
  }, [isAuthenticated, user, setLocation]);

  // Generate realistic daily stats covering last 6 months
  const generateDailyStats = (): DailyStats[] => {
    const stats: DailyStats[] = [];
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - 6);
    
    for (let i = 0; i < 180; i++) {
      const currentDate = new Date(startDate);
      currentDate.setDate(startDate.getDate() + i);
      
      const baseTransactions = Math.floor(Math.random() * 25) + 15;
      const avgKgPerTransaction = 2.5 + Math.random() * 2;
      const totalKg = baseTransactions * avgKgPerTransaction;
      const cashRatio = 0.6 + Math.random() * 0.3;
      const cashPaidOut = totalKg * 4.5 * cashRatio;
      const pointsPaidOut = Math.floor(totalKg * (1 - cashRatio) * 8);
      
      stats.push({
        date: currentDate.toISOString().split('T')[0],
        cashPaidOut: Math.round(cashPaidOut * 100) / 100,
        pointsPaidOut,
        householdsServed: baseTransactions,
        totalKg: Math.round(totalKg * 10) / 10,
        transactions: baseTransactions
      });
    }
    
    return stats.reverse();
  };

  const dailyStats = generateDailyStats();
  const todayStats = dailyStats.find(stat => stat.date === selectedDate) || dailyStats[0];

  // ESG metrics for single collection point (Klang Valley Hub)
  const esgMetrics = {
    monthly: {
      co2Saved: 2.4, // tons for this collection point
      oilCollected: 890, // kg for this month
      householdsServed: 156, // households this month
      wasteReduced: 0.89 // tons diverted from landfill
    },
    ytd: {
      co2Saved: 18.7, // tons YTD
      oilCollected: 6234, // kg YTD
      householdsServed: 1247, // unique households YTD
      wasteReduced: 6.2 // tons YTD
    },
    trends: [
      { month: "Jan", co2: 1.8, oil: 612, households: 98 },
      { month: "Feb", co2: 2.1, oil: 735, households: 121 },
      { month: "Mar", co2: 2.4, oil: 890, households: 156 },
      { month: "Apr", co2: 2.2, oil: 823, households: 143 },
      { month: "May", co2: 2.6, oil: 945, households: 167 },
      { month: "Jun", co2: 2.8, oil: 1024, households: 178 }
    ]
  };

  const addEntryMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/collections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to add entry");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/collections"] });
      resetEntryForm();
    },
  });

  // Helper functions for verification flow
  const resetEntryForm = () => {
    setIsAddEntryOpen(false);
    setPhone("");
    setWeight("");
    setAmount("");
    setVerificationStep('phone');
    setVerificationType(null);
    setVerificationStatus('pending');
    setOtpCode("");
    setCapturedPhoto(null);
    setCapturedSignature(null);
  };

  const handleVerification = (type: 'face' | 'ic' | 'otp') => {
    setVerificationType(type);
    setVerificationStatus('pending');
    
    // Simulate verification process
    setTimeout(() => {
      setVerificationStatus('success');
      setTimeout(() => {
        setVerificationStep('proof');
      }, 1000);
    }, 2000);
  };

  const handleOTPVerification = () => {
    if (otpCode === "123456") {
      setVerificationStatus('success');
      setTimeout(() => {
        setVerificationStep('proof');
      }, 1000);
    } else {
      setVerificationStatus('failed');
    }
  };

  const simulatePhotoCapture = () => {
    setCapturedPhoto("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/mock-image");
  };

  const simulateSignatureCapture = () => {
    setCapturedSignature("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDIwMCAxMDAiPjxwYXRoIGQ9Ik0xMCw1MCBRMTM1LDEwIDIwMCw1MCIgc3Ryb2tlPSJibGFjayIgZmlsbD0ibm9uZSIvPjwvc3ZnPg==");
  };

  const handleCompleteEntry = () => {
    if (!phone || !weight || !amount) return;

    addEntryMutation.mutate({
      phone,
      kg: parseFloat(weight),
      payoutType,
      payoutAmount: parseFloat(amount),
      status: 'completed',
      verificationType,
    });
  };

  const generateReceipt = () => {
    const receiptData = {
      transactionId: `TXN${Date.now()}`,
      phone,
      weight,
      payoutType,
      amount,
      verificationType,
      timestamp: new Date().toISOString(),
      station: "Klang Valley Hub"
    };
    
    // Create receipt content
    const receiptContent = `
=== SETELGREASE RECEIPT ===
Transaction ID: ${receiptData.transactionId}
Station: ${receiptData.station}
Date: ${new Date().toLocaleDateString()}
Time: ${new Date().toLocaleTimeString()}

Customer Phone: ${receiptData.phone}
Oil Weight: ${receiptData.weight} kg
Payout: ${payoutType === 'cash' ? `RM ${amount}` : `${amount} points`}
Verification: ${verificationType?.toUpperCase()}

Thank you for your contribution to 
environmental sustainability!

Powered by PETRONAS SetelGrease
============================
    `.trim();

    // Create and download receipt
    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SetelGrease_Receipt_${receiptData.transactionId}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const generateReport = () => {
    const reportData = {
      transactionId: `TXN${Date.now()}`,
      phone,
      weight: parseFloat(weight),
      payoutType,
      amount: parseFloat(amount),
      verificationType,
      timestamp: new Date().toISOString(),
      station: "Klang Valley Hub",
      coordinates: { lat: 3.1390, lng: 101.6869 },
      esgImpact: {
        co2Saved: (parseFloat(weight) * 2.3).toFixed(2),
        wasteReduced: weight,
        pointsAwarded: payoutType === 'points' ? amount : 0,
        cashPaid: payoutType === 'cash' ? amount : 0
      }
    };

    const reportContent = JSON.stringify(reportData, null, 2);
    
    // Create and download analytics report
    const blob = new Blob([reportContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SetelGrease_Analytics_${reportData.transactionId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleReviewFraudCases = () => {
    setIsFraudReviewOpen(true);
  };

  const handleNextStep = () => {
    if (verificationStep === 'phone' && phone) {
      setVerificationStep('verify');
    } else if (verificationStep === 'verify' && verificationType) {
      setVerificationStep('complete');
      handleCompleteEntry();
    }
  };

  // Generate oil collection chart data by time of day
  const generateOilCollectionData = () => {
    const data = [];
    const selectedDate = chartSelectedDate;
    const july25th2025 = new Date('2025-07-25');
    const isPurpleDate = selectedDate >= july25th2025;
    
    // Generate hourly data from 6 AM to 10 PM (16 hours)
    for (let hour = 6; hour <= 22; hour++) {
      let timeLabel;
      if (hour === 12) {
        timeLabel = '12:00 PM';
      } else if (hour < 12) {
        timeLabel = `${hour}:00 AM`;
      } else {
        timeLabel = `${hour - 12}:00 PM`;
      }
      
      // Simulate realistic collection patterns throughout the day
      let baseAmount;
      if (hour >= 6 && hour <= 9) {
        baseAmount = 8; // Morning peak
      } else if (hour >= 10 && hour <= 16) {
        baseAmount = 15; // Midday peak
      } else if (hour >= 17 && hour <= 20) {
        baseAmount = 12; // Evening moderate
      } else {
        baseAmount = 5; // Low activity
      }
      
      const variation = Math.random() * 6 - 3; // ±3 variation
      const oilCollected = Math.max(0, Math.round((baseAmount + variation) * 10) / 10);
      
      data.push({
        time: timeLabel,
        oilCollected,
        isPurpleDate
      });
    }
    
    return data;
  };

  const chartData = generateOilCollectionData();

  if (!isAuthenticated || user?.role !== 'collector') {
    return null;
  }

  const renderDashboardTab = () => (
    <div className="space-y-4">
      {/* BLE Scale Status */}
      {isOnline && scaleWeight && (
        <Card className="border-green-200 bg-green-50 mx-4">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Scale className="h-5 w-5 text-green-600" />
                <span className="text-green-800 font-medium">BLE Scale Connected</span>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-800">
                  {scaleWeight.toFixed(1)} kg
                </div>
                <div className="text-xs text-green-600">Live reading</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Primary Action Buttons */}
      <div className="px-4 space-y-3">
        <Dialog open={isAddEntryOpen} onOpenChange={setIsAddEntryOpen}>
          <DialogTrigger asChild>
            <Button className="w-full bg-petronas-blue hover:bg-petronas-light text-white py-6 text-lg font-medium">
              <Plus className="h-6 w-6 mr-2" />
              Add New Collection Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {verificationStep === 'phone' && 'New Collection Entry'}
                {verificationStep === 'verify' && 'Verify Customer Identity'}
                {verificationStep === 'proof' && 'Capture Proof'}
                {verificationStep === 'complete' && 'Entry Complete'}
              </DialogTitle>
            </DialogHeader>
            
            {/* Step 1: Basic Info */}
            {verificationStep === 'phone' && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="phone">Household Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+60123456789"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Oil Weight (kg)</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="weight"
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                    />
                    {scaleWeight && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setWeight(scaleWeight.toString())}
                        className="shrink-0"
                      >
                        Use Scale: {scaleWeight.toFixed(1)}kg
                      </Button>
                    )}
                  </div>
                </div>
                <div>
                  <Label htmlFor="payoutType">Payout Method</Label>
                  <Select value={payoutType} onValueChange={(value: 'cash' | 'points') => setPayoutType(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select payout method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash Payment</SelectItem>
                      <SelectItem value="points">Setel Points</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="amount">Amount</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    placeholder={payoutType === 'cash' ? "0.00" : "0"}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {payoutType === 'cash' ? 'Cash amount in RM' : 'Points to credit'}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={resetEntryForm}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleNextStep}
                    disabled={!phone || !weight || !amount}
                    className="flex-1 bg-petronas-blue hover:bg-petronas-light"
                  >
                    Next: Verify Customer
                  </Button>
                </div>
              </div>
            )}

            {/* Step 2: Identity Verification */}
            {verificationStep === 'verify' && (
              <div className="space-y-4">
                <div className="text-center">
                  <Shield className="mx-auto h-12 w-12 text-blue-600 mb-3" />
                  <p className="text-sm text-gray-600 mb-4">
                    Choose a verification method to confirm customer identity
                  </p>
                </div>

                <div className="space-y-3">
                  <Button
                    onClick={() => setVerificationType('face')}
                    variant={verificationType === 'face' ? "default" : "outline"}
                    className="w-full p-4 h-auto flex items-center justify-start space-x-3"
                  >
                    <Eye className="h-6 w-6 text-green-600" />
                    <div className="text-left">
                      <div className="font-medium">Face Recognition</div>
                      <div className="text-xs text-gray-500">Use camera to verify identity</div>
                    </div>
                    {verificationType === 'face' && <Check className="h-5 w-5 text-green-600 ml-auto" />}
                  </Button>

                  <Button
                    onClick={() => setVerificationType('ic')}
                    variant={verificationType === 'ic' ? "default" : "outline"}
                    className="w-full p-4 h-auto flex items-center justify-start space-x-3"
                  >
                    <CreditCard className="h-6 w-6 text-blue-600" />
                    <div className="text-left">
                      <div className="font-medium">IC Verification</div>
                      <div className="text-xs text-gray-500">Scan Malaysian IC card</div>
                    </div>
                    {verificationType === 'ic' && <Check className="h-5 w-5 text-blue-600 ml-auto" />}
                  </Button>

                  <Button
                    onClick={() => setVerificationType('otp')}
                    variant={verificationType === 'otp' ? "default" : "outline"}
                    className="w-full p-4 h-auto flex items-center justify-start space-x-3"
                  >
                    <Smartphone className="h-6 w-6 text-purple-600" />
                    <div className="text-left">
                      <div className="font-medium">Mobile OTP</div>
                      <div className="text-xs text-gray-500">Send verification code to {phone}</div>
                    </div>
                    {verificationType === 'otp' && <Check className="h-5 w-5 text-purple-600 ml-auto" />}
                  </Button>
                </div>

                {verificationType && (
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <Check className="mx-auto h-12 w-12 text-green-600 mb-2" />
                    <p className="text-green-800 font-medium">
                      {verificationType === 'face' && 'Face Recognition Selected'}
                      {verificationType === 'ic' && 'IC Verification Selected'}
                      {verificationType === 'otp' && 'Mobile OTP Selected'}
                    </p>
                    <p className="text-sm text-green-600">Ready to proceed with transaction</p>
                  </div>
                )}

                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    onClick={() => setVerificationStep('phone')}
                    className="flex-1"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={handleNextStep}
                    disabled={!verificationType || addEntryMutation.isPending}
                    className="flex-1 bg-petronas-blue hover:bg-petronas-light"
                  >
                    {addEntryMutation.isPending ? "Processing..." : "Save & Generate Receipt"}
                  </Button>
                </div>
              </div>
            )}

            {/* Step 3: Transaction Complete */}
            {verificationStep === 'complete' && (
              <div className="space-y-4 text-center">
                <div className="p-6 bg-green-50 rounded-lg">
                  <Check className="mx-auto h-16 w-16 text-green-600 mb-4" />
                  <h3 className="text-lg font-medium text-green-800 mb-2">
                    Transaction Completed Successfully!
                  </h3>
                  <p className="text-sm text-green-600 mb-4">
                    Collection entry has been saved and processed
                  </p>
                  
                  {/* Transaction Summary */}
                  <div className="bg-white p-4 rounded-lg border text-left">
                    <h4 className="font-medium text-gray-900 mb-2">Transaction Summary</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Phone:</span>
                        <span className="font-medium">{phone}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Weight:</span>
                        <span className="font-medium">{weight} kg</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Payout:</span>
                        <span className="font-medium">
                          {payoutType === 'cash' ? `RM ${amount}` : `${amount} points`}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Verification:</span>
                        <span className="font-medium capitalize">{verificationType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Date & Time:</span>
                        <span className="font-medium">{new Date().toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-2 mt-6">
                    <Button 
                      onClick={generateReceipt}
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      <Receipt className="h-4 w-4 mr-2" />
                      Generate Receipt
                    </Button>
                    <Button 
                      onClick={generateReport}
                      variant="outline"
                      className="flex-1"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Analytics Report
                    </Button>
                  </div>

                  <Button 
                    onClick={resetEntryForm}
                    variant="outline"
                    className="w-full mt-3"
                  >
                    Add Another Entry
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={isOfflineEntryOpen} onOpenChange={setIsOfflineEntryOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              className="w-full py-6 text-lg font-medium border-2 border-petronas-blue text-petronas-blue hover:bg-petronas-blue hover:text-white"
            >
              <Upload className="h-6 w-6 mr-2" />
              Upload Offline Entries
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Upload Offline Collection Data</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="file">Select CSV File</Label>
                <Input
                  id="file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => setUploadedFile(e.target.files?.[0] || null)}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Upload collection data collected while offline
                </p>
              </div>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsOfflineEntryOpen(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  disabled={!uploadedFile}
                  className="flex-1 bg-petronas-blue hover:bg-petronas-light"
                >
                  Upload
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Fraud Detection Alert */}
      <div className="px-4">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-2 h-2 bg-red-500 rounded-full mt-2"></div>
              <div className="flex-1">
                <h4 className="text-sm font-medium text-red-800">Fraud Detection Alert</h4>
                <p className="text-sm text-red-700 mt-1">
                  AI system detected 2 suspicious transactions requiring review
                </p>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={handleReviewFraudCases}
                  className="mt-2 text-red-700 border-red-300 hover:bg-red-100"
                >
                  Review Cases
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Date Selector for Performance Data */}
      <div className="px-4">
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Performance Data</CardTitle>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-40"
                min="2024-12-01"
                max={new Date().toISOString().split('T')[0]}
              />
            </div>
            <p className="text-sm text-gray-500">View daily collection performance for the last 6 months</p>
          </CardHeader>
        </Card>
      </div>

      {/* Performance Cards */}
      <div className="px-4">
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Banknote className="h-5 w-5 text-green-600" />
                <span className="text-sm font-medium">Cash Paid Out</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">
                RM {todayStats.cashPaidOut.toFixed(2)}
              </div>
              <div className="text-xs text-gray-500">{todayStats.transactions} transactions</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Coins className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium">Points Credited</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">
                {todayStats.pointsPaidOut}
              </div>
              <div className="text-xs text-gray-500">Setel Points</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Users className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium">Households</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">
                {todayStats.householdsServed}
              </div>
              <div className="text-xs text-gray-500">served today</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Weight className="h-5 w-5 text-orange-600" />
                <span className="text-sm font-medium">Oil Collected</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">
                {todayStats.totalKg} kg
              </div>
              <div className="text-xs text-gray-500">total weight</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Oil Collection Chart */}
      <div className="px-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Hourly Oil Collection
                </CardTitle>
                <p className="text-sm text-gray-600 mt-1">Collection by time of day</p>
              </div>
              <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="flex items-center space-x-2">
                    <CalendarDays className="h-4 w-4" />
                    <span>{format(chartSelectedDate, "MMM dd, yyyy")}</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <CalendarComponent
                    mode="single"
                    selected={chartSelectedDate}
                    onSelect={(date) => {
                      if (date) {
                        setChartSelectedDate(date);
                        setIsCalendarOpen(false);
                      }
                    }}
                    disabled={(date) => {
                      const july1st2025 = new Date('2025-07-01');
                      const august31st2025 = new Date('2025-08-31');
                      return date < july1st2025 || date > august31st2025;
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="time" 
                    tick={{ fontSize: 11 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    label={{ value: 'Oil (kg)', angle: -90, position: 'insideLeft' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="oilCollected"
                    stroke={chartData.length > 0 && chartData[0].isPurpleDate ? "#8b5cf6" : "#3b82f6"}
                    strokeWidth={2}
                    dot={{ 
                      fill: chartData.length > 0 && chartData[0].isPurpleDate ? "#8b5cf6" : "#3b82f6", 
                      strokeWidth: 2, 
                      r: 3 
                    }}
                    name="Oil Collected (kg)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center space-x-6 mt-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-0.5 ${chartData.length > 0 && chartData[0].isPurpleDate ? "bg-purple-500" : "bg-blue-500"}`}></div>
                <span className="text-gray-600">
                  {chartData.length > 0 && chartData[0].isPurpleDate 
                    ? `${format(chartSelectedDate, "MMM dd")} (July 25+)` 
                    : `${format(chartSelectedDate, "MMM dd")} (July 24-)`}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Fraud Review Dialog */}
      <Dialog open={isFraudReviewOpen} onOpenChange={setIsFraudReviewOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Fraud Detection Review</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-3">
              <div className="border-l-4 border-red-500 p-4 bg-red-50 rounded">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-red-800">Suspicious Transaction #1</h4>
                    <p className="text-sm text-red-700 mt-1">Phone: +60123456789</p>
                    <p className="text-sm text-red-700">Weight: 15.2 kg (unusually high)</p>
                    <p className="text-sm text-red-700">Time: 14:32 (multiple visits today)</p>
                  </div>
                  <Badge variant="destructive">High Risk</Badge>
                </div>
                <div className="flex space-x-2 mt-3">
                  <Button size="sm" variant="outline" className="text-green-700 border-green-300">
                    Approve
                  </Button>
                  <Button size="sm" variant="outline" className="text-red-700 border-red-300">
                    Flag
                  </Button>
                </div>
              </div>
              
              <div className="border-l-4 border-yellow-500 p-4 bg-yellow-50 rounded">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-yellow-800">Suspicious Transaction #2</h4>
                    <p className="text-sm text-yellow-700 mt-1">Phone: +60187654321</p>
                    <p className="text-sm text-yellow-700">Weight: 8.9 kg (repeated patterns)</p>
                    <p className="text-sm text-yellow-700">Time: 16:45 (similar timing pattern)</p>
                  </div>
                  <Badge variant="secondary">Medium Risk</Badge>
                </div>
                <div className="flex space-x-2 mt-3">
                  <Button size="sm" variant="outline" className="text-green-700 border-green-300">
                    Approve
                  </Button>
                  <Button size="sm" variant="outline" className="text-red-700 border-red-300">
                    Flag
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setIsFraudReviewOpen(false)}
              >
                Close
              </Button>
              <Button className="bg-petronas-blue hover:bg-petronas-light">
                Submit Review
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );

  const renderReportsTab = () => (
    <div className="space-y-4">
      {/* Reports Header */}
      <div className="px-4 py-4 bg-white shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold text-gray-900">Reports & Analytics</h2>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
        <p className="text-sm text-gray-600">Generate and download comprehensive reports and analytics</p>
      </div>

      {/* Quick Actions */}
      <div className="px-4 space-y-3">
        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 text-lg">
          <FileText className="h-5 w-5 mr-2" />
          Custom Report Builder
        </Button>
        
        <Button variant="outline" className="w-full py-4 text-lg border-2">
          <Calendar className="h-5 w-5 mr-2" />
          Schedule Report
        </Button>
      </div>

      {/* Predefined Reports */}
      <div className="px-4">
        <h3 className="text-lg font-semibold mb-4">Predefined Reports</h3>
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">Monthly ESG Report</h4>
                  <p className="text-sm text-gray-600 mt-1">Comprehensive environmental, social, and governance metrics</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span>Last: 2024-03-01</span>
                    <span>PDF</span>
                    <span>2.4 MB</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                    Download
                  </Button>
                  <Button size="sm" variant="outline">
                    Generate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">Quarterly Board Report</h4>
                  <p className="text-sm text-gray-600 mt-1">Executive summary for board presentations</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span>Last: 2024-03-01</span>
                    <span>PDF</span>
                    <span>1.8 MB</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                    Download
                  </Button>
                  <Button size="sm" variant="outline">
                    Generate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">Partner Performance Report</h4>
                  <p className="text-sm text-gray-600 mt-1">Detailed analysis of partner collection metrics</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span>Last: 2024-03-10</span>
                    <span>Excel</span>
                    <span>5.2 MB</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                    Download
                  </Button>
                  <Button size="sm" variant="outline">
                    Generate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">Weekly Operations Summary</h4>
                  <p className="text-sm text-gray-600 mt-1">Weekly operational metrics and KPIs</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span>Last: 2024-03-15</span>
                    <span>PDF</span>
                    <span>1.1 MB</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                    Download
                  </Button>
                  <Button size="sm" variant="outline">
                    Generate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Custom Report Builder */}
      <div className="px-4">
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Build Custom Reports
            </CardTitle>
            <p className="text-sm text-gray-500">Create customized reports with specific data fields and date ranges</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center py-8 text-gray-500">
              <FileText className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">Build Custom Reports</p>
              <p className="text-sm mb-4">Create customized reports with specific data fields and date ranges</p>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="h-4 w-4 mr-2" />
                Start Building
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderESGTab = () => (
    <div className="space-y-4">
      {/* ESG Header */}
      <div className="px-4 py-4 bg-white shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold text-gray-900">ESG Impact</h2>
          <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white">
            <FileText className="h-4 w-4 mr-2" />
            Export ESG Report
          </Button>
        </div>
        <p className="text-sm text-gray-600">Environmental impact for Klang Valley Hub collection point</p>
      </div>

      {/* Monthly Impact Cards */}
      <div className="px-4">
        <h3 className="text-md font-semibold mb-3 text-gray-800">This Month's Impact</h3>
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">CO₂ Saved</p>
                  <p className="text-2xl font-bold text-green-700">{esgMetrics.monthly.co2Saved} tons</p>
                  <p className="text-xs text-green-600">This month</p>
                </div>
                <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                  <Leaf className="h-5 w-5 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Waste Diverted</p>
                  <p className="text-2xl font-bold text-blue-700">{esgMetrics.monthly.wasteReduced} tons</p>
                  <p className="text-xs text-blue-600">From landfills</p>
                </div>
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                  <Droplets className="h-5 w-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Oil Collected</p>
                  <p className="text-2xl font-bold text-orange-700">{esgMetrics.monthly.oilCollected} kg</p>
                  <p className="text-xs text-orange-600">Recycled UCO</p>
                </div>
                <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center">
                  <Weight className="h-5 w-5 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Households</p>
                  <p className="text-2xl font-bold text-purple-700">{esgMetrics.monthly.householdsServed}</p>
                  <p className="text-xs text-purple-600">Engaged</p>
                </div>
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                  <Users className="h-5 w-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Year to Date Summary */}
      <div className="px-4">
        <Card className="bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-lg text-green-800">Year-to-Date Impact Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-700">{esgMetrics.ytd.co2Saved}</div>
                <div className="text-sm text-green-600">tons CO₂ saved</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-700">{esgMetrics.ytd.oilCollected}</div>
                <div className="text-sm text-blue-600">kg oil collected</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-700">{esgMetrics.ytd.householdsServed}</div>
                <div className="text-sm text-purple-600">households served</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-700">{esgMetrics.ytd.wasteReduced}</div>
                <div className="text-sm text-orange-600">tons waste diverted</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Environmental Impact Calculation */}
      <div className="px-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Calculator className="h-5 w-5 mr-2" />
              Impact Calculations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3">Conversion Factors</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">1 kg UCO →</span>
                  <span className="font-medium">3.0 kg CO₂ savings</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">1 ton CO₂ →</span>
                  <span className="font-medium">25 carbon credits</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">1 kg UCO →</span>
                  <span className="font-medium">RM 2.50 economic value</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-700">{Math.round(esgMetrics.ytd.co2Saved * 25)}</div>
                <div className="text-sm text-green-600">Carbon Credits Earned</div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-700">RM {(esgMetrics.ytd.oilCollected * 2.5).toLocaleString()}</div>
                <div className="text-sm text-blue-600">Economic Value Generated</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* SDG Alignment */}
      <div className="px-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">UN SDG Alignment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium text-gray-900">SDG 12: Responsible Consumption</span>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div className="h-2 bg-green-500 rounded-full" style={{ width: '92%' }}></div>
                  </div>
                  <span className="text-sm font-semibold text-green-700">92%</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <span className="text-sm font-medium text-gray-900">SDG 13: Climate Action</span>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div className="h-2 bg-blue-500 rounded-full" style={{ width: '88%' }}></div>
                  </div>
                  <span className="text-sm font-semibold text-blue-700">88%</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                <span className="text-sm font-medium text-gray-900">SDG 11: Sustainable Cities</span>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div className="h-2 bg-purple-500 rounded-full" style={{ width: '85%' }}></div>
                  </div>
                  <span className="text-sm font-semibold text-purple-700">85%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Achievements */}
      <div className="px-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Achievements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center p-3 bg-green-50 rounded-lg">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Monthly target exceeded</p>
                  <p className="text-xs text-gray-600">Collected 890kg vs 750kg target for March</p>
                </div>
              </div>
              
              <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">New household record</p>
                  <p className="text-xs text-gray-600">156 households engaged this month</p>
                </div>
              </div>
              
              <div className="flex items-center p-3 bg-purple-50 rounded-lg">
                <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Carbon savings milestone</p>
                  <p className="text-xs text-gray-600">Reached 18.7 tons CO₂ saved YTD</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Mobile Header */}
      <div className="bg-petronas-blue text-white p-4 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src="/neos-profile.png" alt="NEOS" />
              <AvatarFallback>NE</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="font-semibold text-lg">NEOS Collector</h1>
              <div className="flex items-center space-x-2 text-sm opacity-90">
                <MapPin className="h-3 w-3" />
                <span>Klang Valley Hub</span>
                {isOnline ? (
                  <Wifi className="h-3 w-3 text-green-300" />
                ) : (
                  <WifiOff className="h-3 w-3 text-red-300" />
                )}
              </div>
            </div>
          </div>
          <Badge className={isOnline ? "bg-green-500" : "bg-red-500"}>
            {isOnline ? "Online" : "Offline"}
          </Badge>
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 pb-20">
        {activeTab === 'dashboard' && renderDashboardTab()}
        {activeTab === 'reports' && renderReportsTab()}
        {activeTab === 'esg' && renderESGTab()}
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-2">
        <div className="flex justify-around">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center py-2 px-3 rounded-lg ${
              activeTab === 'dashboard' 
                ? 'bg-petronas-blue text-white' 
                : 'text-gray-600 hover:text-petronas-blue'
            }`}
          >
            <Home className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Dashboard</span>
          </button>
          
          <button
            onClick={() => setActiveTab('reports')}
            className={`flex flex-col items-center py-2 px-3 rounded-lg ${
              activeTab === 'reports' 
                ? 'bg-petronas-blue text-white' 
                : 'text-gray-600 hover:text-petronas-blue'
            }`}
          >
            <BarChart3 className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Reports</span>
          </button>

          <button
            onClick={() => setActiveTab('esg')}
            className={`flex flex-col items-center py-2 px-3 rounded-lg ${
              activeTab === 'esg' 
                ? 'bg-petronas-blue text-white' 
                : 'text-gray-600 hover:text-petronas-blue'
            }`}
          >
            <Leaf className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">ESG</span>
          </button>
        </div>
      </div>
    </div>
  );
}