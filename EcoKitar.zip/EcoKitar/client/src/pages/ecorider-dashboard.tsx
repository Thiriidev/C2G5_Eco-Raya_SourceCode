import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { useLanguage } from "@/lib/i18n";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { LanguageToggle } from "@/components/language-toggle";
import { 
  MapPin, Navigation, Package, CheckCircle, Clock, 
  Route, Truck, AlertTriangle, LogOut, Home, Map, List,
  User, Send, Bot, Play, Pause, Scale, Wifi, WifiOff,
  Camera, PenTool, Square, CircleDot, X, Plus, Gift, Coins, Wallet
} from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import type { RecyclableItem, Report, RoutePlan } from "@shared/schema";
import { CATEGORY_COLORS, CATEGORIES, CATEGORY_CONSTRAINTS, REWARD_RATES } from "@shared/schema";
import { MapContainer, TileLayer, Marker, Popup, useMap, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import ecoKitarLogo from "@assets/1000150524_1762361284650.jpg";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

const createCategoryIcon = (category: string) => {
  const color = CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS] || "#4DA6FF";
  return L.divIcon({
    className: "custom-marker",
    html: `<div style="
      background-color: ${color};
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border: 3px solid white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
    ">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
        <path d="M3 6h18"/>
        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
      </svg>
    </div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

const createRouteIcon = (sequence: number, routeStatus: string) => {
  let bgColor = "#10B981";
  let borderColor = "#059669";
  
  if (routeStatus === "off_route") {
    bgColor = "#FBBF24";
    borderColor = "#D97706";
  } else if (routeStatus === "wrong_category") {
    bgColor = "#EF4444";
    borderColor = "#DC2626";
  } else if (routeStatus === "completed") {
    bgColor = "#6B7280";
    borderColor = "#4B5563";
  }
  
  return L.divIcon({
    className: "route-marker",
    html: `<div style="
      background-color: ${bgColor};
      width: 36px;
      height: 36px;
      border-radius: 50%;
      border: 4px solid ${borderColor};
      box-shadow: 0 3px 10px rgba(0,0,0,0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 14px;
      color: white;
    ">${routeStatus === "on_route" ? sequence : (routeStatus === "completed" ? "✓" : "")}</div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
};

const reportIcon = L.divIcon({
  className: "custom-marker",
  html: `<div style="
    background-color: #FF6666;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: 3px solid white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
  ">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>
      <path d="M12 9v4"/>
      <path d="M12 17h.01"/>
    </svg>
  </div>`,
  iconSize: [32, 32],
  iconAnchor: [16, 16],
});

const riderIcon = L.divIcon({
  className: "custom-marker",
  html: `<div style="
    background-color: #22C55E;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 4px solid white;
    box-shadow: 0 2px 10px rgba(0,0,0,0.4);
    display: flex;
    align-items: center;
    justify-content: center;
  ">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
      <circle cx="12" cy="12" r="10"/>
      <circle cx="12" cy="10" r="3"/>
      <path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662"/>
    </svg>
  </div>`,
  iconSize: [40, 40],
  iconAnchor: [20, 20],
});

function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, 15);
  }, [center, map]);
  return null;
}

export default function EcoRiderDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState("map");
  const [selectedItem, setSelectedItem] = useState<RecyclableItem | null>(null);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [riderLocation, setRiderLocation] = useState<[number, number]>([3.139, 101.6869]);
  const [isTracking, setIsTracking] = useState(false);
  const [aiChatOpen, setAiChatOpen] = useState(false);
  const [aiMessage, setAiMessage] = useState("");
  const [aiConversation, setAiConversation] = useState<{role: string; content: string}[]>([]);
  const [aiLoading, setAiLoading] = useState(false);
  const watchIdRef = useRef<number | null>(null);
  
  // BLE Scale states
  const [isScaleConnected, setIsScaleConnected] = useState(false);
  const [scaleWeight, setScaleWeight] = useState<number | null>(null);
  const [isWeighing, setIsWeighing] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  // Collection flow states
  const [collectionDialogOpen, setCollectionDialogOpen] = useState(false);
  const [collectionStep, setCollectionStep] = useState<'weigh' | 'photo' | 'signature' | 'complete'>('weigh');
  const [confirmedWeight, setConfirmedWeight] = useState<number | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [customerSignature, setCustomerSignature] = useState<string | null>(null);
  
  // Route planning states
  const [routeDialogOpen, setRouteDialogOpen] = useState(false);
  const [routePlanningLoading, setRoutePlanningLoading] = useState(false);
  const [routeForm, setRouteForm] = useState({
    riderName: "",
    truckCapacityKg: 500,
    selectedCategories: [] as string[],
  });

  // Reward credit dialog states
  const [rewardDialogOpen, setRewardDialogOpen] = useState(false);
  const [pendingRewardItem, setPendingRewardItem] = useState<RecyclableItem | null>(null);
  const [rewardType, setRewardType] = useState<"points" | "cashback">("points");
  const [actualWeight, setActualWeight] = useState<string>("");

  // Fetch active route from server
  const { data: activeRouteData } = useQuery<{
    active: boolean;
    plan: RoutePlan | null;
    items: (RecyclableItem & { lat: number; lng: number; routeStatus?: string; routeSequence?: number })[];
  }>({
    queryKey: ["/api/routes/active"],
    refetchInterval: 10000,
  });

  // Derived active route state from server
  const activeRoute = activeRouteData?.active ? {
    plan: activeRouteData.plan,
    items: activeRouteData.items || []
  } : null;

  const getCategoryLabel = (category: string) => {
    return t(category) || category;
  };

  useEffect(() => {
    if (!user) {
      setLocation("/login");
      return;
    }
    if (user.role !== "ecorider" && user.role !== "collector") {
      if (user.role === "jabatan" || user.role === "petronas") {
        setLocation("/jabatan");
      } else if (user.role === "ecorakyat") {
        setLocation("/ecorakyat");
      }
    }
  }, [user, setLocation]);

  // Monitor online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Simulate BLE scale connection
  useEffect(() => {
    let scaleInterval: NodeJS.Timeout | null = null;
    
    if (isScaleConnected && isWeighing) {
      scaleInterval = setInterval(() => {
        // Simulate weight fluctuation while weighing
        setScaleWeight(prev => {
          if (prev === null) return Math.random() * 3 + 0.5;
          return prev + (Math.random() - 0.5) * 0.1;
        });
      }, 500);
    }
    
    return () => {
      if (scaleInterval) clearInterval(scaleInterval);
    };
  }, [isScaleConnected, isWeighing]);

  const { data: stats } = useQuery<{
    pendingCollections: number;
    completedToday: number;
    totalKgCollected: number;
    activeRoute: RoutePlan | null;
    pendingReports: number;
  }>({
    queryKey: ["/api/ecorider/stats", user?.id],
    enabled: !!user?.id,
  });

  const { data: pendingData } = useQuery<{
    items: RecyclableItem[];
    reports: Report[];
  }>({
    queryKey: ["/api/ecorider/pending-pickups"],
    refetchInterval: 30000,
  });

  const { data: myAssignedData } = useQuery<{
    items: RecyclableItem[];
    reports: Report[];
  }>({
    queryKey: ["/api/ecorider/my-assignments", user?.id],
    enabled: !!user?.id,
  });

  const assignItemMutation = useMutation({
    mutationFn: async (itemId: number) => {
      return apiRequest("PATCH", `/api/recyclable-items/${itemId}/assign`, { riderId: user?.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/my-assignments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/stats"] });
      toast({
        title: t("success"),
        description: t("item_assigned"),
      });
      setSelectedItem(null);
    },
  });

  const collectItemMutation = useMutation({
    mutationFn: async (data: { itemId: number; actualWeight?: number }) => {
      return apiRequest("PATCH", `/api/recyclable-items/${data.itemId}/collect`, { 
        actualWeight: data.actualWeight,
        collectedAt: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/my-assignments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/stats"] });
      toast({
        title: t("success"),
        description: t("item_collected"),
      });
      setSelectedItem(null);
      setCollectionDialogOpen(false);
      resetCollectionFlow();
    },
  });

  const assignReportMutation = useMutation({
    mutationFn: async (reportId: number) => {
      return apiRequest("PATCH", `/api/reports/${reportId}/assign`, { riderId: user?.id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/my-assignments"] });
      toast({
        title: t("success"),
        description: t("report_assigned"),
      });
      setSelectedReport(null);
    },
  });

  const resolveReportMutation = useMutation({
    mutationFn: async (reportId: number) => {
      return apiRequest("PATCH", `/api/reports/${reportId}/resolve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/my-assignments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/stats"] });
      toast({
        title: t("success"),
        description: t("report_resolved"),
      });
      setSelectedReport(null);
    },
  });

  // Route optimization mutations
  const startRouteMutation = useMutation({
    mutationFn: async () => {
      const allRestrictedCategories = routeForm.selectedCategories.flatMap(
        cat => CATEGORY_CONSTRAINTS[cat] || []
      );
      const uniqueRestricted = Array.from(new Set(allRestrictedCategories));
      
      const response = await apiRequest("POST", "/api/routes/optimize", {
        riderName: routeForm.riderName || user?.name,
        truckCapacityKg: routeForm.truckCapacityKg,
        selectedCategories: routeForm.selectedCategories,
        restrictedCategories: uniqueRestricted,
        truckLocation: { lat: riderLocation[0], lng: riderLocation[1] },
        language: language
      });
      return response.json();
    },
    onSuccess: (data) => {
      setRouteDialogOpen(false);
      setRoutePlanningLoading(false);
      queryClient.invalidateQueries({ queryKey: ["/api/routes/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      toast({
        title: t("route_started"),
        description: data.routePlan.aiSummary || t("route_calculated"),
      });
    },
    onError: () => {
      setRoutePlanningLoading(false);
      toast({
        title: t("error"),
        description: t("route_optimization_failed"),
        variant: "destructive",
      });
    }
  });

  const creditRewardMutation = useMutation({
    mutationFn: async ({ itemId, rewardType, actualWeightKg }: { itemId: number; rewardType: string; actualWeightKg?: number }) => {
      const response = await apiRequest("POST", "/api/rewards/credit", { itemId, rewardType, actualWeightKg });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: language === "en" ? "Reward Credited!" : "Ganjaran Dikreditkan!",
        description: data.rewardType === "points" 
          ? `${data.pointsEarned} ${language === "en" ? "points earned" : "mata diperolehi"}`
          : `RM${data.cashbackEarned} ${language === "en" ? "cashback earned" : "pulangan tunai diperolehi"}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rewards/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rewards/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/vouchers/my"] });
    }
  });

  const completeRouteItemMutation = useMutation({
    mutationFn: async (itemId: number) => {
      return apiRequest("PATCH", `/api/routes/${activeRoute?.plan?.id}/items/${itemId}/complete`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routes/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      toast({
        title: t("success"),
        description: t("location_completed"),
      });
      setSelectedItem(null);
      setRewardDialogOpen(false);
      setPendingRewardItem(null);
      setActualWeight("");
    }
  });

  const handleCompleteWithReward = async () => {
    if (!pendingRewardItem) return;
    
    const weightKg = actualWeight ? parseFloat(actualWeight) : undefined;
    
    try {
      await creditRewardMutation.mutateAsync({ 
        itemId: pendingRewardItem.id, 
        rewardType, 
        actualWeightKg: weightKg 
      });
      await completeRouteItemMutation.mutateAsync(pendingRewardItem.id);
    } catch (error) {
      console.error("Error completing with reward:", error);
    }
  };

  const openRewardDialog = (item: RecyclableItem) => {
    setPendingRewardItem(item);
    setActualWeight(item.weightEstimateKg?.toString() || "");
    setRewardType("points");
    setRewardDialogOpen(true);
  };

  const removeFromRouteMutation = useMutation({
    mutationFn: async (itemId: number) => {
      return apiRequest("PATCH", `/api/routes/${activeRoute?.plan?.id}/items/${itemId}/remove`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routes/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      toast({
        title: t("success"),
        description: t("location_removed"),
      });
      setSelectedItem(null);
    }
  });

  const addToRouteMutation = useMutation({
    mutationFn: async ({ itemId, sequence }: { itemId: number; sequence: number }) => {
      return apiRequest("PATCH", `/api/routes/${activeRoute?.plan?.id}/items/${itemId}/add`, { sequence });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routes/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      toast({
        title: t("success"),
        description: t("location_added"),
      });
    }
  });

  const endRouteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/routes/${activeRoute?.plan?.id}/end`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routes/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/ecorider/pending-pickups"] });
      toast({
        title: t("route_ended"),
        description: t("success"),
      });
    }
  });

  const handleAiChat = async () => {
    if (!aiMessage.trim()) return;
    
    const userMessage = aiMessage;
    setAiMessage("");
    setAiConversation(prev => [...prev, { role: "user", content: userMessage }]);
    setAiLoading(true);

    try {
      const response = await apiRequest("POST", "/api/ai/chat", { 
        message: userMessage,
        context: "ecorider",
        language: language
      });
      const data = await response.json();
      setAiConversation(prev => [...prev, { role: "assistant", content: data.reply }]);
    } catch (error) {
      toast({
        title: t("error"),
        description: "AI service unavailable",
        variant: "destructive",
      });
    } finally {
      setAiLoading(false);
    }
  };

  const startTracking = () => {
    if (navigator.geolocation) {
      setIsTracking(true);
      watchIdRef.current = navigator.geolocation.watchPosition(
        (position) => {
          setRiderLocation([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.error("Location error:", error);
          toast({
            title: t("location_error_title"),
            description: t("enable_gps"),
            variant: "destructive",
          });
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 1000 }
      );
    }
  };

  const stopTracking = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsTracking(false);
  };

  const toggleScaleConnection = () => {
    if (isScaleConnected) {
      setIsScaleConnected(false);
      setScaleWeight(null);
      setIsWeighing(false);
    } else {
      // Simulate BLE connection
      setIsScaleConnected(true);
      toast({
        title: t("success"),
        description: t("scale_connected"),
      });
    }
  };

  const startWeighing = () => {
    setIsWeighing(true);
    setScaleWeight(0);
  };

  const confirmWeight = () => {
    if (scaleWeight !== null) {
      setConfirmedWeight(parseFloat(scaleWeight.toFixed(2)));
      setIsWeighing(false);
      setCollectionStep('photo');
    }
  };

  const resetCollectionFlow = () => {
    setCollectionStep('weigh');
    setConfirmedWeight(null);
    setCapturedPhoto(null);
    setCustomerSignature(null);
    setIsWeighing(false);
    setScaleWeight(null);
  };

  const simulatePhotoCapture = () => {
    setCapturedPhoto("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/mock-photo");
    setCollectionStep('signature');
  };

  const simulateSignatureCapture = () => {
    setCustomerSignature("data:image/svg+xml;base64,mock-signature");
    setCollectionStep('complete');
  };

  const completeCollection = () => {
    if (selectedItem && confirmedWeight !== null) {
      collectItemMutation.mutate({ 
        itemId: selectedItem.id, 
        actualWeight: confirmedWeight 
      });
    }
  };

  const handleLogout = () => {
    stopTracking();
    logout();
    setLocation("/login");
  };

  const handleStartRoute = () => {
    setRouteForm({
      riderName: user?.name || "",
      truckCapacityKg: 500,
      selectedCategories: [],
    });
    setRouteDialogOpen(true);
  };

  const handleRouteSubmit = () => {
    if (routeForm.selectedCategories.length === 0) {
      toast({
        title: t("category_required"),
        description: t("select_collection_category"),
        variant: "destructive",
      });
      return;
    }
    setRoutePlanningLoading(true);
    startRouteMutation.mutate();
  };

  const handleEndRoute = () => {
    endRouteMutation.mutate();
  };

  const getItemRouteInfo = (item: RecyclableItem) => {
    if (!activeRoute) return null;
    
    const routeItem = activeRoute.items.find(ri => ri.id === item.id);
    if (routeItem) {
      return {
        isOnRoute: routeItem.routeStatus === "on_route",
        isCompleted: routeItem.routeStatus === "completed",
        isOffRoute: routeItem.routeStatus === "off_route",
        isWrongCategory: routeItem.routeStatus === "wrong_category",
        sequence: routeItem.routeSequence
      };
    }
    
    const selectedCategories = activeRoute.plan?.selectedCategories || 
      (activeRoute.plan?.selectedCategory ? [activeRoute.plan.selectedCategory] : []);
    if (selectedCategories.includes(item.category)) {
      return { isOffRoute: true };
    }
    return { isWrongCategory: true };
  };

  const getRoutePositions = (): [number, number][] => {
    if (!activeRoute) return [];
    const sortedItems = activeRoute.items
      .filter(item => item.routeStatus === "on_route")
      .sort((a, b) => (a.routeSequence || 0) - (b.routeSequence || 0));
    return [
      riderLocation,
      ...sortedItems.map(item => [item.lat, item.lng] as [number, number])
    ];
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { labelKey: string; color: string }> = {
      new: { labelKey: "status_new", color: "bg-blue-500" },
      assigned: { labelKey: "status_assigned", color: "bg-yellow-500" },
      in_progress: { labelKey: "status_in_progress", color: "bg-orange-500" },
      collected: { labelKey: "status_collected", color: "bg-green-500" },
      resolved: { labelKey: "status_resolved", color: "bg-green-500" },
    };
    const { labelKey, color } = statusMap[status] || { labelKey: status, color: "bg-gray-500" };
    return <Badge className={`${color} text-white`}>{t(labelKey)}</Badge>;
  };

  const getSeverityLabel = (severity: string) => {
    return t(severity) || severity;
  };

  if (!user) return null;

  const allItems = pendingData?.items || [];
  const allReports = pendingData?.reports || [];
  const myAssignedItems = myAssignedData?.items || [];
  const myAssignedReports = myAssignedData?.reports || [];

  return (
    <div className="min-h-screen flex flex-col bg-eco-gradient" data-testid="ecorider-dashboard">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-4 shadow-xl z-10">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img 
              src={ecoKitarLogo} 
              alt="EcoKitar Logo" 
              className="h-10 w-10 rounded-lg object-cover shadow-md"
            />
            <div>
              <p className="text-emerald-200 text-xs">{t("ecorider")}</p>
              <h1 className="text-xl font-bold" data-testid="rider-name">{user.name}</h1>
            </div>
          </div>
          <div className="flex gap-2 items-center">
            {/* Online Status */}
            <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${isOnline ? 'bg-emerald-400/30 border border-emerald-300/30' : 'bg-red-400/30 border border-red-300/30'}`}>
              {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
              {isOnline ? t("online") : t("offline")}
            </div>
            <LanguageToggle />
            {/* Route Planning Button */}
            {activeRoute ? (
              <Button
                variant="destructive"
                size="sm"
                onClick={handleEndRoute}
                disabled={endRouteMutation.isPending}
                data-testid="button-end-route"
              >
                <Square className="h-4 w-4 mr-1" />
                {t("end_route")}
              </Button>
            ) : (
              <Button
                size="sm"
                onClick={handleStartRoute}
                className="bg-white/20 hover:bg-white/30 text-white border border-white/30"
                data-testid="button-start-route"
              >
                <Route className="h-4 w-4 mr-1" />
                {t("start_route")}
              </Button>
            )}
            <Button
              size="sm"
              onClick={isTracking ? stopTracking : startTracking}
              className={isTracking ? "bg-red-500 hover:bg-red-600" : "bg-white/20 hover:bg-white/30 text-white border border-white/30"}
              data-testid="button-tracking"
            >
              {isTracking ? <Pause className="h-4 w-4 mr-1" /> : <Play className="h-4 w-4 mr-1" />}
              {isTracking ? t("stop") : t("start")}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/10"
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="flex gap-4 mt-3 flex-wrap">
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/10">
            <Package className="h-4 w-4" />
            <span className="text-sm font-medium" data-testid="stat-pending">
              {stats?.pendingCollections || allItems.length} {t("pickups")}
            </span>
          </div>
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/10">
            <CheckCircle className="h-4 w-4" />
            <span className="text-sm font-medium" data-testid="stat-completed">
              {stats?.completedToday || 0} {t("today")}
            </span>
          </div>
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full border border-white/10">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-sm font-medium" data-testid="stat-reports">
              {stats?.pendingReports || allReports.length} {t("reports")}
            </span>
          </div>
        </div>
      </div>

      {/* Main Content - Scrollable */}
      <div className="flex-1 overflow-y-auto pb-20">
        {activeTab === "map" && (
          <div className="p-4 space-y-4">
            {/* Active Route Summary Card */}
            {activeRoute && (
              <Card className="border-2 border-emerald-400 bg-gradient-to-br from-emerald-50 to-teal-50 shadow-lg">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2 text-emerald-700">
                    <Route className="h-5 w-5" />
                    {t("route_active")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-3 mb-3">
                    <div className="bg-white/80 backdrop-blur-sm p-2 rounded-lg text-center border border-emerald-100">
                      <p className="text-2xl font-bold text-emerald-600">
                        {activeRoute.items.filter(i => i.routeStatus === "on_route").length}
                      </p>
                      <p className="text-xs text-gray-500">{t("stops_remaining")}</p>
                    </div>
                    <div className="bg-white p-2 rounded-lg text-center">
                      <p className="text-2xl font-bold text-blue-600">
                        {Number(activeRoute.plan?.totalDistanceKm ?? 0).toFixed(1)}
                      </p>
                      <p className="text-xs text-gray-500">{t("km")}</p>
                    </div>
                    <div className="bg-white p-2 rounded-lg text-center">
                      <p className="text-2xl font-bold text-orange-600">
                        {activeRoute.plan?.estimatedDurationMin || 0}
                      </p>
                      <p className="text-xs text-gray-500">{t("minutes")}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-3 mb-3">
                    <div className="bg-amber-50 p-2 rounded-lg text-center border border-amber-200">
                      <p className="text-xl font-bold text-amber-600">
                        {activeRoute.plan?.petrolConsumedL?.toFixed(1) || "0.0"}
                      </p>
                      <p className="text-xs text-gray-500">{t("petrol_consumed")} (L)</p>
                    </div>
                    <div className="bg-green-50 p-2 rounded-lg text-center border border-green-200">
                      <p className="text-xl font-bold text-green-600">
                        {activeRoute.plan?.petrolSavedL?.toFixed(1) || "0.0"}
                      </p>
                      <p className="text-xs text-gray-500">{t("petrol_saved")} (L)</p>
                    </div>
                    <div className="bg-cyan-50 p-2 rounded-lg text-center border border-cyan-200">
                      <p className="text-xl font-bold text-cyan-600">
                        {activeRoute.plan?.co2SavedKg?.toFixed(1) || "0.0"}
                      </p>
                      <p className="text-xs text-gray-500">{t("co2_saved")} (kg)</p>
                    </div>
                  </div>
                  
                  {activeRoute.plan?.aiSummary && (
                    <div className="bg-white p-3 rounded-lg mb-3">
                      <p className="text-sm font-medium text-gray-700">{t("ai_route_summary")}</p>
                      <p className="text-sm text-gray-600 mt-1">{activeRoute.plan.aiSummary}</p>
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    <div className="flex items-center gap-1 text-xs">
                      <div className="w-4 h-4 rounded-full bg-green-500" />
                      <span>{t("on_route")}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      <div className="w-4 h-4 rounded-full bg-yellow-500" />
                      <span>{t("off_route")}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs">
                      <div className="w-4 h-4 rounded-full bg-red-500" />
                      <span>{t("wrong_category")}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* BLE Scale Card */}
            <Card className="border-2 border-green-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Scale className="h-5 w-5 text-green-600" />
                  {t("ble_scale")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${isScaleConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`} />
                    <span className="text-sm">
                      {isScaleConnected ? t("scale_connected") : t("scale_disconnected")}
                    </span>
                  </div>
                  <Button
                    variant={isScaleConnected ? "destructive" : "default"}
                    size="sm"
                    onClick={toggleScaleConnection}
                    data-testid="button-connect-scale"
                  >
                    {isScaleConnected ? t("disconnect_scale") : t("connect_scale")}
                  </Button>
                </div>
                
                {isScaleConnected && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <p className="text-sm text-gray-500">{t("live_weight")}</p>
                      <p className="text-4xl font-bold text-green-600" data-testid="scale-weight">
                        {scaleWeight !== null ? scaleWeight.toFixed(2) : "0.00"} kg
                      </p>
                      {isWeighing && (
                        <div className="mt-2">
                          <Progress value={65} className="h-2" />
                          <p className="text-xs text-gray-400 mt-1">{t("weighing")}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Map Container - Fixed height, not fullscreen */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Map className="h-5 w-5 text-green-600" />
                  {t("map")}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[400px] rounded-b-lg overflow-hidden">
                  <MapContainer
                    center={riderLocation}
                    zoom={15}
                    maxZoom={19}
                    minZoom={10}
                    style={{ height: "100%", width: "100%" }}
                    zoomControl={true}
                  >
                    <TileLayer
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      attribution='&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a>'
                      maxZoom={19}
                    />
                    <MapUpdater center={riderLocation} />

                    {/* Rider location */}
                    <Marker position={riderLocation} icon={riderIcon}>
                      <Popup>
                        <div className="text-center">
                          <strong>{t("your_location")}</strong>
                          <p className="text-xs text-gray-500">
                            {isTracking ? t("tracking_location") : t("press_start_track")}
                          </p>
                        </div>
                      </Popup>
                    </Marker>

                    {/* Route polyline when active */}
                    {activeRoute && getRoutePositions().length > 1 && (
                      <Polyline
                        positions={getRoutePositions()}
                        pathOptions={{
                          color: "#10B981",
                          weight: 5,
                          opacity: 0.8,
                          dashArray: "10, 10"
                        }}
                      />
                    )}

                    {/* Recyclable items markers with route-aware colors */}
                    {allItems.map((item) => {
                      const routeInfo = getItemRouteInfo(item);
                      let markerIcon = createCategoryIcon(item.category);
                      
                      if (activeRoute) {
                        if (routeInfo?.isOnRoute) {
                          markerIcon = createRouteIcon(routeInfo.sequence || 0, "on_route");
                        } else if (routeInfo?.isCompleted) {
                          markerIcon = createRouteIcon(0, "completed");
                        } else if (routeInfo?.isOffRoute) {
                          markerIcon = createRouteIcon(0, "off_route");
                        } else if (routeInfo?.isWrongCategory) {
                          markerIcon = createRouteIcon(0, "wrong_category");
                        }
                      }
                      
                      return (
                        <Marker
                          key={`item-${item.id}`}
                          position={[parseFloat(item.latitude), parseFloat(item.longitude)]}
                          icon={markerIcon}
                          eventHandlers={{
                            click: () => setSelectedItem(item),
                          }}
                        >
                          <Popup>
                            <div className="min-w-[150px]">
                              <div className="flex items-center gap-2 mb-2">
                                <div
                                  className="w-3 h-3 rounded-full"
                                  style={{ backgroundColor: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] }}
                                />
                                <strong>{getCategoryLabel(item.category)}</strong>
                              </div>
                              {item.weightEstimateKg && (
                                <p className="text-sm">{t("weight")}: ~{item.weightEstimateKg} kg</p>
                              )}
                              <p className="text-xs text-gray-500 truncate">{item.address}</p>
                              {getStatusBadge(item.status)}
                              
                              {/* Route actions */}
                              {activeRoute && (
                                <div className="mt-2 pt-2 border-t space-y-1">
                                  {routeInfo?.isOnRoute && (
                                    <>
                                      <Badge className="bg-green-500 text-white text-xs">
                                        #{routeInfo.sequence} {t("on_route")}
                                      </Badge>
                                      <div className="flex gap-1 mt-1">
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          className="h-6 text-xs"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            openRewardDialog(item);
                                          }}
                                          data-testid={`button-complete-${item.id}`}
                                        >
                                          <Gift className="h-3 w-3 mr-1" />
                                          {t("mark_complete")}
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant="ghost"
                                          className="h-6 text-xs text-red-500"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            removeFromRouteMutation.mutate(item.id);
                                          }}
                                        >
                                          <X className="h-3 w-3" />
                                        </Button>
                                      </div>
                                    </>
                                  )}
                                  {routeInfo?.isOffRoute && (
                                    <>
                                      <Badge className="bg-yellow-500 text-white text-xs">{t("off_route")}</Badge>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="h-6 text-xs mt-1"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          const nextSeq = (activeRoute.items.filter(i => i.routeStatus === "on_route").length || 0) + 1;
                                          addToRouteMutation.mutate({ itemId: item.id, sequence: nextSeq });
                                        }}
                                      >
                                        <Plus className="h-3 w-3 mr-1" />
                                        {t("add_to_route")}
                                      </Button>
                                    </>
                                  )}
                                  {routeInfo?.isWrongCategory && (
                                    <Badge className="bg-red-500 text-white text-xs">{t("wrong_category")}</Badge>
                                  )}
                                  {routeInfo?.isCompleted && (
                                    <Badge className="bg-gray-500 text-white text-xs">{t("status_collected")}</Badge>
                                  )}
                                </div>
                              )}
                            </div>
                          </Popup>
                        </Marker>
                      );
                    })}

                    {/* Report markers */}
                    {allReports.map((report) => (
                      <Marker
                        key={`report-${report.id}`}
                        position={[parseFloat(report.latitude), parseFloat(report.longitude)]}
                        icon={reportIcon}
                        eventHandlers={{
                          click: () => setSelectedReport(report),
                        }}
                      >
                        <Popup>
                          <div className="min-w-[150px]">
                            <strong className="text-red-600">{report.title}</strong>
                            <p className="text-xs text-gray-500 mt-1">{report.description?.slice(0, 50)}...</p>
                            {getStatusBadge(report.status)}
                          </div>
                        </Popup>
                      </Marker>
                    ))}
                  </MapContainer>
                </div>
              </CardContent>
            </Card>

            {/* Pending Items List */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Package className="h-5 w-5 text-blue-600" />
                  {t("pending_pickups")} ({allItems.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[300px] overflow-y-auto">
                  {allItems.length === 0 ? (
                    <p className="text-center text-gray-500 py-4">{t("no_new_items")}</p>
                  ) : (
                    allItems.slice(0, 5).map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                        onClick={() => setSelectedItem(item)}
                        data-testid={`pickup-item-${item.id}`}
                      >
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] + "20" }}
                        >
                          <Package
                            className="h-5 w-5"
                            style={{ color: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] }}
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium">{getCategoryLabel(item.category)}</p>
                          <p className="text-xs text-gray-500 truncate">{item.address}</p>
                        </div>
                        <div className="text-right">
                          {getStatusBadge(item.status)}
                          {item.weightEstimateKg && (
                            <p className="text-xs text-gray-500 mt-1">~{item.weightEstimateKg} kg</p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Pending Reports List */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  {t("reports")} ({allReports.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[300px] overflow-y-auto">
                  {allReports.length === 0 ? (
                    <p className="text-center text-gray-500 py-4">{t("no_new_reports")}</p>
                  ) : (
                    allReports.slice(0, 5).map((report) => (
                      <div
                        key={report.id}
                        className="flex items-start gap-3 p-3 bg-red-50 rounded-lg cursor-pointer hover:bg-red-100 border-l-4 border-red-500"
                        onClick={() => setSelectedReport(report)}
                        data-testid={`report-item-${report.id}`}
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-red-600">{report.title}</p>
                          <p className="text-xs text-gray-500 truncate">{report.address}</p>
                        </div>
                        <div className="text-right">
                          {getStatusBadge(report.status)}
                          <Badge
                            variant={report.severity === "high" ? "destructive" : "secondary"}
                            className="mt-1 text-xs"
                          >
                            {getSeverityLabel(report.severity || "low")}
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "list" && (
          <div className="p-4">
            <Tabs defaultValue="items">
              <TabsList className="w-full mb-4">
                <TabsTrigger value="items" className="flex-1">
                  <Package className="h-4 w-4 mr-2" />
                  {t("item")} ({allItems.length})
                </TabsTrigger>
                <TabsTrigger value="reports" className="flex-1">
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  {t("reports")} ({allReports.length})
                </TabsTrigger>
              </TabsList>
              <TabsContent value="items">
                <div className="space-y-3">
                  {allItems.length === 0 ? (
                    <Card>
                      <CardContent className="py-8 text-center text-gray-500">
                        {t("no_new_items")}
                      </CardContent>
                    </Card>
                  ) : (
                    allItems.map((item) => (
                      <Card
                        key={item.id}
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => {
                          setSelectedItem(item);
                          setActiveTab("map");
                        }}
                        data-testid={`list-item-${item.id}`}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center gap-3">
                            <div
                              className="w-10 h-10 rounded-full flex items-center justify-center"
                              style={{ backgroundColor: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] + "20" }}
                            >
                              <Package
                                className="h-5 w-5"
                                style={{ color: CATEGORY_COLORS[item.category as keyof typeof CATEGORY_COLORS] }}
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium">
                                {getCategoryLabel(item.category)}
                              </p>
                              <p className="text-xs text-gray-500 truncate">{item.address}</p>
                            </div>
                            <div className="text-right">
                              {getStatusBadge(item.status)}
                              {item.weightEstimateKg && (
                                <p className="text-xs text-gray-500 mt-1">~{item.weightEstimateKg} kg</p>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>
              <TabsContent value="reports">
                <div className="space-y-3">
                  {allReports.length === 0 ? (
                    <Card>
                      <CardContent className="py-8 text-center text-gray-500">
                        {t("no_new_reports")}
                      </CardContent>
                    </Card>
                  ) : (
                    allReports.map((report) => (
                      <Card
                        key={report.id}
                        className="cursor-pointer hover:shadow-md transition-shadow border-l-4 border-l-red-500"
                        onClick={() => {
                          setSelectedReport(report);
                          setActiveTab("map");
                        }}
                        data-testid={`list-report-${report.id}`}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-red-600">{report.title}</p>
                              <p className="text-xs text-gray-500 truncate">{report.address}</p>
                              <p className="text-xs text-gray-400 mt-1">
                                {report.createdAt && new Date(report.createdAt).toLocaleDateString("ms-MY")}
                              </p>
                            </div>
                            <div className="text-right">
                              {getStatusBadge(report.status)}
                              <Badge
                                variant={report.severity === "high" ? "destructive" : "secondary"}
                                className="mt-1 text-xs"
                              >
                                {getSeverityLabel(report.severity || "low")}
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {activeTab === "profile" && (
          <div className="p-4 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t("rider_profile")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                    <User className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{user.name}</h3>
                    <p className="text-gray-500">{user.email}</p>
                    <Badge className="mt-1 bg-green-100 text-green-800">{t("ecorider")}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{t("statistics")}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-green-600">{stats?.completedToday || 0}</p>
                    <p className="text-sm text-gray-500">{t("today")}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-green-600">{stats?.totalKgCollected?.toFixed(1) || 0}</p>
                    <p className="text-sm text-gray-500">{t("total_weight")} (kg)</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-blue-600">{myAssignedItems.length}</p>
                    <p className="text-sm text-gray-500">{t("assigned_items")}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-xl text-center">
                    <p className="text-2xl font-bold text-orange-600">{myAssignedReports.length}</p>
                    <p className="text-sm text-gray-500">{t("reports")}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Item Detail Modal */}
      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: CATEGORY_COLORS[selectedItem?.category as keyof typeof CATEGORY_COLORS] }}
              />
              {getCategoryLabel(selectedItem?.category || "")}
            </DialogTitle>
            <DialogDescription>
              {selectedItem?.address || t("address_not_available")}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {selectedItem?.photoUrl && (
              <img
                src={selectedItem.photoUrl}
                alt="Item"
                className="w-full h-40 object-cover rounded-lg"
              />
            )}
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-gray-500">{t("estimated_weight")}</p>
                <p className="font-medium">{selectedItem?.weightEstimateKg || "-"} kg</p>
              </div>
              <div>
                <p className="text-gray-500">{t("status")}</p>
                {selectedItem && getStatusBadge(selectedItem.status)}
              </div>
            </div>
            {selectedItem?.description && (
              <div>
                <p className="text-gray-500 text-sm">{t("description")}</p>
                <p className="text-sm">{selectedItem.description}</p>
              </div>
            )}
            <div className="flex gap-2 pt-2">
              {(selectedItem?.status === "new" || 
                (activeRoute && selectedItem && getItemRouteInfo(selectedItem)?.isWrongCategory)) && (
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => selectedItem && assignItemMutation.mutate(selectedItem.id)}
                  disabled={assignItemMutation.isPending}
                  data-testid="button-assign-item"
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  {t("take_assignment")}
                </Button>
              )}
              {selectedItem?.status === "assigned" && selectedItem.assignedRiderId === user?.id && (
                <Button
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={() => {
                    setCollectionDialogOpen(true);
                    resetCollectionFlow();
                  }}
                  data-testid="button-start-collection"
                >
                  <Scale className="h-4 w-4 mr-2" />
                  {t("start_collection")}
                </Button>
              )}
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  if (selectedItem) {
                    window.open(
                      `https://www.google.com/maps/dir/?api=1&destination=${selectedItem.latitude},${selectedItem.longitude}`,
                      "_blank"
                    );
                  }
                }}
                data-testid="button-navigate"
              >
                <MapPin className="h-4 w-4 mr-2" />
                {t("navigate")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Collection Flow Dialog */}
      <Dialog open={collectionDialogOpen} onOpenChange={setCollectionDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("collection_details")}</DialogTitle>
          </DialogHeader>
          
          {collectionStep === 'weigh' && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium">{t("ble_scale")}</span>
                  <div className={`w-3 h-3 rounded-full ${isScaleConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                </div>
                
                {!isScaleConnected ? (
                  <Button onClick={toggleScaleConnection} className="w-full">
                    {t("connect_scale")}
                  </Button>
                ) : (
                  <>
                    <div className="text-center mb-4">
                      <p className="text-sm text-gray-500">{t("live_weight")}</p>
                      <p className="text-4xl font-bold text-green-600">
                        {scaleWeight !== null ? scaleWeight.toFixed(2) : "0.00"} kg
                      </p>
                    </div>
                    
                    {!isWeighing ? (
                      <Button onClick={startWeighing} className="w-full bg-green-600 hover:bg-green-700">
                        {t("weigh_items")}
                      </Button>
                    ) : (
                      <Button onClick={confirmWeight} className="w-full bg-blue-600 hover:bg-blue-700">
                        {t("confirm_weight")}
                      </Button>
                    )}
                  </>
                )}
              </div>
            </div>
          )}

          {collectionStep === 'photo' && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg text-center">
                <p className="text-sm text-gray-500 mb-2">{t("actual_weight")}</p>
                <p className="text-2xl font-bold text-green-600">{confirmedWeight} kg</p>
              </div>
              
              <div className="p-4 border-2 border-dashed rounded-lg text-center">
                {capturedPhoto ? (
                  <div className="text-green-600">
                    <CheckCircle className="h-12 w-12 mx-auto mb-2" />
                    <p>{t("photo_required")} ✓</p>
                  </div>
                ) : (
                  <Button onClick={simulatePhotoCapture} variant="outline" className="w-full">
                    <Camera className="h-4 w-4 mr-2" />
                    {t("capture_photo")}
                  </Button>
                )}
              </div>
            </div>
          )}

          {collectionStep === 'signature' && (
            <div className="space-y-4">
              <div className="p-4 border-2 border-dashed rounded-lg text-center">
                {customerSignature ? (
                  <div className="text-green-600">
                    <CheckCircle className="h-12 w-12 mx-auto mb-2" />
                    <p>{t("customer_signature")} ✓</p>
                  </div>
                ) : (
                  <Button onClick={simulateSignatureCapture} variant="outline" className="w-full">
                    <PenTool className="h-4 w-4 mr-2" />
                    {t("customer_signature")}
                  </Button>
                )}
              </div>
            </div>
          )}

          {collectionStep === 'complete' && (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg text-center">
                <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-2" />
                <p className="font-medium">{t("complete_collection")}</p>
                <p className="text-sm text-gray-500">{confirmedWeight} kg {getCategoryLabel(selectedItem?.category || "")}</p>
              </div>
              
              <Button 
                onClick={completeCollection} 
                className="w-full bg-green-600 hover:bg-green-700"
                disabled={collectItemMutation.isPending}
              >
                {t("confirm_collected")}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Route Planning Dialog */}
      <Dialog open={routeDialogOpen} onOpenChange={setRouteDialogOpen}>
        <DialogContent className="max-w-md" data-testid="route-planning-dialog">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Route className="h-5 w-5 text-green-600" />
              {t("route_setup")}
            </DialogTitle>
            <DialogDescription>
              {routePlanningLoading ? t("ai_analyzing") : t("select_collection_category")}
            </DialogDescription>
          </DialogHeader>
          
          {routePlanningLoading ? (
            <div className="py-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4" />
              <p className="text-lg font-medium">{t("planning_route")}</p>
              <p className="text-sm text-gray-500 mt-2">{t("ai_analyzing")}</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="riderName">{t("rider_name")}</Label>
                <Input
                  id="riderName"
                  value={routeForm.riderName}
                  onChange={(e) => setRouteForm({...routeForm, riderName: e.target.value})}
                  placeholder={user?.name}
                  data-testid="input-rider-name"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="truckCapacity">{t("truck_capacity")}</Label>
                <Input
                  id="truckCapacity"
                  type="number"
                  value={routeForm.truckCapacityKg}
                  onChange={(e) => setRouteForm({...routeForm, truckCapacityKg: parseInt(e.target.value) || 500})}
                  data-testid="input-truck-capacity"
                />
              </div>
              
              <div className="space-y-2">
                <Label>{t("select_collection_category")}</Label>
                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 border rounded-lg">
                  {CATEGORIES.map((cat) => {
                    const isSelected = routeForm.selectedCategories.includes(cat);
                    const isRestricted = routeForm.selectedCategories.some(
                      selectedCat => CATEGORY_CONSTRAINTS[selectedCat]?.includes(cat)
                    );
                    return (
                      <div
                        key={cat}
                        className={`flex items-center gap-2 p-2 rounded cursor-pointer transition-colors ${
                          isSelected ? "bg-green-100 border border-green-400" : 
                          isRestricted ? "bg-gray-100 opacity-50 cursor-not-allowed" : "hover:bg-gray-50"
                        }`}
                        onClick={() => {
                          if (isRestricted) return;
                          if (isSelected) {
                            setRouteForm({
                              ...routeForm,
                              selectedCategories: routeForm.selectedCategories.filter(c => c !== cat)
                            });
                          } else {
                            setRouteForm({
                              ...routeForm,
                              selectedCategories: [...routeForm.selectedCategories, cat]
                            });
                          }
                        }}
                        data-testid={`category-checkbox-${cat}`}
                      >
                        <Checkbox
                          checked={isSelected}
                          disabled={isRestricted}
                          className={isSelected ? "border-green-600 bg-green-600" : ""}
                        />
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: CATEGORY_COLORS[cat as keyof typeof CATEGORY_COLORS] }}
                        />
                        <span className="text-sm">{t(cat)}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
              
              {routeForm.selectedCategories.length > 0 && (
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">
                    <strong>
                      {allItems.filter(i => routeForm.selectedCategories.includes(i.category) && i.status === "new").length}
                    </strong> {t("pending_pickups")} ({routeForm.selectedCategories.map(c => t(c)).join(", ")})
                  </p>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setRouteDialogOpen(false)}
              disabled={routePlanningLoading}
            >
              {t("status_cancelled")}
            </Button>
            <Button 
              onClick={handleRouteSubmit}
              disabled={routePlanningLoading || routeForm.selectedCategories.length === 0}
              className="bg-green-600 hover:bg-green-700"
              data-testid="button-submit-route"
            >
              <Route className="h-4 w-4 mr-2" />
              {t("start_route")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reward Credit Dialog */}
      <Dialog open={rewardDialogOpen} onOpenChange={setRewardDialogOpen}>
        <DialogContent className="max-w-md" data-testid="reward-credit-dialog">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-green-600" />
              {language === "en" ? "Credit Reward" : "Kreditkan Ganjaran"}
            </DialogTitle>
            <DialogDescription>
              {language === "en" 
                ? "Choose reward type for the citizen" 
                : "Pilih jenis ganjaran untuk rakyat"}
            </DialogDescription>
          </DialogHeader>
          
          {pendingRewardItem && (
            <div className="space-y-4">
              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: CATEGORY_COLORS[pendingRewardItem.category as keyof typeof CATEGORY_COLORS] }}
                  />
                  <span className="font-medium">{t(pendingRewardItem.category)}</span>
                </div>
                <p className="text-sm text-gray-600">{pendingRewardItem.address}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="actualWeight">{language === "en" ? "Actual Weight (kg)" : "Berat Sebenar (kg)"}</Label>
                <Input
                  id="actualWeight"
                  type="number"
                  step="0.1"
                  value={actualWeight}
                  onChange={(e) => setActualWeight(e.target.value)}
                  placeholder={pendingRewardItem.weightEstimateKg?.toString()}
                  data-testid="input-actual-weight"
                />
              </div>

              <div className="space-y-2">
                <Label>{language === "en" ? "Reward Type" : "Jenis Ganjaran"}</Label>
                <RadioGroup value={rewardType} onValueChange={(v) => setRewardType(v as "points" | "cashback")}>
                  <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <RadioGroupItem value="points" id="points" data-testid="radio-points" />
                    <Label htmlFor="points" className="flex items-center gap-2 cursor-pointer flex-1">
                      <Coins className="h-5 w-5 text-yellow-500" />
                      <div>
                        <p className="font-medium">{language === "en" ? "Points" : "Mata"}</p>
                        <p className="text-xs text-gray-500">
                          {REWARD_RATES[pendingRewardItem.category]?.pointsPerKg || 30} {language === "en" ? "pts/kg" : "mata/kg"}
                        </p>
                      </div>
                    </Label>
                    {actualWeight && (
                      <span className="text-green-600 font-bold">
                        +{Math.round(parseFloat(actualWeight) * (REWARD_RATES[pendingRewardItem.category]?.pointsPerKg || 30))}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                    <RadioGroupItem value="cashback" id="cashback" data-testid="radio-cashback" />
                    <Label htmlFor="cashback" className="flex items-center gap-2 cursor-pointer flex-1">
                      <Wallet className="h-5 w-5 text-green-500" />
                      <div>
                        <p className="font-medium">{language === "en" ? "Cashback" : "Pulangan Tunai"}</p>
                        <p className="text-xs text-gray-500">
                          RM{REWARD_RATES[pendingRewardItem.category]?.cashbackPerKg || 0.20}/kg
                        </p>
                      </div>
                    </Label>
                    {actualWeight && (
                      <span className="text-green-600 font-bold">
                        +RM{(parseFloat(actualWeight) * (REWARD_RATES[pendingRewardItem.category]?.cashbackPerKg || 0.20)).toFixed(2)}
                      </span>
                    )}
                  </div>
                </RadioGroup>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setRewardDialogOpen(false)}
              disabled={creditRewardMutation.isPending || completeRouteItemMutation.isPending}
            >
              {t("status_cancelled")}
            </Button>
            <Button 
              onClick={handleCompleteWithReward}
              disabled={creditRewardMutation.isPending || completeRouteItemMutation.isPending || !actualWeight}
              className="bg-green-600 hover:bg-green-700"
              data-testid="button-confirm-reward"
            >
              {(creditRewardMutation.isPending || completeRouteItemMutation.isPending) ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              ) : (
                <CheckCircle className="h-4 w-4 mr-2" />
              )}
              {language === "en" ? "Credit & Complete" : "Kredit & Selesai"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Report Detail Modal */}
      <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              {selectedReport?.title}
            </DialogTitle>
            <DialogDescription>
              {selectedReport?.address || t("address_not_available")}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {selectedReport?.photoUrl && (
              <img
                src={selectedReport.photoUrl}
                alt="Report"
                className="w-full h-40 object-cover rounded-lg"
              />
            )}
            <div>
              <p className="text-gray-500 text-sm">{t("description")}</p>
              <p className="text-sm">{selectedReport?.description}</p>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">{t("severity")}</p>
                <Badge variant={selectedReport?.severity === "high" ? "destructive" : "secondary"}>
                  {getSeverityLabel(selectedReport?.severity || "low")}
                </Badge>
              </div>
              <div>
                <p className="text-gray-500 text-sm">{t("status")}</p>
                {selectedReport && getStatusBadge(selectedReport.status)}
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              {selectedReport?.status === "new" && (
                <Button
                  className="flex-1 bg-orange-600 hover:bg-orange-700"
                  onClick={() => selectedReport && assignReportMutation.mutate(selectedReport.id)}
                  disabled={assignReportMutation.isPending}
                  data-testid="button-assign-report"
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  {t("take_assignment")}
                </Button>
              )}
              {selectedReport?.status === "assigned" && selectedReport.assignedRiderId === user?.id && (
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => selectedReport && resolveReportMutation.mutate(selectedReport.id)}
                  disabled={resolveReportMutation.isPending}
                  data-testid="button-resolve-report"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  {t("resolve")}
                </Button>
              )}
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  if (selectedReport) {
                    window.open(
                      `https://www.google.com/maps/dir/?api=1&destination=${selectedReport.latitude},${selectedReport.longitude}`,
                      "_blank"
                    );
                  }
                }}
              >
                <MapPin className="h-4 w-4 mr-2" />
                {t("navigate")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* AI Assistant FAB */}
      <Dialog open={aiChatOpen} onOpenChange={setAiChatOpen}>
        <DialogTrigger asChild>
          <Button
            className="fixed bottom-24 right-4 h-14 w-14 rounded-full bg-purple-600 hover:bg-purple-700 shadow-lg z-[1000]"
            data-testid="button-ai-assistant"
          >
            <Bot className="h-6 w-6" />
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md h-[60vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-purple-600" />
              {t("ai_rider_assistant")}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-4">
              {aiConversation.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Bot className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>{t("ask_for_help")}</p>
                  <p className="text-xs mt-1">{t("example_ewaste")}</p>
                </div>
              )}
              {aiConversation.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2 ${
                      msg.role === "user"
                        ? "bg-purple-600 text-white"
                        : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  </div>
                </div>
              ))}
              {aiLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 rounded-2xl px-4 py-2">
                    <p className="text-sm text-gray-500">{t("ai_thinking")}</p>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          <div className="flex gap-2 pt-4 border-t">
            <Input
              placeholder={t("type_your_question")}
              value={aiMessage}
              onChange={(e) => setAiMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAiChat()}
              disabled={aiLoading}
              data-testid="input-ai-message"
            />
            <Button
              onClick={handleAiChat}
              disabled={aiLoading || !aiMessage.trim()}
              className="bg-purple-600 hover:bg-purple-700"
              data-testid="button-send-ai"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-10">
        <div className="flex justify-around py-2">
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "map" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("map")}
            data-testid="nav-map"
          >
            <Map className="h-5 w-5" />
            <span className="text-xs">{t("map")}</span>
          </Button>
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "list" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("list")}
            data-testid="nav-list"
          >
            <List className="h-5 w-5" />
            <span className="text-xs">{t("list")}</span>
          </Button>
          <Button
            variant="ghost"
            className={`flex-col h-14 ${activeTab === "profile" ? "text-green-600" : "text-gray-400"}`}
            onClick={() => setActiveTab("profile")}
            data-testid="nav-profile"
          >
            <User className="h-5 w-5" />
            <span className="text-xs">{t("profile")}</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
