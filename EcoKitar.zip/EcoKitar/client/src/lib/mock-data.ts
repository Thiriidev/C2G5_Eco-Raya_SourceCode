export const mockCollectionTrends = [
  { day: "Mon", kg: 1200, revenue: 2400 },
  { day: "Tue", kg: 1350, revenue: 2700 },
  { day: "Wed", kg: 1100, revenue: 2200 },
  { day: "Thu", kg: 1450, revenue: 2900 },
  { day: "Fri", kg: 1600, revenue: 3200 },
  { day: "Sat", kg: 1800, revenue: 3600 },
  { day: "Sun", kg: 1300, revenue: 2600 },
];

export const mockTopPartners = [
  { id: 1, name: "AUCO Sdn Bhd", volume: "8,945 kg", growth: "+24%" },
  { id: 2, name: "Arus Oil Trading", volume: "7,234 kg", growth: "+18%" },
  { id: 3, name: "GreenTech Solutions", volume: "6,187 kg", growth: "+12%" },
  { id: 4, name: "EcoWaste Management", volume: "5,432 kg", growth: "+8%" },
  { id: 5, name: "Sustainable Oil Co", volume: "4,876 kg", growth: "+15%" },
];

export const mockRecentCollections = [
  {
    id: "COL-24567",
    station: "Klang Valley Hub",
    collector: "Siti Ahmad",
    volume: 45.2,
    payout: "RM 22.60",
    status: "verified",
    date: "2024-03-15 14:32",
  },
  {
    id: "COL-24566",
    station: "Subang Collection Point",
    collector: "Rahman Ibrahim",
    volume: 78.9,
    payout: "RM 39.45",
    status: "under_review",
    date: "2024-03-15 13:18",
  },
  {
    id: "COL-24565",
    station: "Shah Alam Terminal",
    collector: "Farid Hassan",
    volume: 32.7,
    payout: "RM 16.35",
    status: "verified",
    date: "2024-03-15 12:45",
  },
  {
    id: "COL-24564",
    station: "Petaling Jaya Hub",
    collector: "Aminah Binti Ali",
    volume: 56.8,
    payout: "RM 28.40",
    status: "verified",
    date: "2024-03-15 11:22",
  },
  {
    id: "COL-24563",
    station: "Klang Valley Hub",
    collector: "Ahmad Razak",
    volume: 91.3,
    payout: "RM 45.65",
    status: "flagged",
    date: "2024-03-15 10:15",
  },
];

export const mockDashboardMetrics = {
  totalOil: 24567,
  householdsServed: 8423,
  co2Saved: 73.7,
  revenue: 186420,
  growthRates: {
    oil: 12.5,
    households: 8.2,
    co2: 15.3,
    revenue: 15.8,
  },
};
