import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type Language = "en" | "ms";

interface Translations {
  [key: string]: {
    en: string;
    ms: string;
  };
}

const translations: Translations = {
  welcome: { en: "Welcome", ms: "Selamat datang" },
  logout: { en: "Logout", ms: "Log Keluar" },
  items: { en: "Items", ms: "Item" },
  kg_recycled: { en: "kg Recycled", ms: "kg Dikitar" },
  kg_co2: { en: "kg CO₂", ms: "kg CO₂" },
  quick_actions: { en: "Quick Actions", ms: "Aksi Pantas" },
  submit_item: { en: "Submit Item", ms: "Hantar Item" },
  report_issue: { en: "Report Issue", ms: "Lapor Isu" },
  submit_recyclable: { en: "Submit Recyclable Item", ms: "Hantar Item Kitar Semula" },
  location_required_collection: { en: "Your location is required for collection", ms: "Lokasi anda diperlukan untuk kutipan" },
  enable_location: { en: "Enable Location", ms: "Aktifkan Lokasi" },
  getting_location: { en: "Getting location...", ms: "Mendapatkan lokasi..." },
  location_obtained: { en: "Location Obtained", ms: "Lokasi Diperoleh" },
  location_error: { en: "Failed to get location. Please enable GPS.", ms: "Gagal mendapatkan lokasi. Sila aktifkan GPS." },
  location_not_supported: { en: "Location not supported by your browser", ms: "Lokasi tidak disokong oleh pelayar anda" },
  take_photo: { en: "Take Photo", ms: "Ambil Gambar" },
  change_photo: { en: "Change Photo", ms: "Tukar Gambar" },
  category: { en: "Category", ms: "Kategori" },
  select_category: { en: "Select category", ms: "Pilih kategori" },
  weight_estimate: { en: "Weight Estimate (kg)", ms: "Anggaran Berat (kg)" },
  description: { en: "Description (optional)", ms: "Keterangan (pilihan)" },
  submit: { en: "Submit", ms: "Hantar" },
  submitting: { en: "Submitting...", ms: "Menghantar..." },
  success: { en: "Success!", ms: "Berjaya!" },
  item_submitted: { en: "Your recyclable item has been submitted. EcoRider will come to collect.", ms: "Item kitar semula anda telah dihantar. EcoRider akan datang mengutip." },
  error: { en: "Error", ms: "Ralat" },
  failed_submit_item: { en: "Failed to submit item. Please try again.", ms: "Gagal menghantar item. Sila cuba lagi." },
  location_required: { en: "Location Required", ms: "Lokasi Diperlukan" },
  enable_location_first: { en: "Please enable your location first", ms: "Sila aktifkan lokasi anda terlebih dahulu" },
  category_required: { en: "Category Required", ms: "Kategori Diperlukan" },
  select_recycling_category: { en: "Please select a recycling category", ms: "Sila pilih kategori kitar semula" },
  report_illegal_dumping: { en: "Report Issue / Illegal Dumping", ms: "Lapor Isu / Pembuangan Haram" },
  help_clean_area: { en: "Help us keep your area clean", ms: "Bantu kami menjaga kebersihan kawasan anda" },
  title: { en: "Title", ms: "Tajuk" },
  severity: { en: "Severity", ms: "Keterukan" },
  low: { en: "Low", ms: "Rendah" },
  medium: { en: "Medium", ms: "Sederhana" },
  high: { en: "High", ms: "Tinggi" },
  report_submitted: { en: "Report Submitted", ms: "Laporan Dihantar" },
  thank_you_report: { en: "Thank you! Jabatan will review your report.", ms: "Terima kasih! Jabatan akan menyemak laporan anda." },
  failed_submit_report: { en: "Failed to submit report. Please try again.", ms: "Gagal menghantar laporan. Sila cuba lagi." },
  title_required: { en: "Title Required", ms: "Tajuk Diperlukan" },
  enter_report_title: { en: "Please enter a report title", ms: "Sila masukkan tajuk laporan" },
  home: { en: "Home", ms: "Utama" },
  add: { en: "Add", ms: "Tambah" },
  history: { en: "History", ms: "Sejarah" },
  profile: { en: "Profile", ms: "Profil" },
  ai_chat: { en: "AI Chat", ms: "AI Chat" },
  recycling_coach: { en: "Recycling Coach", ms: "Jurulatih Kitar Semula" },
  ask_recycling: { en: "Ask anything about recycling...", ms: "Tanya apa sahaja tentang kitar semula..." },
  send: { en: "Send", ms: "Hantar" },
  my_items: { en: "My Items", ms: "Item Saya" },
  my_reports: { en: "My Reports", ms: "Laporan Saya" },
  no_items_yet: { en: "No items submitted yet", ms: "Tiada item dihantar lagi" },
  no_reports_yet: { en: "No reports submitted yet", ms: "Tiada laporan dihantar lagi" },
  status_new: { en: "New", ms: "Baru" },
  status_assigned: { en: "Assigned", ms: "Ditugaskan" },
  status_in_progress: { en: "In Progress", ms: "Dalam Proses" },
  status_collected: { en: "Collected", ms: "Dikutip" },
  status_resolved: { en: "Resolved", ms: "Selesai" },
  status_cancelled: { en: "Cancelled", ms: "Dibatalkan" },
  plastic: { en: "Plastic", ms: "Plastik" },
  paper: { en: "Paper", ms: "Kertas" },
  glass: { en: "Glass", ms: "Kaca" },
  metal: { en: "Metal", ms: "Logam" },
  ewaste: { en: "E-Waste", ms: "E-Sisa" },
  batteries: { en: "Batteries", ms: "Bateri" },
  cooking_oil: { en: "Cooking Oil", ms: "Minyak Masak" },
  textiles: { en: "Textiles", ms: "Tekstil" },
  appliances: { en: "Appliances", ms: "Peralatan" },
  organic: { en: "Organic", ms: "Organik" },
  special_waste: { en: "Special Waste", ms: "Sisa Khas" },
  map: { en: "Map", ms: "Peta" },
  assignments: { en: "Assignments", ms: "Tugasan" },
  pending_pickups: { en: "Pending Pickups", ms: "Kutipan Tertangguh" },
  pending_collections: { en: "Pending Collections", ms: "Kutipan Tertangguh" },
  completed_today: { en: "Completed Today", ms: "Selesai Hari Ini" },
  total_collected: { en: "Total Collected", ms: "Jumlah Dikutip" },
  optimize_route: { en: "Optimize Route", ms: "Optimumkan Laluan" },
  assign_to_me: { en: "Assign to Me", ms: "Tugaskan kepada Saya" },
  mark_collected: { en: "Mark Collected", ms: "Tandakan Dikutip" },
  mark_resolved: { en: "Mark Resolved", ms: "Tandakan Selesai" },
  item_assigned: { en: "Item assigned to you", ms: "Item ditugaskan kepada anda" },
  item_collected: { en: "Item successfully collected!", ms: "Item berjaya dikutip!" },
  report_assigned: { en: "Report assigned to you", ms: "Laporan ditugaskan kepada anda" },
  report_resolved: { en: "Report marked as resolved", ms: "Laporan ditandakan selesai" },
  dashboard: { en: "Dashboard", ms: "Papan Pemuka" },
  analytics: { en: "Analytics", ms: "Analitik" },
  collections: { en: "Collections", ms: "Kutipan" },
  reports: { en: "Reports", ms: "Laporan" },
  partners: { en: "Partners", ms: "Rakan Kongsi" },
  devices: { en: "Devices", ms: "Peranti" },
  esg: { en: "ESG", ms: "ESG" },
  settings: { en: "Settings", ms: "Tetapan" },
  total_oil_collected: { en: "Total Oil Collected", ms: "Jumlah Minyak Dikutip" },
  households_served: { en: "Households Served", ms: "Isi Rumah Dilayan" },
  co2_saved: { en: "CO₂ Saved", ms: "CO₂ Dijimatkan" },
  petrol_consumed: { en: "Petrol Used", ms: "Petrol Digunakan" },
  petrol_saved: { en: "Petrol Saved", ms: "Petrol Dijimatkan" },
  liters: { en: "L", ms: "L" },
  kg: { en: "kg", ms: "kg" },
  revenue_generated: { en: "Revenue Generated", ms: "Hasil Dijana" },
  language: { en: "Language", ms: "Bahasa" },
  english: { en: "English", ms: "Bahasa Inggeris" },
  malay: { en: "Malay", ms: "Bahasa Melayu" },
  
  // AI Chat translations
  ai_recycling_coach: { en: "AI Recycling Coach", ms: "Jurulatih Kitar Semula AI" },
  ask_me_recycling: { en: "Ask me about recycling!", ms: "Tanya saya tentang kitar semula!" },
  example_question: { en: "Example: \"How do I recycle plastic bottles?\"", ms: "Contoh: \"Bagaimana nak kitar semula botol plastik?\"" },
  ai_thinking: { en: "Thinking...", ms: "Sedang berfikir..." },
  ai_analyzing_item: { en: "Analyzing your item...", ms: "Menganalisis item anda..." },
  type_your_question: { en: "Type your question...", ms: "Taip soalan anda..." },
  snap_to_recycle: { en: "Snap a photo to learn how to recycle!", ms: "Ambil gambar untuk tahu cara kitar semula!" },
  take_photo_or_ask: { en: "Take a photo of any item or ask a question", ms: "Ambil gambar mana-mana item atau tanya soalan" },
  describe_item: { en: "Add details about the item...", ms: "Tambah butiran tentang item..." },
  new_conversation: { en: "Start new conversation", ms: "Mulakan perbualan baru" },
  
  // Additional UI translations
  area: { en: "Area", ms: "Kawasan" },
  describe_issue: { en: "Describe the issue you found...", ms: "Huraikan isu yang anda temui..." },
  example_weight: { en: "Example: 2.5", ms: "Contoh: 2.5" },
  example_description: { en: "Example: 10 PET plastic bottles", ms: "Contoh: 10 botol plastik PET" },
  start: { en: "Start", ms: "Mula" },
  stop: { en: "Stop", ms: "Henti" },
  total_items: { en: "Total Items", ms: "Jumlah Item" },
  total_weight: { en: "Total Weight", ms: "Jumlah Berat" },
  co2_saved_short: { en: "kg CO₂ Saved", ms: "kg CO₂ Dijimatkan" },
  view_details: { en: "View Details", ms: "Lihat Butiran" },
  address_not_available: { en: "Address not available", ms: "Alamat tidak tersedia" },
  weight: { en: "Weight", ms: "Berat" },
  status: { en: "Status", ms: "Status" },
  date: { en: "Date", ms: "Tarikh" },
  assigned_to: { en: "Assigned to", ms: "Ditugaskan kepada" },
  not_assigned: { en: "Not assigned yet", ms: "Belum ditugaskan" },
  contact_collected: { en: "Contact when collected", ms: "Hubungi apabila dikutip" },
  navigate: { en: "Navigate", ms: "Navigasi" },
  rider_profile: { en: "EcoRider Profile", ms: "Profil EcoRider" },
  statistics: { en: "Statistics", ms: "Statistik" },
  collections_completed: { en: "Collections Completed", ms: "Kutipan Selesai" },
  average_per_day: { en: "Avg per Day", ms: "Purata Sehari" },
  ai_rider_assistant: { en: "AI Rider Assistant", ms: "Pembantu AI Rider" },
  ask_for_help: { en: "Ask me for help!", ms: "Tanya saya untuk bantuan!" },
  example_ewaste: { en: "Example: \"How to handle e-waste properly?\"", ms: "Contoh: \"Bagaimana nak kemas sampah e-sisa?\"" },
  location_error_title: { en: "Location Error", ms: "Ralat Lokasi" },
  enable_gps: { en: "Please enable your location/GPS", ms: "Sila aktifkan lokasi/GPS anda" },
  address: { en: "Address", ms: "Alamat" },
  photo_required: { en: "Photo", ms: "Gambar" },
  
  // EcoRider specific translations
  ecorider: { en: "EcoRider", ms: "EcoRider" },
  your_location: { en: "Your Location", ms: "Lokasi Anda" },
  tracking_location: { en: "Tracking location...", ms: "Mengesan lokasi..." },
  press_start_track: { en: "Press 'Start' to track location", ms: "Tekan 'Mula' untuk kesan lokasi" },
  pickups: { en: "pickups", ms: "kutipan" },
  today: { en: "today", ms: "hari ini" },
  take_assignment: { en: "Take Assignment", ms: "Ambil Tugasan" },
  mark_as_collected: { en: "Mark as Collected", ms: "Tandakan Dikutip" },
  resolve: { en: "Resolve", ms: "Selesaikan" },
  no_new_items: { en: "No new collection items", ms: "Tiada item kutipan baru" },
  no_new_reports: { en: "No new reports", ms: "Tiada laporan baru" },
  item: { en: "Item", ms: "Item" },
  assigned_items: { en: "Assigned Items", ms: "Item Ditugaskan" },
  list: { en: "List", ms: "Senarai" },
  estimated_weight: { en: "Estimated Weight", ms: "Anggaran Berat" },
  
  // BLE Scale translations
  ble_scale: { en: "BLE Scale", ms: "Skala BLE" },
  live_weight: { en: "Live Weight", ms: "Berat Langsung" },
  scale_connected: { en: "Scale Connected", ms: "Skala Disambungkan" },
  scale_disconnected: { en: "Scale Disconnected", ms: "Skala Terputus" },
  connect_scale: { en: "Connect Scale", ms: "Sambung Skala" },
  disconnect_scale: { en: "Disconnect Scale", ms: "Putuskan Skala" },
  weighing: { en: "Weighing...", ms: "Menimbang..." },
  confirm_weight: { en: "Confirm Weight", ms: "Sahkan Berat" },
  actual_weight: { en: "Actual Weight", ms: "Berat Sebenar" },
  
  // Collection flow translations
  collection_details: { en: "Collection Details", ms: "Butiran Kutipan" },
  start_collection: { en: "Start Collection", ms: "Mula Kutipan" },
  complete_collection: { en: "Complete Collection", ms: "Selesai Kutipan" },
  weigh_items: { en: "Weigh Items", ms: "Timbang Item" },
  confirm_collected: { en: "Confirm Collected", ms: "Sahkan Dikutip" },
  capture_photo: { en: "Capture Photo", ms: "Ambil Gambar" },
  customer_signature: { en: "Customer Signature", ms: "Tandatangan Pelanggan" },
  generate_receipt: { en: "Generate Receipt", ms: "Jana Resit" },
  
  // Online status
  online: { en: "Online", ms: "Dalam Talian" },
  offline: { en: "Offline", ms: "Luar Talian" },
  
  // Route optimization  
  optimized_route: { en: "Optimized Route", ms: "Laluan Optimum" },
  route_calculated: { en: "Route calculated for optimal pickup", ms: "Laluan dikira untuk kutipan optimum" },
  get_directions: { en: "Get Directions", ms: "Dapatkan Arah" },
  
  // AI Route Planning
  start_route: { en: "Start Route", ms: "Mula Laluan" },
  end_route: { en: "End Route", ms: "Tamat Laluan" },
  route_setup: { en: "Route Setup", ms: "Tetapan Laluan" },
  rider_name: { en: "Rider Name", ms: "Nama Pemandu" },
  truck_capacity: { en: "Truck Capacity (kg)", ms: "Kapasiti Trak (kg)" },
  select_collection_category: { en: "Select Collection Category", ms: "Pilih Kategori Kutipan" },
  category_restrictions: { en: "Category Restrictions", ms: "Sekatan Kategori" },
  cannot_mix_with: { en: "Cannot mix with", ms: "Tidak boleh dicampur dengan" },
  planning_route: { en: "Planning Route...", ms: "Merancang Laluan..." },
  ai_analyzing: { en: "AI is analyzing optimal route", ms: "AI sedang menganalisis laluan optimum" },
  route_active: { en: "Route Active", ms: "Laluan Aktif" },
  stops_remaining: { en: "stops remaining", ms: "perhentian berbaki" },
  total_distance: { en: "Total Distance", ms: "Jumlah Jarak" },
  estimated_time: { en: "Estimated Time", ms: "Anggaran Masa" },
  minutes: { en: "minutes", ms: "minit" },
  on_route: { en: "On Route", ms: "Dalam Laluan" },
  off_route: { en: "Off Route", ms: "Luar Laluan" },
  wrong_category: { en: "Wrong Category", ms: "Kategori Salah" },
  add_to_route: { en: "Add to Route", ms: "Tambah ke Laluan" },
  remove_from_route: { en: "Remove from Route", ms: "Keluarkan dari Laluan" },
  mark_complete: { en: "Mark Complete", ms: "Tandakan Selesai" },
  next_stop: { en: "Next Stop", ms: "Perhentian Seterusnya" },
  route_summary: { en: "Route Summary", ms: "Ringkasan Laluan" },
  ai_route_summary: { en: "AI Route Summary", ms: "Ringkasan Laluan AI" },
  no_active_route: { en: "No active route", ms: "Tiada laluan aktif" },
  click_start_route: { en: "Click 'Start' to plan a collection route", ms: "Klik 'Mula' untuk merancang laluan kutipan" },
  route_optimization_failed: { en: "Route optimization failed", ms: "Pengoptimuman laluan gagal" },
  route_started: { en: "Route Started", ms: "Laluan Bermula" },
  route_ended: { en: "Route Ended", ms: "Laluan Tamat" },
  location_completed: { en: "Location marked as completed", ms: "Lokasi ditandakan selesai" },
  location_removed: { en: "Location removed from route", ms: "Lokasi dikeluarkan dari laluan" },
  location_added: { en: "Location added to route", ms: "Lokasi ditambah ke laluan" },
  km: { en: "km", ms: "km" },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem("ecokitar_language");
    return (saved as Language) || "ms";
  });

  useEffect(() => {
    localStorage.setItem("ecokitar_language", language);
  }, [language]);

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) {
      console.warn(`Missing translation for key: ${key}`);
      return key;
    }
    return translation[language];
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
