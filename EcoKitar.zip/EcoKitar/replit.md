# EcoKitar Recycling Platform

## Overview

EcoKitar is a comprehensive recycling platform with three user roles: Jabatan (government oversight), EcoRider (collection staff with AI-powered route optimization), and EcoRakyat (citizens submitting recyclables). The platform integrates Gemini AI for intelligent route planning, chat features, HuggingFace for image classification, and Leaflet.js + OpenStreetMap for interactive maps with color-coded route visualization.

## User Preferences

Preferred communication style: Simple, everyday language.
Preferred language: Malay (default), with English translations available.

## User Roles

1. **Jabatan** - Government oversight, analytics dashboard, ESG metrics
2. **EcoRider** - Collection staff with AI-powered route optimization
3. **EcoRakyat** - Citizens submitting recyclable items and reports

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with EcoKitar green theme
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Forms**: React Hook Form with Zod validation
- **Maps**: Leaflet.js + OpenStreetMap for interactive maps

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM (fully integrated with DatabaseStorage)
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Pattern**: RESTful API endpoints
- **Session Management**: Express sessions with PostgreSQL store
- **AI Integration**: Google Gemini AI for route optimization and chat

### Authentication & Authorization
- **Authentication**: Username/password based with role-based access control (RBAC)
- **Roles**: jabatan, ecorider, ecorakyat, admin
- **Session Storage**: Server-side sessions with connect-pg-simple

## Key Features

### AI-Powered Route Optimization
- **Gemini AI Integration**: Intelligent route planning based on recycling categories and truck constraints
- **Category-Based Routing**: Routes optimized for specific material types (plastic, paper, glass, etc.)
- **Safety Constraints**: Prevents mixing incompatible materials (e.g., batteries with organic waste)
- **Visual Pin System**:
  - Green numbered pins (1, 2, 3...): On-route items in collection order
  - Yellow pins: Same category items but off-route (can be added)
  - Red pins: Wrong category items (cannot be collected on this route)
  - Gray pins: Completed items
- **Route Polyline**: Visual path connecting all waypoints in order

### EcoRider Dashboard
- Real-time location tracking with Start/Stop controls
- BLE scale integration for weighing recyclables
- AI chat assistant for recycling guidance
- Pending pickups list with status badges
- Report handling (illegal dumping, issues)
- Route planning dialog with:
  - Rider name input
  - Truck capacity setting (kg)
  - Category selection
  - Category restriction warnings
  - AI-generated route summary

### EcoRakyat Dashboard
- Submit recyclable items with photo, location, and category
- Report illegal dumping or issues
- Track submission history
- View personal statistics
- AI recycling coach chat
- **Rewards tab**: View points balance, cashback balance, redeem vouchers
- Transaction history for all reward activities

### Jabatan Dashboard
- Analytics overview with KPIs
- Collection metrics and trends
- ESG metrics tracking
- Partner management
- Device monitoring

## Database Schema

### Core Tables
- **users**: Authentication and role management (includes totalPoints, totalCashback, lifetimePoints, lifetimeCashback)
- **recyclable_items**: Submitted recyclables with location, category, status (includes pointsEarned, cashbackEarned, rewardType, rewardCredited)
- **reports**: Issue/illegal dumping reports
- **route_plans**: AI-optimized collection routes
- **route_events**: Individual stops in a route
- **partners**: Collection partners
- **stations**: Collection points
- **devices**: BLE scales and IoT equipment
- **vouchers**: Reward vouchers (pointsCost, discountValue, partnerName)
- **user_vouchers**: Redeemed vouchers per user with codes and status
- **reward_transactions**: Transaction history for points/cashback earned/spent

### Route Planning Fields
- **recyclable_items**: routeStatus (on_route, off_route, wrong_category, completed), routePlanId, routeSequence
- **route_plans**: selectedCategory, restrictedCategories, truckCapacityKg, waypoints, aiSummary, totalDistanceKm, estimatedDurationMin
- **optimizationMeta** (JSON): Contains fuel/CO2 metrics:
  - petrolConsumedL: Liters of petrol consumed for the route
  - petrolSavedL: Liters saved vs unoptimized baseline
  - co2SavedKg: kg CO2 emissions saved
  - baselineDistanceKm: Estimated unoptimized route distance

### Route Distance Calculation
- **Haversine Formula**: Accurate straight-line distance with 1.3x road factor multiplier
- **Fuel Consumption**: 13 L/100km benchmark for Malaysian medium-duty trucks
- **CO2 Factor**: 2.31 kg CO2 per liter of petrol (IPCC standard)
- **Duration**: 30 km/h avg speed + 15 minutes per collection stop
- **Fallback**: Same calculations used when AI optimization fails

## API Endpoints

### Route Optimization
- `POST /api/routes/optimize` - Create optimized route with AI
- `GET /api/routes/active` - Get rider's active route
- `PATCH /api/routes/:planId/items/:itemId/complete` - Mark item collected
- `PATCH /api/routes/:planId/items/:itemId/remove` - Remove from route
- `PATCH /api/routes/:planId/items/:itemId/add` - Add to route
- `PATCH /api/routes/:planId/end` - End route

### AI Endpoints
- `POST /api/ai/chat` - AI chat for recycling guidance
- `POST /api/ai/classify-image` - HuggingFace image classification
- `POST /api/ai/optimize-route` - Basic route optimization

### Rewards Endpoints
- `GET /api/rewards/summary` - Get user's points and cashback balances
- `GET /api/rewards/transactions` - Get user's reward transaction history
- `GET /api/rewards/rates` - Get points/cashback rates per category
- `POST /api/rewards/credit` - Credit rewards when item is collected (EcoRider only)
- `GET /api/vouchers` - Get available vouchers
- `GET /api/vouchers/my` - Get user's redeemed vouchers
- `POST /api/vouchers/:id/redeem` - Redeem a voucher with points

## Category System

### Available Categories
plastic, paper, glass, metal, ewaste, batteries, cooking_oil, textiles, appliances, organic, special_waste

### Category Constraints (Cannot Mix)
- batteries: ewaste, organic
- ewaste: batteries, organic
- cooking_oil: paper, organic
- organic: batteries, ewaste, cooking_oil, special_waste
- special_waste: organic

## Internationalization

- Default language: Malay (ms)
- Supported: English (en), Malay (ms)
- Language toggle in header
- All UI text localized

## Development

### Test Credentials
- EcoRider: rider1 / rider123
- EcoRakyat: user1 / user123

### Environment Variables
- DATABASE_URL: PostgreSQL connection string
- GOOGLE_API_KEY: Gemini AI API key
- HUGGINGFACE_API_KEY: Image classification API key

### Commands
- `npm run dev`: Development server with hot reload
- `npm run build`: Production build
- `npm run db:push`: Database schema deployment
