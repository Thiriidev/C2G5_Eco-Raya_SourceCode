import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Category colors for recyclables (matching brand guidelines)
export const CATEGORY_COLORS = {
  plastic: "#4DA6FF",
  paper: "#9E8BFF",
  glass: "#4BC7A9",
  metal: "#8A8A8A",
  ewaste: "#5BDB6F",
  batteries: "#FFDD57",
  cooking_oil: "#FF9F45",
  textiles: "#FF7BA5",
  appliances: "#264C8C",
  organic: "#B47C4D",
  special_waste: "#FF6666",
} as const;

export const CATEGORIES = Object.keys(CATEGORY_COLORS) as Array<keyof typeof CATEGORY_COLORS>;

// User roles: jabatan (admin), ecorider (collector), ecorakyat (citizen)
export const USER_ROLES = ["jabatan", "ecorider", "ecorakyat"] as const;

// Item/report status lifecycle
export const ITEM_STATUS = ["new", "assigned", "in_progress", "collected", "cancelled"] as const;
export const REPORT_STATUS = ["new", "assigned", "in_progress", "resolved", "cancelled"] as const;

// Route status for visual pin colors
export const ROUTE_PIN_STATUS = ["on_route", "off_route", "wrong_category", "completed"] as const;

// Category constraints - what can't be mixed together for safety
export const CATEGORY_CONSTRAINTS: Record<string, string[]> = {
  ewaste: ["organic", "cooking_oil", "batteries"],
  batteries: ["organic", "cooking_oil", "ewaste"],
  cooking_oil: ["ewaste", "batteries", "paper"],
  organic: ["ewaste", "batteries", "special_waste"],
  special_waste: ["organic", "paper", "textiles"],
} as const;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  role: text("role").notNull(), // 'jabatan', 'ecorider', 'ecorakyat'
  partnerId: integer("partner_id"),
  avatarUrl: text("avatar_url"),
  totalPoints: integer("total_points").default(0),
  totalCashback: decimal("total_cashback", { precision: 10, scale: 2 }).default("0"),
  lifetimePoints: integer("lifetime_points").default(0),
  lifetimeCashback: decimal("lifetime_cashback", { precision: 10, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Point and cashback rates per category per kg
export const REWARD_RATES: Record<string, { pointsPerKg: number; cashbackPerKg: number }> = {
  plastic: { pointsPerKg: 50, cashbackPerKg: 0.30 },
  paper: { pointsPerKg: 30, cashbackPerKg: 0.15 },
  glass: { pointsPerKg: 40, cashbackPerKg: 0.20 },
  metal: { pointsPerKg: 80, cashbackPerKg: 0.50 },
  ewaste: { pointsPerKg: 150, cashbackPerKg: 1.00 },
  batteries: { pointsPerKg: 200, cashbackPerKg: 1.50 },
  cooking_oil: { pointsPerKg: 60, cashbackPerKg: 0.40 },
  textiles: { pointsPerKg: 40, cashbackPerKg: 0.25 },
  appliances: { pointsPerKg: 100, cashbackPerKg: 0.80 },
  organic: { pointsPerKg: 20, cashbackPerKg: 0.10 },
  special_waste: { pointsPerKg: 100, cashbackPerKg: 0.50 },
};

// Voucher types available for redemption
export const vouchers = pgTable("vouchers", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // 'discount', 'cashback', 'gift'
  value: decimal("value", { precision: 10, scale: 2 }).notNull(),
  pointsCost: integer("points_cost").notNull(),
  partnerName: text("partner_name"),
  partnerLogo: text("partner_logo"),
  expiresAt: timestamp("expires_at"),
  maxRedemptions: integer("max_redemptions"),
  currentRedemptions: integer("current_redemptions").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User voucher redemptions
export const userVouchers = pgTable("user_vouchers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  voucherId: integer("voucher_id").notNull(),
  code: text("code").notNull(), // Unique redemption code
  status: text("status").notNull().default("active"), // active, used, expired
  redeemedAt: timestamp("redeemed_at").defaultNow(),
  usedAt: timestamp("used_at"),
  expiresAt: timestamp("expires_at"),
});

// Reward transactions (points earned/spent)
export const rewardTransactions = pgTable("reward_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'earned', 'redeemed', 'expired', 'cashback'
  points: integer("points").default(0),
  cashback: decimal("cashback", { precision: 10, scale: 2 }).default("0"),
  description: text("description").notNull(),
  recyclableItemId: integer("recyclable_item_id"), // If earned from recycling
  voucherId: integer("voucher_id"), // If redeemed for voucher
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  contact: text("contact").notNull(),
  email: text("email").notNull(),
  regions: text("regions").array(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stations = pgTable("stations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  partnerId: integer("partner_id").notNull(),
  hours: text("hours"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  stationId: integer("station_id").notNull(),
  type: text("type").notNull().default("ble_scale"),
  serialNumber: text("serial_number").notNull().unique(),
  lastCalibration: timestamp("last_calibration"),
  firmware: text("firmware"),
  status: text("status").notNull().default("active"),
  batteryLevel: integer("battery_level"),
  lastSync: timestamp("last_sync"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const households = pgTable("households", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull().unique(),
  name: text("name"),
  email: text("email"),
  consentFlags: jsonb("consent_flags"),
  totalKg: decimal("total_kg", { precision: 10, scale: 2 }).default("0"),
  totalPoints: integer("total_points").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  collectionId: text("collection_id").notNull().unique(),
  householdId: integer("household_id"),
  stationId: integer("station_id").notNull(),
  collectorId: integer("collector_id").notNull(),
  kg: decimal("kg", { precision: 10, scale: 2 }).notNull(),
  payoutType: text("payout_type").notNull(),
  payoutAmount: decimal("payout_amount", { precision: 10, scale: 2 }).notNull(),
  photoUrl: text("photo_url"),
  signatureUrl: text("signature_url"),
  deviceId: integer("device_id"),
  flags: text("flags").array(),
  status: text("status").notNull().default("verified"),
  geoLocation: jsonb("geo_location"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const payouts = pgTable("payouts", {
  id: serial("id").primaryKey(),
  collectionId: integer("collection_id").notNull(),
  householdId: integer("household_id"),
  type: text("type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("completed"),
  reconciled: boolean("reconciled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fraudCases = pgTable("fraud_cases", {
  id: serial("id").primaryKey(),
  collectionIds: integer("collection_ids").array(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"),
  reviewerId: integer("reviewer_id"),
  resolutionNotes: text("resolution_notes"),
  severity: text("severity").notNull().default("medium"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

export const esgMetrics = pgTable("esg_metrics", {
  id: serial("id").primaryKey(),
  period: text("period").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  kgTotal: decimal("kg_total", { precision: 15, scale: 2 }).notNull(),
  householdsServed: integer("households_served").notNull(),
  co2Saved: decimal("co2_saved", { precision: 10, scale: 2 }).notNull(),
  revenueGenerated: decimal("revenue_generated", { precision: 15, scale: 2 }).notNull(),
  reportUrl: text("report_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiInsights = pgTable("ai_insights", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  metadata: jsonb("metadata"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// NEW: Recyclable Items submitted by EcoRakyat
export const recyclableItems = pgTable("recyclable_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // EcoRakyat user who submitted
  category: text("category").notNull(), // plastic, paper, glass, etc.
  subcategory: text("subcategory"), // PET bottles, cardboard, etc.
  description: text("description"),
  photoUrl: text("photo_url"),
  weightEstimateKg: decimal("weight_estimate_kg", { precision: 10, scale: 2 }),
  actualWeightKg: decimal("actual_weight_kg", { precision: 10, scale: 2 }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  address: text("address"),
  status: text("status").notNull().default("new"), // new, assigned, in_progress, collected, cancelled
  assignedRiderId: integer("assigned_rider_id"),
  routePlanId: integer("route_plan_id"), // Current route this item is on
  routeSequence: integer("route_sequence"), // Order in route (1, 2, 3...)
  routeStatus: text("route_status"), // on_route, off_route, wrong_category, completed
  collectedAt: timestamp("collected_at"),
  aiClassification: jsonb("ai_classification"), // HuggingFace results
  pointsEarned: integer("points_earned").default(0),
  cashbackEarned: decimal("cashback_earned", { precision: 10, scale: 2 }).default("0"),
  rewardType: text("reward_type"), // 'points', 'cashback', or null if not yet collected
  rewardCredited: boolean("reward_credited").default(false),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// NEW: Reports (illegal dumping, issues) submitted by EcoRakyat
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // EcoRakyat user who submitted
  title: text("title").notNull(),
  description: text("description").notNull(),
  photoUrl: text("photo_url"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  address: text("address"),
  severity: text("severity").notNull().default("medium"), // low, medium, high
  status: text("status").notNull().default("new"), // new, assigned, in_progress, resolved, cancelled
  assignedRiderId: integer("assigned_rider_id"),
  resolvedAt: timestamp("resolved_at"),
  resolutionNotes: text("resolution_notes"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// NEW: Route Plans for EcoRider
export const routePlans = pgTable("route_plans", {
  id: serial("id").primaryKey(),
  riderId: integer("rider_id").notNull(),
  riderName: text("rider_name"),
  date: timestamp("date").notNull(),
  status: text("status").notNull().default("planned"), // planned, in_progress, completed, cancelled
  selectedCategory: text("selected_category").notNull(), // Primary category being collected (for backward compat)
  selectedCategories: text("selected_categories").array(), // Multiple categories for collection
  restrictedCategories: text("restricted_categories").array(), // Categories that can't be mixed
  truckCapacityKg: decimal("truck_capacity_kg", { precision: 10, scale: 2 }),
  currentLoadKg: decimal("current_load_kg", { precision: 10, scale: 2 }).default("0"),
  startLatitude: decimal("start_latitude", { precision: 10, scale: 8 }),
  startLongitude: decimal("start_longitude", { precision: 11, scale: 8 }),
  polyline: text("polyline"), // Encoded route polyline
  waypoints: jsonb("waypoints"), // Array of waypoint coordinates
  totalDistanceKm: decimal("total_distance_km", { precision: 10, scale: 2 }),
  estimatedDurationMin: integer("estimated_duration_min"),
  aiSummary: text("ai_summary"), // AI explanation of route optimization
  optimizationMeta: jsonb("optimization_meta"), // AI optimization results
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// NEW: Route Events (individual stops in a route)
export const routeEvents = pgTable("route_events", {
  id: serial("id").primaryKey(),
  planId: integer("plan_id").notNull(),
  itemId: integer("item_id"), // Reference to recyclable_items
  reportId: integer("report_id"), // Reference to reports
  sequence: integer("sequence").notNull(), // Order in the route
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  address: text("address"),
  eta: timestamp("eta"),
  arrivedAt: timestamp("arrived_at"),
  completedAt: timestamp("completed_at"),
  status: text("status").notNull().default("pending"), // pending, arrived, completed, skipped
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// NEW: AI Prompts configuration (for customizing AI behavior)
export const aiPrompts = pgTable("ai_prompts", {
  id: serial("id").primaryKey(),
  promptType: text("prompt_type").notNull(), // recycling_coach, rider_assistant, classifier
  name: text("name").notNull(),
  content: text("content").notNull(),
  model: text("model").notNull().default("gemini-2.5-flash"),
  settings: jsonb("settings"), // temperature, max_tokens, etc.
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertPartnerSchema = createInsertSchema(partners).omit({
  id: true,
  createdAt: true,
});

export const insertStationSchema = createInsertSchema(stations).omit({
  id: true,
  createdAt: true,
});

export const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  createdAt: true,
});

export const insertHouseholdSchema = createInsertSchema(households).omit({
  id: true,
  createdAt: true,
});

export const insertCollectionSchema = createInsertSchema(collections).omit({
  id: true,
  createdAt: true,
});

export const insertPayoutSchema = createInsertSchema(payouts).omit({
  id: true,
  createdAt: true,
});

export const insertFraudCaseSchema = createInsertSchema(fraudCases).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});

export const insertEsgMetricSchema = createInsertSchema(esgMetrics).omit({
  id: true,
  createdAt: true,
});

export const insertAiInsightSchema = createInsertSchema(aiInsights).omit({
  id: true,
  createdAt: true,
});

export const insertRecyclableItemSchema = createInsertSchema(recyclableItems).omit({
  id: true,
  createdAt: true,
  collectedAt: true,
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});

export const insertRoutePlanSchema = createInsertSchema(routePlans).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertRouteEventSchema = createInsertSchema(routeEvents).omit({
  id: true,
  createdAt: true,
});

export const insertAiPromptSchema = createInsertSchema(aiPrompts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVoucherSchema = createInsertSchema(vouchers).omit({
  id: true,
  createdAt: true,
});

export const insertUserVoucherSchema = createInsertSchema(userVouchers).omit({
  id: true,
  redeemedAt: true,
  usedAt: true,
});

export const insertRewardTransactionSchema = createInsertSchema(rewardTransactions).omit({
  id: true,
  createdAt: true,
});

// Select types
export type User = typeof users.$inferSelect;
export type Partner = typeof partners.$inferSelect;
export type Station = typeof stations.$inferSelect;
export type Device = typeof devices.$inferSelect;
export type Household = typeof households.$inferSelect;
export type Collection = typeof collections.$inferSelect;
export type Payout = typeof payouts.$inferSelect;
export type FraudCase = typeof fraudCases.$inferSelect;
export type EsgMetric = typeof esgMetrics.$inferSelect;
export type AiInsight = typeof aiInsights.$inferSelect;
export type RecyclableItem = typeof recyclableItems.$inferSelect;
export type Report = typeof reports.$inferSelect;
export type RoutePlan = typeof routePlans.$inferSelect;
export type RouteEvent = typeof routeEvents.$inferSelect;
export type AiPrompt = typeof aiPrompts.$inferSelect;

// Insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertPartner = z.infer<typeof insertPartnerSchema>;
export type InsertStation = z.infer<typeof insertStationSchema>;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type InsertHousehold = z.infer<typeof insertHouseholdSchema>;
export type InsertCollection = z.infer<typeof insertCollectionSchema>;
export type InsertPayout = z.infer<typeof insertPayoutSchema>;
export type InsertFraudCase = z.infer<typeof insertFraudCaseSchema>;
export type InsertEsgMetric = z.infer<typeof insertEsgMetricSchema>;
export type InsertAiInsight = z.infer<typeof insertAiInsightSchema>;
export type InsertRecyclableItem = z.infer<typeof insertRecyclableItemSchema>;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type InsertRoutePlan = z.infer<typeof insertRoutePlanSchema>;
export type InsertRouteEvent = z.infer<typeof insertRouteEventSchema>;
export type InsertAiPrompt = z.infer<typeof insertAiPromptSchema>;
export type InsertVoucher = z.infer<typeof insertVoucherSchema>;
export type InsertUserVoucher = z.infer<typeof insertUserVoucherSchema>;
export type InsertRewardTransaction = z.infer<typeof insertRewardTransactionSchema>;

// Select types for new tables
export type Voucher = typeof vouchers.$inferSelect;
export type UserVoucher = typeof userVouchers.$inferSelect;
export type RewardTransaction = typeof rewardTransactions.$inferSelect;
